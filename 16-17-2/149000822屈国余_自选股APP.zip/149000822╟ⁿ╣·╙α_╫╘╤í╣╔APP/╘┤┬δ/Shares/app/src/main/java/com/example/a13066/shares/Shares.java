package com.example.a13066.shares;

/**
 * Created by 13066 on 2017/6/8.
 * 编写人：屈国余
 * QQ:1306642782
 */

public class Shares {
    String stockCode;//股票代码
    String stockName;//股票名称
    String stockCodes_Sina;
    boolean isTrue;//判断是否已加入自选股
    int _id;
    String stockPrice;
    String stockZhangDie;

    String buy_Count1;
    String buy_price1;
    String sale_count1;
    String sale_price1;
    String nowprice;
    String nowchange;

    String minprice;
    String maxprice;

    public String getMinprice() {
        return minprice;
    }

    public void setMinprice(String minprice) {
        this.minprice = minprice;
    }

    public String getMaxprice() {
        return maxprice;
    }

    public void setMaxprice(String maxprice) {
        this.maxprice = maxprice;
    }

    public Shares(String stockName, int _id) {
        this.stockName = stockName;
        this._id = _id;
    }

    public Shares(String stockName, String stockCode, String stockCodes_Sina, String buy_Count1, String buy_price1, String sale_count1, String sale_price1, String nowprice, String nowchange, String minprice, String maxprice) {
        this.stockName = stockName;
        this.stockCode = stockCode;
        this.stockCodes_Sina = stockCodes_Sina;
        this.buy_Count1 = buy_Count1;
        this.buy_price1 = buy_price1;
        this.sale_count1 = sale_count1;
        this.sale_price1 = sale_price1;
        this.nowprice = nowprice;
        this.nowchange = nowchange;
        this.maxprice = maxprice;
        this.minprice = minprice;
    }

    public Shares(String stockName, String stockCodes_Sina, String stockPrice, String stockZhangDie) {
        this.stockName = stockName;
        this.stockCodes_Sina = stockCodes_Sina;
        this.stockPrice = stockPrice;
        this.stockZhangDie = stockZhangDie;
    }

    public Shares(String stockCode, String stockName, String stockCodes_Sina, boolean isTrue) {
        this.stockCode = stockCode;
        this.stockName = stockName;
        this.stockCodes_Sina = stockCodes_Sina;
        this.isTrue = isTrue;
    }

    public String getStockCode() {
        return stockCode;
    }

    public void setStockCode(String stockCode) {
        this.stockCode = stockCode;
    }

    public String getStockName() {
        return stockName;
    }

    public void setStockName(String stockName) {
        this.stockName = stockName;
    }

    public String getStockCodes_Sina() {
        return stockCodes_Sina;
    }

    public void setStockCodes_Sina(String stockCodes_Sina) {
        this.stockCodes_Sina = stockCodes_Sina;
    }

    public boolean getIsTrue() {
        return isTrue;
    }

    public void setIsTrue(boolean isTrue) {
        this.isTrue = isTrue;
    }

    public boolean isTrue() {
        return isTrue;
    }

    public void setTrue(boolean aTrue) {
        isTrue = aTrue;
    }

    public String getStockZhangDie() {
        return stockZhangDie;
    }

    public void setStockZhangDie(String stockZhangDie) {
        this.stockZhangDie = stockZhangDie;
    }

    public String getStockPrice() {
        return stockPrice;
    }

    public void setStockPrice(String stockPrice) {
        this.stockPrice = stockPrice;
    }

    public String getBuy_Count1() {
        return buy_Count1;
    }

    public void setBuy_Count1(String buy_Count1) {
        this.buy_Count1 = buy_Count1;
    }

    public String getBuy_price1() {
        return buy_price1;
    }

    public void setBuy_price1(String buy_price1) {
        this.buy_price1 = buy_price1;
    }

    public String getSale_count1() {
        return sale_count1;
    }

    public void setSale_count1(String sale_count1) {
        this.sale_count1 = sale_count1;
    }

    public String getSale_price1() {
        return sale_price1;
    }

    public void setSale_price1(String sale_price1) {
        this.sale_price1 = sale_price1;
    }

    public String getNowprice() {
        return nowprice;
    }

    public void setNowprice(String nowprice) {
        this.nowprice = nowprice;
    }

    public String getNowchange() {
        return nowchange;
    }

    public void setNowchange(String nowchange) {
        this.nowchange = nowchange;
    }

    public int get_id() {
        return _id;
    }

    public void set_id(int _id) {
        this._id = _id;
    }
}
