package com.example.a13066.shares;

import android.app.ProgressDialog;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Handler;
import android.os.Message;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTabHost;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TabHost;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

/**
 * 详情页面
 */
public class DetailsActivity extends AppCompatActivity {

    private static final String TAG = "DetailsActivity";
    FragmentTabHost tabHost;
    private String[] texts = {"分时", "日K", "周K", "月K"};
    private String[] textTager = {"time", "day", "week", "month"};
    private Class[] fragmentArray = {TimeFragment.class, DayFragment.class, WeekFragment.class, MonthFragment.class};
    String stockCodes_Sina;
    Button showAd;
    TextView tv_stockName;
    String context;//判断是从哪个页面传值的
    int anInt = 0;//判断自选是否改变
    TextView maxprice, minprice, nowprice;
    SwipeRefreshLayout srl_x;
    private Handler handler = new Handler() {
        public static final String TAG = "MarketFragment";

        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            if (msg.what == 1) {
                init(1);
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);

        //获取页面之间传的值
        Intent intent = getIntent();
        stockCodes_Sina = intent.getStringExtra("stockCodes_Sina").toString().trim();
        context = intent.getStringExtra("context");
        showAd = (Button) findViewById(R.id.showAd);

        //即使器每隔一段时间执行一次
        Timer timer = new Timer(true);
        //任务
        TimerTask task = new TimerTask() {
            public void run() {
                handler.sendEmptyMessage(1);
            }
        };
        timer.schedule(task, 6 * 60 * 1000, 6 * 60 * 1000);

        /**
         * 选项卡
         */
        Bundle bundle = new Bundle();
        bundle.putString("stockCodes_Sina", stockCodes_Sina);

        tabHost = (FragmentTabHost) findViewById(android.R.id.tabhost);
        tabHost.setup(DetailsActivity.this, getSupportFragmentManager(), R.id.fl_contenthoice);

        for (int i = 0; i < texts.length; i++) {
            TabHost.TabSpec spec = tabHost.newTabSpec(textTager[i]).setIndicator(texts[i]);
            tabHost.addTab(spec, fragmentArray[i], bundle);

            View view1 = tabHost.getTabWidget().getChildAt(i);
            view1.getLayoutParams().height = 100;
            view1.setBackgroundResource(R.drawable.tab);
            //设置第一个选项的高度/宽度
        }

        getExistence();//判断判断股票是否自选
        init(0);//初始化数据
        /**
         * 下拉刷新
         */
        srl_x = (SwipeRefreshLayout) findViewById(R.id.srl_x);
        srl_x.setColorSchemeResources(android.R.color.holo_blue_bright,
                android.R.color.holo_green_light, android.R.color.holo_orange_light, android.R.color.holo_blue_bright);
        srl_x.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                /** 模拟网络请求，延时1秒 */
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        init(1);
                        String tag = tabHost.getCurrentTabTag();
                        Log.e(TAG, "run: ================="+tag );
                        if ("time".equals(tag)){
                            TimeFragment  time= (TimeFragment) getSupportFragmentManager().findFragmentByTag(tag);
                            time.getPricte();
                        }
                        if ("day".equals(tag)){
                            DayFragment day= (DayFragment) getSupportFragmentManager().findFragmentByTag(tag);
                            day.getPricte();
                        }
                        if ("week".equals(tag)){
                            WeekFragment week= (WeekFragment) getSupportFragmentManager().findFragmentByTag(tag);
                            week.getPricte();
                        }
                        if ("month".equals(tag)){
                            MonthFragment month= (MonthFragment) getSupportFragmentManager().findFragmentByTag(tag);
                            month.getPricte();
                        }
                        srl_x.setRefreshing(false);
                    }
                }, 1000);
            }
        });
    }

    /**
     * //判断股票是否自选
     */
    public void getExistence() {

        MySQLiteOpenHelper mySQLiteHelper = new MySQLiteOpenHelper(DetailsActivity.this, 1);
        SQLiteDatabase database = mySQLiteHelper.getWritableDatabase();//创建数据库并返回数据库对像
        Cursor cursor = database.query("OptionalShares", null, "SharesCode=?", new String[]{String.valueOf(stockCodes_Sina)}, null, null, null);//查询数据库中的数据并返回Cursor对象
        int i = 0;
        while (cursor.moveToNext()) {
            i++;
            break;
        }
        cursor.close();
        if (i != 0) {
            showAd.setText("取消自选");
        } else {
            showAd.setText("自选");
        }
        database.close();//关闭数据库
    }

    /**
     * 返回上一个页面
     * @param view
     */
    public void showFinish(View view) {
        Intent mIntent = new Intent();
        mIntent.putExtra("details", anInt);
        // 设置结果，并进行传送
        this.setResult(2, mIntent);
        finish();
    }

    /**
     * 绑定数据
     *
     * @param i
     */
    public void init(final int i) {
        new AsyncTask<String, Void, List<Shares>>() {
            ProgressDialog progressDialog;
            TextView sell_1, sell_2, buy_1, buy_2;

            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                progressDialog = new ProgressDialog(DetailsActivity.this);
                progressDialog.setMessage("正在加载中");
                progressDialog.setCancelable(false);
                if (i != 1) {
                    progressDialog.show();
                }
                sell_1 = (TextView) findViewById(R.id.sell_1);
                sell_2 = (TextView) findViewById(R.id.sell_2);
                buy_1 = (TextView) findViewById(R.id.buy_1);
                buy_2 = (TextView) findViewById(R.id.buy_2);
                tv_stockName = (TextView) findViewById(R.id.tv_stockName);
                maxprice = (TextView) findViewById(R.id.maxprice);
                minprice = (TextView) findViewById(R.id.minprice);
                nowprice = (TextView) findViewById(R.id.nowprice);
            }

            @Override
            protected List<Shares> doInBackground(String... params) {
                SharesContent content = new SharesContent();
                StringBuffer s = new StringBuffer(params[0]);
                List<Shares> shares = content.getShares(s);
                return shares;
            }

            @Override
            protected void onPostExecute(List<Shares> list) {
                super.onPostExecute(list);
                Shares s = list.get(0);
                if (i != 1) {
                    progressDialog.dismiss();
                }
                sell_1.setText("买一" + "  " + s.sale_price1);
                buy_1.setText("卖一"+ "   " + s.buy_price1);
                tv_stockName.setText(s.getStockName());
                nowprice.setText(s.getNowprice());
                maxprice.setText(s.getMaxprice());
                minprice.setText(s.getMinprice());
            }
        }.execute(stockCodes_Sina.trim());
    }

    /**
     * 修改自选状况
     *
     * @param view
     */
    public void showAdd(View view) {
        if (showAd.getText() == "自选") {
            MySQLiteOpenHelper mySQLiteHelper = new MySQLiteOpenHelper(DetailsActivity.this, 1);
            SQLiteDatabase database = mySQLiteHelper.getWritableDatabase();
            ContentValues contentValues = new ContentValues();
            contentValues.put("SharesCode", stockCodes_Sina.toString().trim());
            contentValues.put("SharesName", tv_stockName.getText().toString().trim());
            contentValues.put("userinfo_id", "1");
            long numID = database.insert("OptionalShares", null, contentValues);//如果插入成功返回插入的ID值,若失败则返回-1；
            Toast.makeText(DetailsActivity.this, "添加自选成功！", Toast.LENGTH_SHORT).show();
            showAd.setText("取消自选");

            anInt++;
        } else if (showAd.getText() == "取消自选") {
            MySQLiteOpenHelper mySQLiteHelper = new MySQLiteOpenHelper(DetailsActivity.this, 1);
            SQLiteDatabase database = mySQLiteHelper.getWritableDatabase();//创建数据库并返回数据库对像
            int optionalShares = database.delete("OptionalShares", "SharesCode=?", new String[]{String.valueOf(stockCodes_Sina)});
            Toast.makeText(DetailsActivity.this, "取消自选成功！", Toast.LENGTH_SHORT).show();
            Log.e(TAG, "delectDB:============ " + optionalShares);
            showAd.setText("自选");
            anInt++;
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        handler.removeCallbacksAndMessages(null);
    }
}
