package com.example.a13066.shares;

import android.content.Intent;
import android.os.Handler;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationSet;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;

public class LauncherActivity extends AppCompatActivity {
    private Handler handler = new Handler();
    private ImageView iv_image;
    AnimationSet animationSet;
    private boolean isTrue = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_launcher);
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        //取消标题栏
//        ActionBar actionBar = getSupportActionBar();
//        if (actionBar != null) {
//            actionBar.hide();
//        }

        iv_image = (ImageView) findViewById(R.id.iv_image);
        //设置动画
        animationSet = (AnimationSet) AnimationUtils.loadAnimation(this, R.anim.set);
        iv_image.startAnimation(animationSet);
        animationSet.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {

            }

            @Override
            public void onAnimationEnd(Animation animation) {
                isTrue = true;
            }

            @Override
            public void onAnimationRepeat(Animation animation) {

            }
        });
        //设置3秒跳转
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                showChainStore();
            }
        }, 3000);//3000毫秒后执行该代码
    }

    /**
     * 启动主界面
     */
    private boolean isbollean = false;

    public void showChainStore() {
        if (!isbollean && isTrue) {
            Intent intent = new Intent(LauncherActivity.this, SharesActivity.class);
            isbollean = true;
            isTrue=false;
            startActivity(intent);
            finish();
        }
    }

    /**
     * onTouchEvent 屏幕触摸事件
     *
     * @param event
     * @return
     */
    @Override
    public boolean onTouchEvent(MotionEvent event) {
        showChainStore();
        return super.onTouchEvent(event);
    }

    @Override
    protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);//移除Handler，传的值为空表示移除所有的handler和其中的值
        iv_image.clearAnimation();
        super.onDestroy();
    }
}
