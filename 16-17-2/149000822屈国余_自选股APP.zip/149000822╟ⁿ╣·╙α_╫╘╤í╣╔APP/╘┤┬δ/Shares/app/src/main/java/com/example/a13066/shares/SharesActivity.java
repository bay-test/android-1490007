package com.example.a13066.shares;



import android.support.v4.app.FragmentTabHost;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TabHost;
import android.widget.TextView;

public class SharesActivity extends AppCompatActivity {
    private static final String TAG = "SharesActivity";
    FragmentTabHost tabHost;
    private String texts[] = {"行情", "我的"};
    private String textTager[] = {"marker", "userInfo"};
    private int imageButton[] = {R.drawable.bottom_group_1, R.drawable.bottom_group_5};
    private Class fragmentArray[] = {MarketFragment.class, UserInfoFragment.class};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shares);

        //控件初始化
        init();

    }

    public void init() {
        /**
         * 选项卡
         */
        tabHost = (FragmentTabHost) findViewById(android.R.id.tabhost);
        tabHost.setup(SharesActivity.this, getSupportFragmentManager(), R.id.fl_content);

        for (int i = 0; i < texts.length; i++) {
            TabHost.TabSpec spec = tabHost.newTabSpec(textTager[i]).setIndicator(getView(i));
            tabHost.addTab(spec, fragmentArray[i], null);
        }

    }

    private View getView(int i) {
        //取得布局实例
        View view = View.inflate(SharesActivity.this, R.layout.tab_button, null);

        //取得布局对象
        ImageView imageView = (ImageView) view.findViewById(R.id.iv_button);
        TextView textView = (TextView) view.findViewById(R.id.tv_button_text);

        //设置图标
        imageView.setImageResource(imageButton[i]);
        //设置标题
        textView.setText(texts[i]);
        return view;
    }
}
