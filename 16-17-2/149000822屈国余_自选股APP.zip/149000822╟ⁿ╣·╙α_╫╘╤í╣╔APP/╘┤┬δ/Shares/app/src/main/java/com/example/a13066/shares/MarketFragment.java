package com.example.a13066.shares;


import android.content.ContentValues;
import android.content.Intent;
import android.content.res.Resources;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTabHost;
import android.support.v4.widget.SwipeRefreshLayout;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.TabHost;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;

/**
 * A simple {@link Fragment} subclass.
 */
public class MarketFragment extends Fragment {
    FragmentTabHost tabHost;
    private String[] texts = {"自选", "泸深"};
    private String[] textTager = {"optional", "luzhouDeep"};
    private Class[] fragmentArray = {OptionalFragment.class, LuzhouDeepFragment.class};
    OptionalFragment optionalFragment;
    View view;
    AutoCompleteTextView autoCompleteTextView;
    Button tv_edit;
    SwipeRefreshLayout srl_x;
    LuzhouDeepFragment luzhouDeepFragment;
    String text;//判断实在那个页面

    public MarketFragment() {
        // Required empty public constructor
    }
//    private Handler handler = new Handler() {
//        public static final String TAG = "MarketFragment";
//        @Override
//        public void handleMessage(Message msg) {
//            super.handleMessage(msg);
//            if (msg.what == 1) {
//                getShares();
//            }
//        }
//    };

    private Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            if (msg.what == 3) {
                getShares();
            }
        }
    };

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_market, container, false);
        init();
        /**
         * 选项卡
         */
        tabHost = (FragmentTabHost) view.findViewById(android.R.id.tabhost);
        tabHost.setup(getContext(), getChildFragmentManager(), R.id.fl_contenthoice);

        for (int i = 0; i < texts.length; i++) {
            TabHost.TabSpec spec = tabHost.newTabSpec(textTager[i]).setIndicator(texts[i]);
            tabHost.addTab(spec, fragmentArray[i], null);

            View view1 = tabHost.getTabWidget().getChildAt(i);
            view1.getLayoutParams().height = 100;
            //设置第一个选项的高度/宽度
        }
        getShares();//给AutoCompleteTextView控件提供数据源

        /**
         * 计时器
         */
//        Timer timer = new Timer(true);
//        //任务
//        TimerTask task = new TimerTask() {
//            public void run() {
//                handler.sendEmptyMessage(1);
//            }
//        };
//        timer.schedule(task, 0,1000);
        return view;
    }

    /**
     * 控件初始化
     */
    public void init() {
        tv_edit = (Button) view.findViewById(R.id.tv_edit);
        tv_edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getContext(), EditActivity.class);
                startActivityForResult(intent, 1);
            }
        });
        autoCompleteTextView = (AutoCompleteTextView) view.findViewById(R.id.tv_name);
        autoCompleteTextView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Shares shares = (Shares) parent.getItemAtPosition(position);
                if (!shares.getIsTrue()) {
                    MySQLiteOpenHelper mySQLiteHelper = new MySQLiteOpenHelper(getContext(), 1);
                    SQLiteDatabase database = mySQLiteHelper.getWritableDatabase();
                    ContentValues contentValues = new ContentValues();
                    contentValues.put("SharesCode", shares.getStockCodes_Sina().toString().trim());
                    contentValues.put("SharesName", shares.getStockName());
                    contentValues.put("userinfo_id", "1");
                    long numID = database.insert("OptionalShares", null, contentValues);//如果插入成功返回插入的ID值,若失败则返回-1；
                    Toast.makeText(getContext(), "添加自选成功！", Toast.LENGTH_SHORT).show();
                    optionalFragment.query(1);
                    getShares();
                    database.close();//关闭数据库
                }
                autoCompleteTextView.setText(shares.getStockName());

            }
        });

    }

    /**
     * 获取数据源
     *
     * @return
     */
    public void getShares() {
        Resources res = getResources();
        String[] stockNames = res.getStringArray(R.array.stocknames);
        final String[] stockCodes = res.getStringArray(R.array.stockcodes);
        String[] stockCodes_Sina = res.getStringArray(R.array.stockcodes_sina);

        new AsyncTask<String[], Void, List<Shares>>() {
            @Override
            protected void onPreExecute() {
                super.onPreExecute();
            }

            @Override
            protected List<Shares> doInBackground(String[]... params) {
                List<Shares> list = new ArrayList<>();
                Map<String, Boolean> map = getConents();
                String[] stockNames = params[0];
                String[] stockCodes = params[1];
                String[] stockCodes_Sina = params[2];
                for (int i = 0; i < params[1].length; i++) {
                    if (map.get(stockCodes_Sina[i]) != null) {
                        Shares shares = new Shares(stockCodes[i], stockNames[i], stockCodes_Sina[i], true);
                        list.add(shares);
                    } else {
                        Shares shares = new Shares(stockCodes[i], stockNames[i], stockCodes_Sina[i], false);
                        list.add(shares);
                    }
                }
                return list;
            }

            /**
             * 取出数据库中的自选值
             * @return
             */
            public Map<String, Boolean> getConents() {
                Map<String, Boolean> map = new HashMap<>();
                MySQLiteOpenHelper mySQLiteHelper = new MySQLiteOpenHelper(getContext(), 1);
                SQLiteDatabase database = mySQLiteHelper.getWritableDatabase();//创建数据库并返回数据库对像
                Cursor cursor = database.query("OptionalShares", null, null, null, null, null, null);//查询数据库中的数据并返回Cursor对象
                if (cursor.moveToFirst()) {
                    do {
                        //cursor.getString获取值，cursor.getColumnIndex("name")返回列所在的位置索引
                        String SharesCode = cursor.getString(cursor.getColumnIndex("SharesCode"));
                        map.put(SharesCode.toString().trim(), true);
                    } while (cursor.moveToNext());
                }
                cursor.close();
                database.close();
                return map;
            }

            @Override
            protected void onPostExecute(List<Shares> list) {
                super.onPostExecute(list);
                final MyAdapter myAdapter = new MyAdapter(list);
                autoCompleteTextView.setAdapter(myAdapter);
            }
        }.execute(stockNames, stockCodes, stockCodes_Sina);
    }

    @Override
    public void onAttachFragment(Fragment childFragment) {
        super.onAttachFragment(childFragment);
        if (childFragment instanceof OptionalFragment) {
            optionalFragment = (OptionalFragment) childFragment;
            text = "OptionalFragment";
            optionalFragment.getHandler(handler);
        }
        if (childFragment instanceof LuzhouDeepFragment) {
            luzhouDeepFragment = (LuzhouDeepFragment) childFragment;
            text = "LuzhouDeepFragment";
            luzhouDeepFragment.getHandler(handler);
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1 && resultCode == 1) {
            int dow = data.getIntExtra("edit", 0);
            if (dow != 0) {
                optionalFragment.query(1);
                getShares();
            }
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }
}
