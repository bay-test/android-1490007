package com.example.a13066.shares;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Created by 13066 on 2017/6/10.
 * 编写人：屈国余
 * QQ:1306642782
 */

public class MySQLiteOpenHelper extends SQLiteOpenHelper {
    public MySQLiteOpenHelper(Context context, int version) {
        super(context, "myshares.db", null, version);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String sql = "CREATE TABLE userinfo (_id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,UserName VARCHAR (100),Password VARCHAR (100),Name VARCHAR (30))";
        String sql1 = "CREATE TABLE OptionalShares (_id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,SharesCode  VARCHAR (16),SharesName  VARCHAR (20),userinfo_id INTEGER REFERENCES userinfo (_id))";
        db.execSQL(sql);
        db.execSQL(sql1);
        String s="INSERT INTO userinfo (UserName,Password,Name) VALUES ('13251317723','123456','屈国余')";
        db.execSQL(s);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
}
