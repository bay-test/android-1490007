package com.example.a13066.shares;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.List;

/**
 * Created by 13066 on 2017/6/12.
 * 编写人：屈国余
 * QQ:1306642782
 */

public class MyItemAdapter extends BaseAdapter {
    List<Shares> list;

    public MyItemAdapter(List<Shares> list) {
        this.list = list;
    }

    @Override
    public int getCount() {
        return list.size();
    }

    @Override
    public Object getItem(int position) {
        return list.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        Shares shares = list.get(position);
        ViewHolder viewHolder;
        if (convertView == null) {
            convertView = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_shares, null, false);
            viewHolder = new ViewHolder();
            viewHolder.stockName = (TextView) convertView.findViewById(R.id.tv_shareName);
            viewHolder.stockPrice = (TextView) convertView.findViewById(R.id.tv_price);
            viewHolder.stockZhangdie= (TextView) convertView.findViewById(R.id.tv_zhangDie);
            convertView.setTag(viewHolder);
        }
        viewHolder = (ViewHolder) convertView.getTag();
        viewHolder.stockName.setText(shares.getStockName());
        viewHolder.stockPrice.setText(shares.getNowprice());
        viewHolder.stockZhangdie.setText(shares.getNowchange());
        if(shares.getNowchange().contains("-")){
            viewHolder.stockZhangdie.setTextColor(parent.getContext().getResources().getColor(R.color.te));

        }else {
            viewHolder.stockZhangdie.setTextColor(parent.getContext().getResources().getColor(R.color.red));
        }
        return convertView;
    }

    class ViewHolder {
        TextView stockName;
        TextView stockPrice;
        TextView stockZhangdie;
    }
}
