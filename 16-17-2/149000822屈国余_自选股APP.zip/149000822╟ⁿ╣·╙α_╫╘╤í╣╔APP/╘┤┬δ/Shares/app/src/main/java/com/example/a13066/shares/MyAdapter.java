package com.example.a13066.shares;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by 13066 on 2017/6/8.
 * 编写人：屈国余
 * QQ:1306642782
 */
public class MyAdapter extends BaseAdapter implements Filterable {
    List<Shares> list;
    ArrayFilter mFilter;
    private ArrayList<Shares> mUnfilteredData;
    private final Object mLock = new Object();

    public MyAdapter(List<Shares> list) {
        this.list = list;
    }

    @Override
    public int getCount() {
        return list.size();
    }

    @Override
    public Object getItem(int position) {
        return list.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        Shares shares = list.get(position);
        ViewHolder viewHolder;
        if (convertView == null) {
            convertView = LayoutInflater.from(parent.getContext()).inflate(R.layout.auto_complete_textview_item, null, false);
            viewHolder = new ViewHolder();
            viewHolder.stockName = (TextView) convertView.findViewById(R.id.stockName);
            viewHolder.stockCode = (TextView) convertView.findViewById(R.id.stockCode);
            viewHolder.isTrue = (TextView) convertView.findViewById(R.id.tv_isTrue);
            viewHolder.isFalse = (TextView) convertView.findViewById(R.id.tv_isFalse);
            convertView.setTag(viewHolder);
        }
        viewHolder = (ViewHolder) convertView.getTag();
        viewHolder.stockName.setText(shares.getStockName());
        viewHolder.stockCode.setText(shares.getStockCode());
        if (shares.getIsTrue()){
            viewHolder.isTrue.setVisibility(View.VISIBLE);
            viewHolder.isFalse.setVisibility(View.GONE);
        }else {
            viewHolder.isFalse.setVisibility(View.VISIBLE);
            viewHolder.isTrue.setVisibility(View.GONE);
        }
        return convertView;
    }

    @Override
    public Filter getFilter() {
        if (mFilter == null) {
            mFilter = new ArrayFilter();
        }
        return mFilter;
    }

    class ViewHolder {
        TextView stockName;
        TextView stockCode;
        TextView isTrue;
        TextView isFalse;
    }

    private class ArrayFilter extends Filter {
        @Override
        protected FilterResults performFiltering(CharSequence constraint) {
            FilterResults results = new FilterResults();
            if (mUnfilteredData == null) {
                synchronized (mLock) {
                    mUnfilteredData = new ArrayList<Shares>(list);
                }
            }
            //如果没有过滤条件则不过滤
            if (constraint == null || constraint.length() == 0) {
                final ArrayList<Shares> list;
                synchronized (mLock) {
                    list = new ArrayList<>(mUnfilteredData);
                }
                results.values = list;
                results.count = list.size();
            } else {
                final String prefixString = constraint.toString().toLowerCase();

                final ArrayList<Shares> values;
                synchronized (mLock) {
                    values = new ArrayList<>(mUnfilteredData);
                }

                final int count = values.size();
                final ArrayList<Shares> newValues = new ArrayList<>();

                for (int i = 0; i < count; i++) {
                    final Shares shares = values.get(i);
                    if (shares.getStockCode().contains(prefixString)
                            || shares.getStockName().contains(prefixString)
                            || (shares.getStockCodes_Sina() + "").contains(prefixString)) {
                        newValues.add(shares);
                    } else {
                        final String[] words = shares.toString().split(" ");
                        for (String word : words) {
                            if (word.startsWith(prefixString)) {
                                newValues.add(shares);
                                break;
                            }
                        }
                    }
                }
                results.values = newValues;
                results.count = newValues.size();
            }
            return results;
        }

        //在这里返回过滤结果
        @Override
        protected void publishResults(CharSequence constraint, FilterResults results) {
            list = (List<Shares>) results.values;
            if (results.count > 0) {
                notifyDataSetChanged();
            } else {
                notifyDataSetInvalidated();
            }
        }
    }
}
