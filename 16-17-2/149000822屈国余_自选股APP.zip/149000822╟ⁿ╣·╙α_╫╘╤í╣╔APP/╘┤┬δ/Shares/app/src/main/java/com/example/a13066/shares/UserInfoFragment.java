package com.example.a13066.shares;


import android.content.Context;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;


/**
 * A simple {@link Fragment} subclass.
 */
public class UserInfoFragment extends Fragment implements View.OnClickListener {
    LinearLayout ll_login, rl_register, returnLogin;
    View view;
    MySQLiteOpenHelper sqLiteOpenHelper;
    EditText et_name;
    EditText et_password;
    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;
    CheckBox ck_password;

    public UserInfoFragment() {

    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_user_info, container, false);

        ll_login = (LinearLayout) view.findViewById(R.id.ll_login);
        rl_register = (LinearLayout) view.findViewById(R.id.rl_register);
        returnLogin = (LinearLayout) view.findViewById(R.id.returnLogin);
        Login();
        return view;
    }

    public void Login() {
        saveSP();
        et_name = (EditText) view.findViewById(R.id.editName);
        et_password = (EditText) view.findViewById(R.id.editPassword);
        ck_password = (CheckBox) view.findViewById(R.id.ck_password);

        if (sharedPreferences.getBoolean("ck_password", false)) {
            ck_password.setChecked(true);
            et_name.setText(sharedPreferences.getString("name", ""));
            et_password.setText(sharedPreferences.getString("password", ""));
        } else {
            ck_password.setChecked(false);
        }
        Button button = (Button) view.findViewById(R.id.btnShowSignIn);
        button.setOnClickListener(this);

    }

    public void queryDB(View view) {
        Cursor cursor = query();
        if (cursor.moveToFirst()) {
            do {
                //cursor.getString获取值，cursor.getColumnIndex("name")返回列所在的位置索引
                String name = cursor.getString(cursor.getColumnIndex("name"));
                Log.e("name", "queryDB:======================================= " + name);
            } while (cursor.moveToNext());
        }
        cursor.close();
    }

    /**
     * query查询数据库中的数据并返回Cursor对象
     *
     * @return Cursor
     */
    public Cursor query() {
        sqLiteOpenHelper = new MySQLiteOpenHelper(getContext(), 1);
        SQLiteDatabase database = sqLiteOpenHelper.getWritableDatabase();//创建数据库并返回数据库对像
        Cursor cursor = database.query("tabb", null, null, null, null, null, null);//查询数据库中的数据并返回Cursor对象
        return cursor;
    }

    public void showSignIn(View view) {
        save();
        et_password.setText("");
    }

    public void saveSP() {
        sharedPreferences = getContext().getSharedPreferences("mima", Context.MODE_PRIVATE);
    }

    public void save() {
        editor = sharedPreferences.edit();
        if (ck_password.isChecked()) {
            //MODE_PRIVATE表示同文件的新内容会覆盖原文件内容,及存的值key的值与文件中的值中的key值相同就覆盖
            //MODE_APPEND表示如果文件存在就向文件增加新内容。

            editor.putString("name", et_name.getText().toString().trim());
            editor.putString("password", et_password.getText().toString().trim());
            editor.putBoolean("ck_password", true);

        } else {
            editor.putBoolean("ck_password", false);
        }
        editor.commit();//提交。
    }

    /**
     * 注册
     */
    public void Register() {

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.btnShowSignIn:

                
        }
    }
}
