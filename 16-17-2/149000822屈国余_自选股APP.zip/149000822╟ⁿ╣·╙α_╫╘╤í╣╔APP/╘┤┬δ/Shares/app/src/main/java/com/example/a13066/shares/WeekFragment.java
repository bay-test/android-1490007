package com.example.a13066.shares;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import java.util.Timer;
import java.util.TimerTask;

import static android.content.ContentValues.TAG;

/**
 * Created by 13066 on 2017/6/14.
 * 编写人：屈国余
 * QQ:1306642782
 */
public class WeekFragment extends Fragment {
    View view;
    ImageView iv_image;
    String stockCodes_Sina;

    public WeekFragment() {
    }

    private Handler handler = new Handler() {
        public static final String TAG = "MarketFragment";

        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            if (msg.what == 1) {
                init();
            }
        }
    };

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_time, container, false);
        Bundle bundle = getArguments();//从activity传过来的Bundle
        if (bundle != null) {
            stockCodes_Sina = bundle.getString("stockCodes_Sina");
        }
        init();

        Timer timer = new Timer(true);
        //任务
        TimerTask task = new TimerTask() {
            public void run() {
                handler.sendEmptyMessage(1);
            }
        };
        timer.schedule(task, 6 * 60 * 1000, 6 * 60 * 1000);

        return view;
    }

    /**
     * 显示图片
     */
    public void init() {
        iv_image = (ImageView) view.findViewById(R.id.iv_image);
        new AsyncTask<String, Void, byte[]>() {
            @Override
            protected byte[] doInBackground(String... params) {
                SharesContent sharesContent = new SharesContent();
                byte[] bytes = sharesContent.loadChart("http://image.sinajs.cn/newchart/weekly/n/" + params[0] + ".gif");
                return bytes;
            }

            @Override
            protected void onPostExecute(byte[] bytes) {
                super.onPostExecute(bytes);
                Bitmap b = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
                iv_image.setImageBitmap(b);
            }
        }.execute(stockCodes_Sina);
    }
    public void getPricte(){
        Log.e(TAG, "getPricte: ===============week===" );
        init();
    }
    @Override
    public void onDestroy() {
        super.onDestroy();
        handler.removeCallbacksAndMessages(null);
    }
}
