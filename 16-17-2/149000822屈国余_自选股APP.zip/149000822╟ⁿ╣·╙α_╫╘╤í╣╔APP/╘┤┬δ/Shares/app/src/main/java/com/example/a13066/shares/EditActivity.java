package com.example.a13066.shares;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class EditActivity extends AppCompatActivity {
    private static final String TAG = "EditActivity";
    ListView listView;
    List<String> list = new ArrayList<>();
    List<Integer> ints = new ArrayList<>();
    int anInt = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit);
        query();
        listView = (ListView) findViewById(R.id.lv_item);
        final ArrayAdapter arrayAdapter = new ArrayAdapter(EditActivity.this, android.R.layout.simple_list_item_1, list);
        listView.setAdapter(arrayAdapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                delectDB(ints.get(position));
                list.remove(position);
                ints.remove(position);
                anInt++;
                Toast.makeText(EditActivity.this, "取消自选成功！", Toast.LENGTH_SHORT).show();
                arrayAdapter.notifyDataSetChanged();
            }
        });
    }

    /**
     * 回退到上一个界面
     *
     * @param view
     */
    public void showFinish(View view) {
        Intent mIntent = new Intent();
        mIntent.putExtra("edit", anInt);
        // 设置结果，并进行传送
        this.setResult(1, mIntent);
        finish();
    }

    /**
     * query查询数据库中的数据并返回Cursor对象
     *
     * @return Cursor
     */
    public void query() {
        list.clear();
        ints.clear();
        MySQLiteOpenHelper mySQLiteHelper = new MySQLiteOpenHelper(EditActivity.this, 1);
        SQLiteDatabase database = mySQLiteHelper.getWritableDatabase();//创建数据库并返回数据库对像
        Cursor cursor = database.query("OptionalShares", null, null, null, null, null, null);//查询数据库中的数据并返回Cursor对象
        if (cursor.moveToFirst()) {
            do {
                //cursor.getString获取值，cursor.getColumnIndex("name")返回列所在的位置索引
                String name = cursor.getString(cursor.getColumnIndex("SharesName"));
                Log.e(TAG, "query:================= " + name);
                list.add(name);
                int _id = cursor.getInt(cursor.getColumnIndex("_id"));
                ints.add(_id);
                Log.e(TAG, "query:================= " + _id);
            } while (cursor.moveToNext());
        }
        cursor.close();
    }

    public void delectDB(int _id) {
        MySQLiteOpenHelper mySQLiteHelper = new MySQLiteOpenHelper(EditActivity.this, 1);
        SQLiteDatabase database = mySQLiteHelper.getWritableDatabase();//创建数据库并返回数据库对像
        int optionalShares = database.delete("OptionalShares", "_id=?", new String[]{String.valueOf(_id)});
        Log.e(TAG, "delectDB:============ " + optionalShares);
    }


}
