package com.example.a13066.shares;

/**
 * Created by 13066 on 2017/6/12.
 * 编写人：屈国余
 * QQ:1306642782
 */

public class UserInfo {
    int _id;
    String userName;
    String password;
    String Name;

    public UserInfo(int _id, String name, String password, String userName) {
        this._id = _id;
        Name = name;
        this.password = password;
        this.userName = userName;
    }

    public int get_id() {
        return _id;
    }

    public void set_id(int _id) {
        this._id = _id;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }
}
