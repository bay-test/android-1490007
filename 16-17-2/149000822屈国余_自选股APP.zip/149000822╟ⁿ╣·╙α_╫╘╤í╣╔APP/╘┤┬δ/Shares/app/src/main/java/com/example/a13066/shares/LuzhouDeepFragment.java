package com.example.a13066.shares;


import android.app.ProgressDialog;
import android.content.Intent;
import android.content.res.Resources;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v4.app.Fragment;
import android.support.v4.widget.SwipeRefreshLayout;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.ListView;

import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import static android.content.ContentValues.TAG;


/**
 * A simple {@link Fragment} subclass.
 */

/**
 * LuzhouDeepFragment 泸深页面
 */
public class LuzhouDeepFragment extends Fragment {
    View view;
    ListView lv_luzhouDeep;
    int mPosition = 0;
    SwipeRefreshLayout srl_x;
    private Handler handler1;

    public LuzhouDeepFragment() {
        // Required empty public constructor
    }

    /**
     * 处理定时任务
     */
    private Handler handler = new Handler() {
        public static final String TAG = "MarketFragment";
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            if (msg.what == 1) {
                query(1);
            }
        }
    };
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_luzhou_deep, container, false);
        lv_luzhouDeep = (ListView) view.findViewById(R.id.lv_luzhouDeep);
        query(0);
        lv_luzhouDeep.setOnScrollListener(new AbsListView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(AbsListView view, int scrollState) {
                if (scrollState == AbsListView.OnScrollListener.SCROLL_STATE_IDLE) {
                    mPosition = lv_luzhouDeep.getFirstVisiblePosition();
                    if (mPosition == 0) {
                        srl_x.setEnabled(true);
                    } else {
                        srl_x.setEnabled(false);
                    }
                }
            }

            @Override
            public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {

            }
        });

        /**
         * 计时器
         */
        Timer timer = new Timer(true);
        //任务
        TimerTask task = new TimerTask() {
            public void run() {
                handler.sendEmptyMessage(1);
            }
        };
        timer.schedule(task, 6*60*1000,6*60*1000);

        /**
         * 下拉刷新
         */
        srl_x = (SwipeRefreshLayout) view.findViewById(R.id.srl_x);
        srl_x.setColorSchemeResources(android.R.color.holo_blue_bright,
                android.R.color.holo_green_light, android.R.color.holo_orange_light, android.R.color.holo_blue_bright);
        srl_x.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                /** 模拟网络请求，延时1秒 */
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        query(1);
                        srl_x.setRefreshing(false);
                    }
                }, 1000);
            }
        });
        return view;
    }

    public void query(final int x) {
        Resources res = getResources();
        String[] stockCodes_Sina = res.getStringArray(R.array.stockcodes_sina);
        StringBuffer stringBuffer = new StringBuffer();
        for (int i = 0; i < 30; i++) {
            stringBuffer.append(stockCodes_Sina[i] + ",");
        }
        new AsyncTask<StringBuffer, Void, List<Shares>>() {
            ProgressDialog progressDialog;

            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                progressDialog = new ProgressDialog(getContext());
                progressDialog.setMessage("正在加载中");
                progressDialog.setCancelable(false);
                if (x != 1) {
                    progressDialog.show();
                }
            }

            @Override
            protected List<Shares> doInBackground(StringBuffer... params) {
                SharesContent content = new SharesContent();
                List<Shares> shares = content.getShares(params[0]);
                return shares;
            }

            @Override
            protected void onPostExecute(List<Shares> list) {
                super.onPostExecute(list);
                MyItemAdapter myItemAdapter = new MyItemAdapter(list);
                lv_luzhouDeep.setAdapter(myItemAdapter);
                lv_luzhouDeep.setSelection(mPosition);//用于设置listview开始显示的item位置
                lv_luzhouDeep.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                        Shares shares = (Shares) parent.getItemAtPosition(position);
                        Intent intent = new Intent(getContext(), DetailsActivity.class);
                        intent.putExtra("stockCodes_Sina", shares.getStockCodes_Sina().toString().toString());
                        intent.putExtra("context", "LuzhouDeepFragment");
                        startActivityForResult(intent,2);
                    }
                });
                if (x != 1) {
                    progressDialog.dismiss();
                }
            }
        }.execute(stringBuffer);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        handler.removeCallbacksAndMessages(null);
    }

    /**
     * 用户通知父级更新
     * @param handler
     */
    public void getHandler(Handler handler) {
        this.handler1 = handler;
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        Log.e(TAG, "==================== " + resultCode);
        if (requestCode == 2 && resultCode == 2) {
            if (data.getIntExtra("details", 0) % 2 != 0) {
                query(1);
                handler1.sendEmptyMessage(3);
            }
        }
    }
}
