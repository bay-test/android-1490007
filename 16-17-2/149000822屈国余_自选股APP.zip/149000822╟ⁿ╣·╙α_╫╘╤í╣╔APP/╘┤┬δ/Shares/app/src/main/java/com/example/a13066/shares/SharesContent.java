package com.example.a13066.shares;

import android.os.Handler;
import android.os.Message;
import android.util.Log;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by 13066 on 2017/6/12.
 * 编写人：屈国余
 * QQ:1306642782
 */

public class SharesContent {
    final List<Shares> list = new ArrayList<>();
//    public void getShares(final Handler handler, final StringBuffer stockCodes_Sina){
//        Log.e("log", "run: ===================================" + stockCodes_Sina.toString());
//        new Thread(new Runnable() {
//            @Override
//            public void run() {
//                HttpURLConnection conn = null;
//                try {
//                    URL url = new URL("http://hq.sinajs.cn/list=" + stockCodes_Sina.toString());
//                    Log.e("log", "run: ===================================" + url.toString());
//                    conn = (HttpURLConnection) url.openConnection();
//                    conn.setRequestMethod("GET");
//                    Log.e("log", "run: ===================================" + conn.getResponseCode());
//                    //判断网络请求是否成功 conn.getResponseCode()==200为true则表示请求成功
//                    if (conn.getResponseCode() == 200) {
//                        InputStream inputStream = conn.getInputStream();
//                        byte[] bytes = new byte[1024];
//                        int len = -1;
//                        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
//                        while ((len = inputStream.read(bytes)) != -1) {
//                            byteArrayOutputStream.write(bytes, 0, len);
//                        }
//                        String tv_texts = byteArrayOutputStream.toString("GBK");
//                        Log.e("log", "run: ===================================" + tv_texts);
//                        tv_texts = tv_texts.replace("var hq_str_", "");
//                        tv_texts = tv_texts.replace("\"", "");
//                        String[] stocks = tv_texts.split(";");
//                        for (String stock : stocks) {
//                            String[] s = stock.split("=");
//                            if (s.length < 2) {
//                                continue;
//                            }
//                            String[] stockInfo = s[1].split(",");
//                            float nowChange = (Float.valueOf(stockInfo[3]) - Float.valueOf(stockInfo[2])) / Float.valueOf(stockInfo[2]);
//
//                            DecimalFormat decimalFormat = new DecimalFormat("0.00");
//                            String nowChangeStr = decimalFormat.format(nowChange * 100);
//
//                            String nowchange = nowChangeStr + "%";
//                            String sinastockcode = s[0];
//                            String stockcode = s[0].replace("sh", "").replace("sz", "");
//                            Shares shares = new Shares(stockInfo[0], stockcode, sinastockcode, stockInfo[10], stockInfo[11], stockInfo[20], stockInfo[21], stockInfo[3], nowchange);
//                            list.add(shares);
//                            byteArrayOutputStream.close();
//                            inputStream.close();
//                        }
//                    } else {
//                        Log.e("log", "run: ===================================" + "失败");
//                    }
//                    Thread.sleep(1000);
//                } catch (Exception e) {
//                    e.printStackTrace();
//                } finally {
//                    if (conn != null) {
//                        conn.disconnect();
//                    }
//                    Message message=new Message();
//                    message.obj=list;
//                    message.what=1;
//                    handler.sendMessage(message);
//                }
//            }
//        }).start();
//    }

    public List<Shares> getShares(StringBuffer stockCodes_Sina) {
        list.clear();
        HttpURLConnection conn = null;
        try {
            URL url = new URL("http://hq.sinajs.cn/list=" + stockCodes_Sina.toString());
            conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            //判断网络请求是否成功 conn.getResponseCode()==200为true则表示请求成功
            if (conn.getResponseCode() == 200) {
                InputStream inputStream = conn.getInputStream();
                byte[] bytes = new byte[1024];
                int len = -1;
                ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                while ((len = inputStream.read(bytes)) != -1) {
                    byteArrayOutputStream.write(bytes, 0, len);
                }
                String tv_texts = byteArrayOutputStream.toString("GBK");
                tv_texts = tv_texts.replace("var hq_str_", "");
                tv_texts = tv_texts.replace("\"", "");
                String[] stocks = tv_texts.split(";");
                for (String stock : stocks) {
                    String[] s = stock.split("=");
                    if (s.length < 2) {
                        continue;
                    }
                    String[] stockInfo = s[1].split(",");
                    float nowChange = (Float.valueOf(stockInfo[3]) - Float.valueOf(stockInfo[2])) / Float.valueOf(stockInfo[2]);

                    DecimalFormat decimalFormat = new DecimalFormat("0.00");
                    String nowChangeStr = decimalFormat.format(nowChange * 100);

                    String nowchange = nowChangeStr + "%";
                    String sinastockcode = s[0];
                    String stockcode = s[0].replace("sh", "").replace("sz", "");
                    Shares shares = new Shares(stockInfo[0], stockcode, sinastockcode, stockInfo[10], stockInfo[11], stockInfo[20], stockInfo[21], stockInfo[3], nowchange,stockInfo[5],stockInfo[4]);
                    list.add(shares);
                    byteArrayOutputStream.close();
                    inputStream.close();
                }
            } else {
                Log.e("log", "run: ===================================" + "失败");
            }
            Thread.sleep(1000);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (conn != null) {
                conn.disconnect();
            }

        }
        return list;
    }

    public byte[] loadChart(String strurl) {

        byte[] minChart = null;

        try {
            URL url = new URL(strurl);
            HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
            httpURLConnection.connect();
            if (httpURLConnection.getResponseCode() == 200) {

                InputStream inputStream = httpURLConnection.getInputStream();
                ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();

                int len = -1;
                byte[] b = new byte[1024];
                while ((len = inputStream.read(b)) != -1) {
                    byteArrayOutputStream.write(b, 0, len);
                }
                minChart = byteArrayOutputStream.toByteArray();
                byteArrayOutputStream.close();
                inputStream.close();
                httpURLConnection.disconnect();

            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return minChart;
    }
}
