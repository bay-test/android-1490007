package com.example.stock;


import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v4.app.Fragment;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;


/**
 * A simple {@link Fragment} subclass.
 */
public class CustomFragment extends Fragment {
    Handler handler;
    MyViewAdapter myAdapter;
    List<Stock> stocks=new ArrayList<>();

    Handler autoHandler;

    public CustomFragment() {
        // Required empty public constructor
    }
    public void  setHandler(Handler handler){
        this.handler=handler;
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        Message message=Message.obtain();
        message.obj="sssss";
        handler.sendMessage(message);
        autoHandler=new Handler(new Handler.Callback() {
            @Override
            public boolean handleMessage(Message message) {
                loadStocks();
                autoHandler.sendEmptyMessageAtTime(1,1000);
                return false;
            }
        });

        View view= inflater.inflate(R.layout.fragment_custom, container, false);

        RecyclerView recyclerView= (RecyclerView) view.findViewById(R.id.rv_stock);

        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        loadStocks();

        myAdapter=new MyViewAdapter(getContext(),stocks);
        recyclerView.setAdapter(myAdapter);

        final SwipeRefreshLayout swipeRefreshLayout= (SwipeRefreshLayout) view.findViewById(R.id.refresh);

        swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                loadStocks();
                //   myAdapter.notifyDataSetChanged();
                swipeRefreshLayout.setRefreshing(false);
            }
        });


        return view;
    }
    public void reRefresh(){
        loadStocks();
        //   myAdapter.notifyDataSetChanged();

    }

    private void loadStocks() {
        stocks.clear();
        //  List<Stock> s=new ArrayList<>();
        MySQLiteOpenHelper mySQLiteOpenHelper=new MySQLiteOpenHelper(getContext(),1);

        SQLiteDatabase sqLiteDatabase=mySQLiteOpenHelper.getWritableDatabase();

        Cursor cursor=sqLiteDatabase.query("stock",new String[]{"_id","stockcode","stockname","sinastockcode"},null,null,null,null,null);
        StringBuffer queryCodes=new StringBuffer();
        while (cursor.moveToNext()){
//            Stock stock=new Stock();
//            stock.setNowchange("10%");
//            stock.setNowprice("3.98");
//            stock.set_id(cursor.getString(0));
//            stock.setStockcode(cursor.getString(1));
//            stock.setStockname(cursor.getString(2));
//            stock.setSinastockcode(cursor.getString(3));
//            stocks.add(stock);
            queryCodes.append(cursor.getString(3).trim()+",");

        }
        sqLiteDatabase.close();
        new AsyncTask<String, Integer, Map<String, Stock>>() {
            @Override
            protected Map<String, Stock> doInBackground(String... params) {
                Common common=new Common();


                return common.loadStocks(params[0]);
            }

            @Override
            protected void onPostExecute(Map<String, Stock> stringStockMap) {
                super.onPostExecute(stringStockMap);
                stocks.addAll(stringStockMap.values());
                if (myAdapter!=null){
                    myAdapter.notifyDataSetChanged();
                }
            }
        }.execute(queryCodes.toString());


    }


}

class MyViewAdapter extends RecyclerView.Adapter {
    Context context;
    List<Stock> stocks;
    public MyViewAdapter(Context context, List<Stock> stocks) {
        this.context=context;
        this.stocks=stocks;

    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        //   View view=View.inflate(context,R.layout.stock_item,null);
        View view=LayoutInflater.from(context).inflate(R.layout.stock_item,parent,false);

        MyHolder myHolder=new MyHolder(view);

        return myHolder;
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        MyHolder myHolder= (MyHolder) holder;
        myHolder.stockname.setText(stocks.get(position).getStockname());
        myHolder.stockcode.setText(stocks.get(position).getStockcode());
        myHolder.nowprice.setText(stocks.get(position).getNowprice());
        myHolder.nowchange.setText(stocks.get(position).getNowchange());


    }

    @Override
    public int getItemCount() {
        return stocks.size();
    }


    class MyHolder extends RecyclerView.ViewHolder {
        TextView stockname;
        TextView stockcode;
        TextView nowprice;
        TextView nowchange;

        public MyHolder(View itemView) {
            super(itemView);
            stockname= (TextView) itemView.findViewById(R.id.stockname);
            stockcode= (TextView) itemView.findViewById(R.id.stockcode);
            nowprice= (TextView) itemView.findViewById(R.id.nowprice);
            nowchange= (TextView) itemView.findViewById(R.id.nowchange);
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Stock stock=stocks.get(getAdapterPosition());
                    Intent intent =new Intent(context,DetailActivity.class);
                    intent.putExtra("stockcode",stock.getStockcode());
                    intent.putExtra("sinastockcode",stock.getSinastockcode());
                    context.startActivity(intent);
                }
            });
        }


    }

}

