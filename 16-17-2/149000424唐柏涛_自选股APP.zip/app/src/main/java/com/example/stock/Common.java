package com.example.stock;

import android.util.Log;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.Map;


/**
 * Created by 10333 on 2017/6/14.
 */

public class Common {
    public Map<String, Stock> loadStocks(String sinaStockCodes) {
        Map<String, Stock> stocksMap = new HashMap<String, Stock>();
        try {
            String urlstr = "http://hq.sinajs.cn/list=" + sinaStockCodes.trim();
            Log.e("tag", "loadStocks:----url-------- "+urlstr );

            URL url = new URL(urlstr);
            HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();

            httpURLConnection.connect();

            if (httpURLConnection.getResponseCode() == 200) {

                InputStream inputStream = httpURLConnection.getInputStream();
                ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();

                int len = -1;
                byte[] b = new byte[1024];
                while ((len = inputStream.read(b)) != -1) {
                    byteArrayOutputStream.write(b, 0, len);
                }
                String result = byteArrayOutputStream.toString("GBK");
                // Toast.makeText(DetailActivity.this, ""+result, Toast.LENGTH_SHORT).show();
                //  Log.e("tag", "doInBackground:================= " + result);

                byteArrayOutputStream.close();
                inputStream.close();
                httpURLConnection.disconnect();

                Log.e("tag", "loadStocks: ----------"+result );
                result = result.replace("var hq_str_", "");
                result = result.replace("\"", "");
                String[] stocks = result.split(";");
                for (String stock : stocks) {
                    String[] s = stock.split("=");
                    if(s.length<2){
                        continue;
                    }
                    String[] stockInfo = s[1].split(",");
                    Stock retStock = new Stock();
                    retStock.setStockname(stockInfo[0]);
                    retStock.setBuy_count1(stockInfo[10]);
                    retStock.setBuy_price1(stockInfo[11]);
                    retStock.setBuy_count1(stockInfo[12]);
                    retStock.setBuy_price1(stockInfo[13]);
                    retStock.setBuy_count1(stockInfo[14]);
                    retStock.setBuy_price1(stockInfo[15]);
                    retStock.setBuy_count1(stockInfo[16]);
                    retStock.setBuy_price1(stockInfo[17]);
                    retStock.setBuy_count1(stockInfo[18]);
                    retStock.setBuy_price1(stockInfo[19]);

                    retStock.setSale_count1(stockInfo[20]);
                    retStock.setSale_price1(stockInfo[21]);
                    retStock.setNowprice(stockInfo[3]);
                    float nowChange = (Float.valueOf(stockInfo[3])-Float.valueOf(stockInfo[2]))/Float.valueOf(stockInfo[2]);

                    DecimalFormat decimalFormat=new DecimalFormat("0.00");
                    String nowChangeStr = decimalFormat.format(nowChange*100);

                    retStock.setNowchange(nowChangeStr+"%");
                    retStock.setSinastockcode(s[0]);
                    retStock.setStockcode(s[0].replace("sh","").replace("sz",""));
                    stocksMap.put(s[0], retStock);


                }


            }


        } catch (Exception e) {
            e.printStackTrace();

        }

        return stocksMap;
    }


    public byte[] loadChart(String strurl) {

        byte[] minChart = null;

        try {
            // String urlstr = "http://image.sinajs.cn/newchart/min/n/" + sinaStockCode + ".gif";
            //  Log.e("tag", "loadMinChart:------------- "+urlstr );
            URL url = new URL(strurl);
            HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
            httpURLConnection.connect();
            if (httpURLConnection.getResponseCode() == 200) {

                InputStream inputStream = httpURLConnection.getInputStream();
                ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();

                int len = -1;
                byte[] b = new byte[1024];
                while ((len = inputStream.read(b)) != -1) {
                    byteArrayOutputStream.write(b, 0, len);
                }
                minChart = byteArrayOutputStream.toByteArray();
                // Toast.makeText(DetailActivity.this, ""+result, Toast.LENGTH_SHORT).show();
                //  Log.e("tag", "doInBackground:================= " + result);

                byteArrayOutputStream.close();
                inputStream.close();
                httpURLConnection.disconnect();


            }


        } catch (Exception e) {
            e.printStackTrace();

        }

        return minChart;
    }


}
