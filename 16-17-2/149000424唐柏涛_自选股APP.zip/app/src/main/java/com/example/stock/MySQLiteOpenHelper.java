package com.example.stock;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;



/**
 * Created by 10333 on 2017/6/13.
 */

public class MySQLiteOpenHelper extends SQLiteOpenHelper {
    public MySQLiteOpenHelper(Context context, int version) {
        super(context, "stock.db", null, version);
    }


    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE table stock(_id integer primary key autoincrement,stockcode varchar,stockname varchar,sinastockcode varchar);");
        db.execSQL("CREATE table user(_id integer primary key autoincrement,username varchar,password varchar);");

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
}
