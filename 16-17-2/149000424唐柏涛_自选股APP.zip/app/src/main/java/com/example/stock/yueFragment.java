package com.example.stock;


import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.Toast;


/**
 * Created by 10333 on 2017/6/14.
 */

public class yueFragment extends Fragment{



    public yueFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view=inflater.inflate(R.layout.fragment_yue, container, false);
        Bundle bundle=getArguments();
        final ImageView imageView= (ImageView) view.findViewById(R.id.yue_pic);
        String stockSinaCode=bundle.getString("sinastockcode");
        Toast.makeText(getContext(),"-----"+stockSinaCode,Toast.LENGTH_LONG).show();


        new AsyncTask<String, Integer, byte[]>() {
            @Override
            protected byte[] doInBackground(String... params) {
                Common common=new Common();
                String url="http://image.sinajs.cn/newchart/monthly/n/" + params[0] + ".gif";
                byte[] b=common.loadChart(url);

                return b;
            }

            @Override
            protected void onPostExecute(byte[] bytes) {
                Bitmap bitmap= BitmapFactory.decodeByteArray(bytes,0,bytes.length);
                imageView.setImageBitmap(bitmap);
                super.onPostExecute(bytes);
            }
        }.execute(stockSinaCode.trim());


        return view;
    }
}
