package com.example.stock;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
/**
 * Created by 10333 on 2017/6/15.
 */

public class RegActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reg);
        getSupportActionBar().hide();
    }
    public void login(View view){
        Intent intent=new Intent(RegActivity.this,LoginActivity.class);
        startActivity(intent);
    }
}

