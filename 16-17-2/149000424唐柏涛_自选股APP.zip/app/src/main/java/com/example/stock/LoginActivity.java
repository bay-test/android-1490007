package com.example.stock;


import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

/**
 * Created by 10333 on 2017/6/15.
 */

public class LoginActivity extends AppCompatActivity{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        MySQLiteOpenHelper mysql=new MySQLiteOpenHelper(LoginActivity.this,1);
        SQLiteDatabase sql=mysql.getWritableDatabase();


    }
}

