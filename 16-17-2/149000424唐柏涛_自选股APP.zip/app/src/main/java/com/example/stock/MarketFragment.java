package com.example.stock;

import android.content.ContentValues;
import android.content.res.Resources;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTabHost;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.TabHost;
import android.widget.Toast;
import java.util.HashMap;
import java.util.Map;


/**
 * Created by 10333 on 2017/6/14.
 */

public class MarketFragment  extends Fragment{
    Map<String,Stock> stockMap=new HashMap<String,Stock>();
    CustomFragment customFragment;

    Handler handler=new Handler(new Handler.Callback() {
        @Override
        public boolean handleMessage(Message msg) {
            Toast.makeText(getContext(),""+msg.obj,Toast.LENGTH_LONG).show();
            return false;
        }
    });

    public MarketFragment() {
        // Required empty public constructor
    }

    @Override
    public void onAttachFragment(Fragment childFragment) {
        super.onAttachFragment(childFragment);
        if (childFragment instanceof CustomFragment) {
            customFragment = (CustomFragment) childFragment;
            customFragment.setHandler(handler);
        }
        Toast.makeText(getContext(), "" + childFragment, Toast.LENGTH_LONG).show();

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view=inflater.inflate(R.layout.fragment_market,container,false);

        FragmentTabHost fragmentTabHost= (FragmentTabHost) view.findViewById(android.R.id.tabhost);
        fragmentTabHost.setup(getActivity(),getChildFragmentManager(),R.id.realtabcontent);


        TabHost.TabSpec tabSpecCust=fragmentTabHost.newTabSpec("cust");
        tabSpecCust.setIndicator("自选");
        fragmentTabHost.addTab(tabSpecCust,CustomFragment.class,null);

        TabHost.TabSpec tabSpecStock=fragmentTabHost.newTabSpec("stock");
        tabSpecStock.setIndicator("沪深");
        fragmentTabHost.addTab(tabSpecStock,StockFragment.class,null);

        fragmentTabHost.getTabWidget().getChildAt(0).getLayoutParams().height=100;
        fragmentTabHost.getTabWidget().getChildAt(1).getLayoutParams().height=100;

        Resources resources=view.getResources();

        final  String [] stockCodes=resources.getStringArray(R.array.stockcodes);
        final  String [] stockNames=resources.getStringArray(R.array.stocknames);
        final  String [] stockSinaCode=resources.getStringArray(R.array.stockcodes_sina);

        for (int i=0;i<stockCodes.length;i++){
            Stock stock=new Stock();
            stock.setStockname(stockNames[i]);
            stock.setStockcode(stockCodes[i]);
            stock.setSinastockcode(stockSinaCode[i]);
            stockMap.put(stockCodes[i],stock);

        }


        final AutoCompleteTextView autoCompleteTextView= (AutoCompleteTextView) view.findViewById(R.id.act_code);
        ArrayAdapter arrayAdapter=new ArrayAdapter(getActivity(),android.R.layout.simple_list_item_1,stockCodes);
        autoCompleteTextView.setAdapter(arrayAdapter);

        autoCompleteTextView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String stockcode=parent.getItemAtPosition(position).toString();


                Toast.makeText(getActivity(),"-----"+parent.getItemAtPosition(position).toString(),Toast.LENGTH_LONG).show();
                Toast.makeText(getActivity(),"-----xxx"+parent.getAdapter().getItem(position).toString(),Toast.LENGTH_LONG).show();
                Toast.makeText(getActivity(),"-----xxx"+stockCodes[position],Toast.LENGTH_LONG).show();

                Stock stock=stockMap.get(stockcode);


                MySQLiteOpenHelper mySQLiteOpenHelper=new MySQLiteOpenHelper(getActivity(),1);


                ContentValues values=new ContentValues();
                values.put("stockname",stock.getStockname());
                values.put("stockcode",stock.getStockcode());
                values.put("sinastockcode",stock.getSinastockcode());

                SQLiteDatabase  sqLiteDatabase=mySQLiteOpenHelper.getWritableDatabase();
                sqLiteDatabase.insert("stock",null,values);
                sqLiteDatabase.close();

                autoCompleteTextView.setText("");

                customFragment.reRefresh();

                Toast.makeText(getActivity(),"自选股添加成功",Toast.LENGTH_LONG).show();



            }
        });




        return view;
    }

}
