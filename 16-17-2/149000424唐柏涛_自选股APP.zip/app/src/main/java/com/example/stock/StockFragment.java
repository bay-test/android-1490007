package com.example.stock;

import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;


/**
 * A simple {@link Fragment} subclass.
 */
public class StockFragment extends Fragment {
    List<Stock> stocks = new ArrayList<Stock>();

    StringBuffer stringBuffer;
    MYRecAdapter mmAdapter;

    public StockFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_stock, container, false);
        RecyclerView recyclerView = (RecyclerView) view.findViewById(R.id.rv_stock);
        getStock();

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getContext());
        // linearLayoutManager.setOrientation(1);
        recyclerView.setLayoutManager(linearLayoutManager);


        mmAdapter = new MYRecAdapter(getContext(), stocks);
        recyclerView.setAdapter(mmAdapter);

        return view;
    }

    private List<Stock> getStock() {
        Resources resources = getResources();
        stringBuffer=new StringBuffer();
        String[] sinastockcode = resources.getStringArray(R.array.stockcodes_sina);
        for (int i = 0; i < 20; i++) {
            stringBuffer.append(sinastockcode[i].trim() + ",");
        }
        new AsyncTask<String, Integer, Map<String, Stock>>() {

            @Override
            protected Map<String, Stock> doInBackground(String... params) {
                Common common = new Common();
                Map<String, Stock> stockMap = common.loadStocks(params[0]);
                return stockMap;
            }

            @Override
            protected void onPostExecute(Map<String, Stock> stringStockMap) {
                super.onPostExecute(stringStockMap);
                stocks.addAll(stringStockMap.values());
                if (mmAdapter != null) {
                    mmAdapter.notifyDataSetChanged();
                }
            }
        }.execute(stringBuffer.toString());
        return stocks;
    }


}
class MYRecAdapter extends RecyclerView.Adapter {
    Context context;
    List<Stock> stocks;

    public MYRecAdapter(Context context, List<Stock> stocks) {
        this.context = context;
        this.stocks = stocks;
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        //   View view=View.inflate(context,R.layout.stock_item,null);
        View view = LayoutInflater.from(context).inflate(R.layout.stock_item1, parent, false);

        MHolder myHolder = new MHolder(view);

        return myHolder;
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        MHolder myHolder = (MHolder) holder;
        myHolder.stockname.setText(stocks.get(position).getStockname());
        myHolder.stockcode.setText(stocks.get(position).getStockcode());
        myHolder.nowprice.setText(stocks.get(position).getNowprice());
        myHolder.nowchange.setText(stocks.get(position).getNowchange());

    }

    @Override
    public int getItemCount() {
        return stocks.size();
    }

    class MHolder extends RecyclerView.ViewHolder {
        TextView stockname;
        TextView stockcode;
        TextView nowprice;
        TextView nowchange;

        public MHolder(View itemView) {
            super(itemView);
            stockname = (TextView) itemView.findViewById(R.id.stockname);
            stockcode = (TextView) itemView.findViewById(R.id.stockcode);
            nowprice = (TextView) itemView.findViewById(R.id.nowprice);
            nowchange = (TextView) itemView.findViewById(R.id.nowchange);
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Stock stock = stocks.get(getAdapterPosition());
                    Intent intent = new Intent(context, DetailActivity.class);
                    intent.putExtra("stockcode", stock.getStockcode());
                    intent.putExtra("sinastockcode", stock.getSinastockcode());
                    context.startActivity(intent);
                }
            });
        }
    }
}





