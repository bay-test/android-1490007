package com.example.stock;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;


public class EditStockActivity extends AppCompatActivity {
    editAdapter adapter;
    List<Stock> stocks=new ArrayList<>();
    Handler handler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_stock);
        getSupportActionBar().hide();


        RecyclerView recyclerView= (RecyclerView) findViewById(R.id.rv_stock);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        loadStocks();

        adapter=new editAdapter(this,stocks);
        recyclerView.setAdapter(adapter);

        final SwipeRefreshLayout swipeRefreshLayout= (SwipeRefreshLayout)findViewById(R.id.refresh);

        swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                loadStocks();
                //   myAdapter.notifyDataSetChanged();
                swipeRefreshLayout.setRefreshing(false);
            }
        });}


    private void loadStocks() {
        stocks.clear();
        //  List<Stock> s=new ArrayList<>();
        MySQLiteOpenHelper mySQLiteOpenHelper=new MySQLiteOpenHelper(this,1);

        SQLiteDatabase sqLiteDatabase=mySQLiteOpenHelper.getWritableDatabase();

        Cursor cursor=sqLiteDatabase.query("stock",new String[]{"_id","stockcode","stockname","sinastockcode"},null,null,null,null,null);
        StringBuffer queryCodes=new StringBuffer();
        while (cursor.moveToNext()){
//            Stock stock=new Stock();
//            stock.setNowchange("10%");
//            stock.setNowprice("3.98");
//            stock.set_id(cursor.getString(0));
//            stock.setStockcode(cursor.getString(1));
//            stock.setStockname(cursor.getString(2));
//            stock.setSinastockcode(cursor.getString(3));
//            stocks.add(stock);
            queryCodes.append(cursor.getString(3).trim()+",");

        }
        sqLiteDatabase.close();
        new AsyncTask<String, Integer, Map<String, Stock>>() {
            @Override
            protected Map<String, Stock> doInBackground(String... params) {
                Common common=new Common();


                return common.loadStocks(params[0]);
            }

            @Override
            protected void onPostExecute(Map<String, Stock> stringStockMap) {
                super.onPostExecute(stringStockMap);
                stocks.addAll(stringStockMap.values());
                if (adapter!=null){
                    adapter.notifyDataSetChanged();
                }
            }
        }.execute(queryCodes.toString());


    }



    public void backHome(View view){
        finish();
    }


}

class editAdapter extends RecyclerView.Adapter {
    Context context;
    List<Stock> stocks;

    public editAdapter(Context context, List<Stock> stocks) {
        this.context = context;
        this.stocks = stocks;
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.stock_item, parent, false);

        Holder Holder = new Holder(view);

        return Holder;
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        Holder Holder = (Holder) holder;
        Holder.stockname.setText(stocks.get(position).getStockname());
        Holder.stockcode.setText(stocks.get(position).getStockcode());
        Holder.nowprice.setText(stocks.get(position).getNowprice());
        Holder.nowchange.setText(stocks.get(position).getNowchange());
    }

    @Override
    public int getItemCount() {
        return stocks.size();
    }


    class Holder extends RecyclerView.ViewHolder {
        TextView stockname;
        TextView stockcode;
        TextView nowprice;
        TextView nowchange;

        public Holder(View itemView) {
            super(itemView);
            stockname = (TextView) itemView.findViewById(R.id.stockname);
            stockcode = (TextView) itemView.findViewById(R.id.stockcode);
            nowprice = (TextView) itemView.findViewById(R.id.nowprice);
            nowchange = (TextView) itemView.findViewById(R.id.nowchange);
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Stock stock = stocks.get(getAdapterPosition());
                    Intent intent = new Intent(context, DetailActivity.class);
                    intent.putExtra("stockcode", stock.getStockcode());
                    intent.putExtra("sinastockcode", stock.getSinastockcode());
                    context.startActivity(intent);
                }
            });
            itemView.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View view) {
                    MySQLiteOpenHelper mysql=new MySQLiteOpenHelper(context,1);
                    SQLiteDatabase sql=mysql.getWritableDatabase();
                    sql.delete("stock","sinastockcode=?",new String[]{stocks.get(getAdapterPosition()).getSinastockcode().trim()});
                    sql.close();

                    Toast.makeText(context,"删除成功。",Toast.LENGTH_LONG).show();

                    stocks.remove(getAdapterPosition());

                    editAdapter.this.notifyDataSetChanged();
                    return false;
                }
            });

        };
    }

}


