package com.example.stock;

/**
 * Created by 10333 on 2017/6/14.
 */

public class Stock {

    String stockname;
    String stockcode;
    String nowprice;
    String nowchange;
    String sinastockcode;
    String _id;

    String buy_price1;
    String buy_count1;
    String sale_price1;
    String sale_count1;

    String buy_price2;
    String buy_count2;
    String sale_price2;
    String sale_count2;

    String buy_price3;
    String buy_count3;
    String sale_price3;
    String sale_count3;

    String buy_price4;
    String buy_count4;
    String sale_price4;
    String sale_count4;

    String buy_price5;
    String buy_count5;
    String sale_price5;
    String sale_count5;

    public String getBuy_price2() {
        return buy_price2;
    }

    public void setBuy_price2(String buy_price2) {
        this.buy_price2 = buy_price2;
    }

    public String getBuy_count2() {
        return buy_count2;
    }

    public void setBuy_count2(String buy_count2) {
        this.buy_count2 = buy_count2;
    }

    public String getSale_price2() {
        return sale_price2;
    }

    public void setSale_price2(String sale_price2) {
        this.sale_price2 = sale_price2;
    }

    public String getSale_count2() {
        return sale_count2;
    }

    public void setSale_count2(String sale_count2) {
        this.sale_count2 = sale_count2;
    }

    public String getBuy_price3() {
        return buy_price3;
    }

    public void setBuy_price3(String buy_price3) {
        this.buy_price3 = buy_price3;
    }

    public String getBuy_count3() {
        return buy_count3;
    }

    public void setBuy_count3(String buy_count3) {
        this.buy_count3 = buy_count3;
    }

    public String getSale_price3() {
        return sale_price3;
    }

    public void setSale_price3(String sale_price3) {
        this.sale_price3 = sale_price3;
    }

    public String getSale_count3() {
        return sale_count3;
    }

    public void setSale_count3(String sale_count3) {
        this.sale_count3 = sale_count3;
    }

    public String getBuy_price4() {
        return buy_price4;
    }

    public void setBuy_price4(String buy_price4) {
        this.buy_price4 = buy_price4;
    }

    public String getBuy_count4() {
        return buy_count4;
    }

    public void setBuy_count4(String buy_count4) {
        this.buy_count4 = buy_count4;
    }

    public String getSale_price4() {
        return sale_price4;
    }

    public void setSale_price4(String sale_price4) {
        this.sale_price4 = sale_price4;
    }

    public String getSale_count4() {
        return sale_count4;
    }

    public void setSale_count4(String sale_count4) {
        this.sale_count4 = sale_count4;
    }

    public String getBuy_price5() {
        return buy_price5;
    }

    public void setBuy_price5(String buy_price5) {
        this.buy_price5 = buy_price5;
    }

    public String getBuy_count5() {
        return buy_count5;
    }

    public void setBuy_count5(String buy_count5) {
        this.buy_count5 = buy_count5;
    }

    public String getSale_price5() {
        return sale_price5;
    }

    public void setSale_price5(String sale_price5) {
        this.sale_price5 = sale_price5;
    }

    public String getSale_count5() {
        return sale_count5;
    }

    public void setSale_count5(String sale_count5) {
        this.sale_count5 = sale_count5;
    }

    String today;
    String yestoday;
    String maxprice;
    String minprice;
    String date;
    String time;

    public String getToday() {
        return today;
    }

    public void setToday(String today) {
        this.today = today;
    }

    public String getYestoday() {
        return yestoday;
    }

    public void setYestoday(String yestoday) {
        this.yestoday = yestoday;
    }

    public String getMaxprice() {
        return maxprice;
    }

    public void setMaxprice(String maxprice) {
        this.maxprice = maxprice;
    }

    public String getMinprice() {
        return minprice;
    }

    public void setMinprice(String minprice) {
        this.minprice = minprice;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getTrade_g() {
        return trade_g;
    }

    public void setTrade_g(String trade_g) {
        this.trade_g = trade_g;
    }

    public String getTrade_p() {
        return trade_p;
    }

    public void setTrade_p(String trade_p) {
        this.trade_p = trade_p;
    }

    String trade_g;
    String trade_p;

    public String getBuy_price1() {
        return buy_price1;
    }

    public void setBuy_price1(String buy_price1) {
        this.buy_price1 = buy_price1;
    }

    public String getBuy_count1() {
        return buy_count1;
    }

    public void setBuy_count1(String buy_count1) {
        this.buy_count1 = buy_count1;
    }

    public String getSale_price1() {
        return sale_price1;
    }

    public void setSale_price1(String sale_price1) {
        this.sale_price1 = sale_price1;
    }

    public String getSale_count1() {
        return sale_count1;
    }

    public void setSale_count1(String sale_count1) {
        this.sale_count1 = sale_count1;
    }

    public void setStockname(String stockname) {
        this.stockname = stockname;
    }

    public void setStockcode(String stockcode) {
        this.stockcode = stockcode;
    }

    public void setNowprice(String nowprice) {
        this.nowprice = nowprice;
    }

    public void setNowchange(String nowchange) {
        this.nowchange = nowchange;
    }

    public void setSinastockcode(String sinastockcode) {
        this.sinastockcode = sinastockcode;
    }

    public void set_id(String _id) {
        this._id = _id;
    }

    public String getStockname() {
        return stockname;
    }

    public String getStockcode() {
        return stockcode;
    }

    public String getNowprice() {
        return nowprice;
    }

    public String getNowchange() {
        return nowchange;
    }

    public String getSinastockcode() {
        return sinastockcode;
    }

    public String get_id() {
        return _id;
    }
}