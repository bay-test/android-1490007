package com.example.stock;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.FragmentTabHost;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.TabHost;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.DecimalFormat;

/**
 * Created by 10333 on 2017/6/14.
 */

public class DetailActivity extends AppCompatActivity{

    TextView stockname;
    TextView buy_price1;
    TextView buy_count1;
    TextView sale_price1;
    TextView sale_count1;

    TextView buy_price2;
    TextView buy_count2;
    TextView sale_price2;
    TextView sale_count2;

    TextView buy_price3;
    TextView buy_count3;
    TextView sale_price3;
    TextView sale_count3;

    TextView buy_price4;
    TextView buy_count4;
    TextView sale_price4;
    TextView sale_count4;

    TextView buy_price5;
    TextView buy_count5;
    TextView sale_price5;
    TextView sale_count5;

    TextView today;
    TextView yestoday;
    TextView maxprice;
    TextView minprice;
    TextView date;
    TextView time;
    TextView trade_g;
    TextView trade_p;

    String stockcode;
    String sinastockcode;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);
        getSupportActionBar().hide();
/*
Intent intent = getIntent();
        sinastockcode =  intent.getStringExtra("sinastockcode");
*/

        Intent intent=getIntent();
        stockcode=intent.getStringExtra("stockcode");
        sinastockcode=intent.getStringExtra("sinastockcode");

        Toast.makeText(this,stockcode+"---"+sinastockcode,Toast.LENGTH_LONG).show();
        FragmentTabHost fragmentTabHost= (FragmentTabHost) findViewById(android.R.id.tabhost);
        fragmentTabHost.setup(this,getSupportFragmentManager(),R.id.realtabcontent);


        TabHost.TabSpec tabSpecfen=fragmentTabHost.newTabSpec("fen");
        tabSpecfen.setIndicator("分时K");
        Bundle bundle=new Bundle();
        bundle.putString("sinastockcode",sinastockcode);
        fragmentTabHost.addTab(tabSpecfen,fenFragment.class,bundle);

        TabHost.TabSpec tabSpecri=fragmentTabHost.newTabSpec("ri");
        tabSpecri.setIndicator("日K");

        fragmentTabHost.addTab(tabSpecri,riFragment.class,bundle);


        TabHost.TabSpec tabSpeczhou=fragmentTabHost.newTabSpec("zhou");
        tabSpeczhou.setIndicator("周K");
        fragmentTabHost.addTab(tabSpeczhou,zhouFragment.class,bundle);


        TabHost.TabSpec tabSpecyue=fragmentTabHost.newTabSpec("yue");
        tabSpecyue.setIndicator("月K");
        fragmentTabHost.addTab(tabSpecyue,yueFragment.class,bundle);


        stockname= (TextView) findViewById(R.id.stockname);
        buy_price1= (TextView) findViewById(R.id.buy_price1);
        buy_count1 = (TextView) findViewById(R.id.buy_count1);
        sale_price1= (TextView) findViewById(R.id.sale_price1);
        sale_count1= (TextView) findViewById(R.id.sale_count1);

        buy_price2= (TextView) findViewById(R.id.buy_price2);
        buy_count2 = (TextView) findViewById(R.id.buy_count2);
        sale_price2= (TextView) findViewById(R.id.sale_price2);
        sale_count2= (TextView) findViewById(R.id.sale_count2);


        buy_price3= (TextView) findViewById(R.id.buy_price3);
        buy_count3 = (TextView) findViewById(R.id.buy_count3);
        sale_price3= (TextView) findViewById(R.id.sale_price3);
        sale_count3= (TextView) findViewById(R.id.sale_count3);

        buy_price4= (TextView) findViewById(R.id.buy_price4);
        buy_count4 = (TextView) findViewById(R.id.buy_count4);
        sale_price4= (TextView) findViewById(R.id.sale_price4);
        sale_count4= (TextView) findViewById(R.id.sale_count4);

        buy_price5= (TextView) findViewById(R.id.buy_price5);
        buy_count5 = (TextView) findViewById(R.id.buy_count5);
        sale_price5= (TextView) findViewById(R.id.sale_price5);
        sale_count5= (TextView) findViewById(R.id.sale_count5);

        today = (TextView) findViewById(R.id.today);
        yestoday = (TextView) findViewById(R.id.yestoday);
        maxprice = (TextView) findViewById(R.id.maxprice);
        minprice = (TextView) findViewById(R.id.minprice);
        date = (TextView) findViewById(R.id.date);
        time = (TextView) findViewById(R.id.time);
        trade_g = (TextView) findViewById(R.id.trade_g);
        trade_p = (TextView) findViewById(R.id.trade_p);


        final ProgressDialog progressDialog=new ProgressDialog(this);
        progressDialog.setMessage("玩命加载中.....");
        progressDialog.setCancelable(false);
        progressDialog.show();



        new AsyncTask<Void,Integer,Stock>(){


            @Override
            protected Stock doInBackground(Void... voids) {
                Stock stock=new Stock();

                try {
                    URL url = new URL("http://hq.sinajs.cn/list=" + sinastockcode.trim());
                    HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
                    httpURLConnection.setRequestMethod("GET");
                    httpURLConnection.connect();
                    if (httpURLConnection.getResponseCode()==200){
                        InputStream inputStream=httpURLConnection.getInputStream();
                        final ByteArrayOutputStream byteArrayOutputStream=new ByteArrayOutputStream();

                        byte[] b=new byte[1024];
                        int len=-1;
                        while ((len = inputStream.read(b))!=-1){
                            byteArrayOutputStream.write(b,0,len);
                        }
                        String result=byteArrayOutputStream.toString("GBK");
                        //   Toast.makeText(DetailActivity.this,""+result,Toast.LENGTH_LONG).show();
                        Log.e("tag", "doInBackground: ========="+result );
                        inputStream.close();
                        byteArrayOutputStream.close();

                        String [] stockArray=result.split("\"")[1].split(",");
                        stock.setStockname(stockArray[0]);
                        stock.setBuy_price1(stockArray[10]);
                        stock.setBuy_count1(stockArray[11]);
                        stock.setBuy_price2(stockArray[12]);
                        stock.setBuy_count2(stockArray[13]);
                        stock.setBuy_price3(stockArray[14]);
                        stock.setBuy_count3(stockArray[15]);
                        stock.setBuy_price4(stockArray[16]);
                        stock.setBuy_count4(stockArray[17]);
                        stock.setBuy_price5(stockArray[18]);
                        stock.setBuy_count5(stockArray[19]);

                        stock.setSale_price1(stockArray[20]);
                        stock.setSale_count1(stockArray[21]);
                        stock.setSale_price2(stockArray[22]);
                        stock.setSale_count2(stockArray[23]);
                        stock.setSale_price3(stockArray[24]);
                        stock.setSale_count3(stockArray[25]);
                        stock.setSale_price4(stockArray[26]);
                        stock.setSale_count4(stockArray[27]);
                        stock.setSale_price5(stockArray[28]);
                        stock.setSale_count5(stockArray[29]);


                        stock.setToday(stockArray[1]);
                        stock.setYestoday(stockArray[2]);
                        stock.setMaxprice(stockArray[4]);
                        stock.setMinprice(stockArray[5]);
                        stock.setDate(stockArray[30]);
                        stock.setTime(stockArray[31]);
                        stock.setTrade_g(stockArray[9]);
                        stock.setTrade_p(stockArray[8]);


                    }
                    httpURLConnection.disconnect();


                } catch (IOException e) {
                    e.printStackTrace();
                    progressDialog.dismiss();
                }



                return stock;
            }

            @Override
            protected void onPostExecute(Stock stock) {

                super.onPostExecute(stock);

                stockname.setText(stock.getStockname());
                buy_price1.setText(stock.getBuy_price1());
                buy_count1.setText(stock.getBuy_count1());
                sale_price1.setText(stock.getSale_price1());
                sale_count1.setText(stock.getSale_count1());

                buy_price2.setText(stock.getBuy_price2());
                buy_count2.setText(stock.getBuy_count2());
                sale_price2.setText(stock.getSale_price2());
                sale_count2.setText(stock.getSale_count2());

                buy_price3.setText(stock.getBuy_price3());
                buy_count3.setText(stock.getBuy_count3());
                sale_price3.setText(stock.getSale_price3());
                sale_count3.setText(stock.getSale_count3());
                buy_price4.setText(stock.getBuy_price4());
                buy_count4.setText(stock.getBuy_count4());
                sale_price4.setText(stock.getSale_price4());
                sale_count4.setText(stock.getSale_count4());
                buy_price5.setText(stock.getBuy_price5());
                buy_count5.setText(stock.getBuy_count5());
                sale_price5.setText(stock.getSale_price5());
                sale_count5.setText(stock.getSale_count5());


                today.setText(stock.getToday());
                yestoday.setText(stock.getYestoday());
                maxprice.setText(stock.getMaxprice());
                minprice.setText(stock.getMinprice());
                date.setText(stock.getDate());
                time.setText(stock.getTime());

                float gusu = Float.valueOf(stock.getTrade_g());
                DecimalFormat decimalFormat = new DecimalFormat("0.00");
                String regusu =  decimalFormat.format(gusu/10000);

                trade_g.setText(regusu+"万股");

                float jine = Float.valueOf(stock.getTrade_p());
                String rejine =  decimalFormat.format(jine/10000);

                trade_p.setText(rejine+"万元");

                progressDialog.dismiss();
            }
        }.execute();


    }
    public  void backHome(View view){
        finish();
    }
}
