package com.gitonway.myshares;

import android.util.Log;

import com.gitonway.myshares.common.common;

import org.junit.Test;

import static org.junit.Assert.*;

/**
 * Example local unit test, which will execute on the development machine (host).
 *
 * @see <a href="http://d.android.com/tools/testing">Testing documentation</a>
 */
public class ExampleUnitTest {
    private static final String TAG ="TEXT" ;

    @Test
    public void addition_isCorrect() throws Exception {
        //assertEquals(4, 2 + 2);
        common  cnn=new common();
        String URL=("http://image.sinajs.cn/newchart/daily/n/sz000892.gif");
        byte[] B=cnn.dataStocks(URL);
       // Log.e(TAG, "addition_isCorrect:================== "+B.length);
        System.out.println("addition_isCorrect:================== "+B.length);
    }
}