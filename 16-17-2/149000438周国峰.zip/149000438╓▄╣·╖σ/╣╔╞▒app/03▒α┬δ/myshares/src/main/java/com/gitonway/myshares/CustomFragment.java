package com.gitonway.myshares;


import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Bundle;

import android.support.v4.app.Fragment;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;


import com.gitonway.myshares.common.common;
import com.gitonway.myshares.detal.DetalActivity;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static android.support.v7.widget.LinearLayoutManager.VERTICAL;


/**
 * A simple {@link Fragment} subclass.
 */
public class    CustomFragment extends Fragment {
    private static final String TAG ="ByteArrayOutputStream" ;
    List<Stock> stock=new ArrayList<Stock>();
    Myadapter myadapter;
 StringBuffer queryCodes=new StringBuffer();

    public CustomFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view=inflater.inflate(R.layout.fragment_custom, container, false);
        RecyclerView recyclerView= (RecyclerView) view.findViewById(R.id.rv_mine);
        getStock();

        final SwipeRefreshLayout swipe= (SwipeRefreshLayout) view.findViewById(R.id.swipe);
        swipe.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
             getStock();
                myadapter.notifyDataSetChanged();
                swipe.setRefreshing(false);
            }
        });
        LinearLayoutManager layoutmanager=new LinearLayoutManager(getContext());
        layoutmanager.setOrientation(VERTICAL);
        recyclerView.setLayoutManager(layoutmanager);
         myadapter=new Myadapter(getContext(),stock);
        recyclerView.setAdapter(myadapter);
        return view;
    }

    @Override
    public void onResume() {
        super.onResume();

        myadapter.notifyDataSetChanged();
    }

    public void refresh(){
    getStock();
    myadapter.notifyDataSetChanged();
}
    private List<Stock> getStock() {
        stock.clear();
        MySQLiteOpenHelper ms=new MySQLiteOpenHelper(getContext(),1);
        SQLiteDatabase sql= ms.getWritableDatabase();
        Cursor cursor=sql.query("stock",new String[]{"_id","stockcodes","stockcodes_sina","stockname"},null,null,null,null,null);
        StringBuffer queryCodes=new StringBuffer();
        while (cursor.moveToNext()){

            queryCodes.append(cursor.getString(2)+",");


        }
        sql.close();
        new AsyncTask<String,Integer,Map<String,Stock>>(){

            @Override
            protected Map<String, Stock> doInBackground(String... params) {
                common cn=new common();
                Map<String, Stock> stockmap=cn.loadStocks(params[0]);
                return stockmap;
            } @Override
            protected void onPostExecute(Map<String, Stock> stringStockMap) {
                super.onPostExecute(stringStockMap);
                stock.addAll(stringStockMap.values());
                if (myadapter!=null){
                    myadapter.notifyDataSetChanged();
                }

            }
        }.execute(queryCodes.toString().trim());


        return stock;
    }

}
class Myadapter extends RecyclerView.Adapter {
    Context context;
    List<Stock> stock;

    public Myadapter(Context context, List<Stock> stock) {
        this.context=context;
        this.stock=stock;
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view=LayoutInflater.from(context).inflate(R.layout.fragment_item,parent,false);
        MyViewHolder myview=new MyViewHolder(view);
        return myview;
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        MyViewHolder mvh= (MyViewHolder) holder;
        mvh.tv_name.setText(stock.get(position).getStockname());
        mvh.tv_code.setText(stock.get(position).getStockcodes());
        mvh.tv_nowprice.setText(stock.get(position).getStocknowprice());
        mvh.tv_nowchange.setText(stock.get(position).getNowchange()+"%");
        if (Float.valueOf(stock.get(position).getNowchange())>=0){
            mvh.tv_nowprice.setTextColor(Color.GREEN);
            mvh.tv_nowchange.setBackgroundColor(Color.GREEN);
        }else {
            mvh.tv_nowprice.setTextColor(Color.RED);
            mvh.tv_nowchange.setBackgroundColor(Color.RED);
        }
        mvh.tv_name.setTextColor(Color.WHITE);
        mvh.tv_nowchange.setTextColor(Color.WHITE);

}

    @Override
    public int getItemCount() {
        return stock.size();
    }

    class MyViewHolder extends RecyclerView.ViewHolder {
        TextView tv_name;
        TextView tv_code;
        TextView tv_nowprice;
        TextView tv_nowchange;
        public MyViewHolder(View itemView) {
            super(itemView);
            tv_name= (TextView) itemView.findViewById(R.id.tv_name);
            tv_code= (TextView) itemView.findViewById(R.id.tv_code);
            tv_nowprice= (TextView) itemView.findViewById(R.id.tv_nowprice);
            tv_nowchange= (TextView) itemView.findViewById(R.id.tv_nowchange);
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    Intent intent=new Intent(context,DetalActivity.class);
                    intent.putExtra("stockcode", stock.get(getAdapterPosition()).getStockcodes());
                    intent.putExtra("stockcode_sina", stock.get(getAdapterPosition()).getStockcodes_sina());
                    context.startActivity(intent);

                }
            });

        }
    }

}

