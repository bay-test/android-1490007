package com.gitonway.myshares;

import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.gitonway.myshares.common.common;
import com.gitonway.myshares.detal.DetalActivity;
import com.gitonway.myshares.mainfragment.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static android.support.v7.widget.LinearLayoutManager.VERTICAL;

public class EditActivity extends AppCompatActivity {
    Madapter myadapter;
    List<Stock> stock=new ArrayList<>();
    StringBuffer stringBuffer = new StringBuffer();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit);
        Handler handle = new Handler(new Handler.Callback() {
            @Override
            public boolean handleMessage(Message msg) {
                if(myadapter != null){
                    getStock();
                    myadapter.notifyDataSetChanged();
                }

                return false;
            }
        });
        RecyclerView recyclerView= (RecyclerView)findViewById(R.id.rv_edit);
        getStock();
        LinearLayoutManager layoutmanager=new LinearLayoutManager(this);
        layoutmanager.setOrientation(VERTICAL);
        recyclerView.setLayoutManager(layoutmanager);
        myadapter=new Madapter(EditActivity.this,stock,handle);
        recyclerView.setAdapter(myadapter);
    }
    public void iv_back(View view){
        finish();
    }

    private List<Stock> getStock() {
        stock.clear();
        MySQLiteOpenHelper ms=new MySQLiteOpenHelper(EditActivity.this,1);
        SQLiteDatabase sql= ms.getWritableDatabase();
        Cursor cursor=sql.query("stock",new String[]{"_id","stockcodes","stockcodes_sina","stockname"},null,null,null,null,null);
        while (cursor.moveToNext()){
            stringBuffer.append(cursor.getString(2)+",");
        }
        sql.close();
        new AsyncTask<String,Integer,Map<String, Stock>>(){
            @Override
            protected Map<String, Stock> doInBackground(String... params) {
                common com = new common();
                Map<String, Stock> stockMap = com.loadStocks(params[0]);
                return stockMap;
            }
            @Override
            protected void onPostExecute(Map<String, Stock> stringStockMap) {
                super.onPostExecute(stringStockMap);
                stock.addAll(stringStockMap.values());
                if (myadapter!=null){
                    myadapter.notifyDataSetChanged();
                }
            }
        }.execute(stringBuffer.toString());
        return stock;

    }
}
class Madapter extends RecyclerView.Adapter {
    Context context;
    List<Stock> stock;
    Handler handle;



    public Madapter(Context context, List<Stock> stock, Handler handle) {
        this.context=context;
        this.stock=stock;
        this.handle = handle;

    }
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(context).inflate(R.layout.fragment_item1,parent,false);
        MyViewHolder myview=new MyViewHolder(view);
        return myview;
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        MyViewHolder mvh= (MyViewHolder) holder;
        mvh.tv_name.setText(stock.get(position).getStockname());
        mvh.tv_code.setText(stock.get(position).getStockcodes());
        mvh.tv_nowprice.setText(stock.get(position).getStocknowprice());
        mvh.tv_nowchange.setText(stock.get(position).getNowchange());
        if (Float.valueOf(stock.get(position).getNowchange())>=0){
            mvh.tv_nowprice.setTextColor(Color.GREEN);
            mvh.tv_nowchange.setBackgroundColor(Color.GREEN);
        }else {
            mvh.tv_nowprice.setTextColor(Color.RED);
            mvh.tv_nowchange.setBackgroundColor(Color.RED);
        }
        mvh.tv_name.setTextColor(Color.WHITE);
        mvh.tv_nowchange.setTextColor(Color.WHITE);

    }

    @Override
    public int getItemCount() {
        return stock.size();
    }

    class MyViewHolder extends RecyclerView.ViewHolder {
        TextView tv_name;
        TextView tv_code;
        TextView tv_nowprice;
        TextView tv_nowchange;
        public MyViewHolder(View itemView) {
            super(itemView);
            tv_name= (TextView) itemView.findViewById(R.id.tv_name);
            tv_code= (TextView) itemView.findViewById(R.id.tv_code);
            tv_nowprice= (TextView) itemView.findViewById(R.id.tv_nowprice);
            tv_nowchange= (TextView) itemView.findViewById(R.id.tv_nowchange);
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    Intent intent=new Intent(context,DetalActivity.class);
                    intent.putExtra("stockcode", stock.get(getAdapterPosition()).getStockcodes());
                    intent.putExtra("stockcode_sina", stock.get(getAdapterPosition()).getStockcodes_sina());
                    Toast.makeText(context,"长按删除股票！！！", Toast.LENGTH_SHORT).show();
                    context.startActivity(intent);

                }
            });

itemView.setOnLongClickListener(new View.OnLongClickListener() {
    @Override
    public boolean onLongClick(View v) {
        MySQLiteOpenHelper ms=new MySQLiteOpenHelper(context,1);
        SQLiteDatabase sql= ms.getWritableDatabase();
        sql.delete("stock","stockcodes_sina=?",new String[]{stock.get(getAdapterPosition()).getStockcodes_sina().trim()});
        sql.close();
        Toast.makeText(context,"删除成功！！！", Toast.LENGTH_SHORT).show();

        stock.remove(getAdapterPosition());
        Madapter.this.notifyDataSetChanged();
        return false;
    }
});
        }
    }

}