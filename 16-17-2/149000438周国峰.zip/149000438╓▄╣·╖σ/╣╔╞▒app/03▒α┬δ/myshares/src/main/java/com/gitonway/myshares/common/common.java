package com.gitonway.myshares.common;

import android.util.Log;

import com.gitonway.myshares.Stock;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by zxc94 on 2017/6/12.
 */

public class common {
    private static final String TAG = "diziiziziiziziiziiziz";

    public Map<String, Stock> loadStocks(String sinaStockCodes) {
        Map<String, Stock> stocksMap = new HashMap<String, Stock>();
        try {
            String urlstr = "http://hq.sinajs.cn/list=" + sinaStockCodes;
            Log.e("tag", "loadStocks: "+urlstr );
            URL url = new URL(urlstr);
            HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
            httpURLConnection.connect();

            if (httpURLConnection.getResponseCode() == 200) {

                InputStream inputStream = httpURLConnection.getInputStream();
                ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();

                int len = -1;
                byte[] b = new byte[1024];
                while ((len = inputStream.read(b)) != -1) {
                    byteArrayOutputStream.write(b, 0, len);
                }
                String result = byteArrayOutputStream.toString("GBK");
                // Toast.makeText(DetailActivity.this, ""+result, Toast.LENGTH_SHORT).show();
               Log.e("tag", "doInBackground:================= " + result);

                byteArrayOutputStream.close();
                inputStream.close();
                httpURLConnection.disconnect();
                result = result.replace("var hq_str_", "");
                result = result.replace("\"", "");
                String[] stocks = result.split(";");
                for (String stock : stocks) {
                    String[] s = stock.split("=");
                    if(s.length<2){
                        continue;
                    }
                    String[] stockInfo = s[1].split(",");
                    Stock retStock = new Stock();
                    retStock.setStockname(stockInfo[0]);
                    retStock.setBuy_count(stockInfo[10]);
                    retStock.setBuy_price(stockInfo[11]);
                    retStock.setSala_count(stockInfo[20]);
                    retStock.setSala_price(stockInfo[21]);
                    retStock.setStocknowprice(stockInfo[3]);
                    float nowChange = (Float.valueOf(stockInfo[3])-Float.valueOf(stockInfo[2]))/Float.valueOf(stockInfo[2]);

                    DecimalFormat decimalFormat=new DecimalFormat("0.00");
                    String nowChangeStr = decimalFormat.format(nowChange*100);

                  retStock.setNowchange(nowChangeStr);
                    retStock.setStockcodes_sina(s[0]);
                    retStock.setStockcodes(s[0].replace("sh","").replace("sz",""));
                    stocksMap.put(s[0], retStock);


                }


            }


        } catch (Exception e) {
            e.printStackTrace();

        }


        return stocksMap;
    }
    public byte[] dataStocks(String sinaStockCodes){
       byte[] mybytes=null;

        try {
//            String urlstock=("http://image.sinajs.cn/newchart/daily/n/"+sinaStockCodes+".gif");
            URL url=new URL(sinaStockCodes);
      // Log.e(TAG, "dataStocks:-xxxx------------------------- "+sinaStockCodes );
           HttpURLConnection  httpURLConnection = (HttpURLConnection) url.openConnection();
            httpURLConnection .connect();
            if (httpURLConnection .getResponseCode()==200){
                InputStream inputstream=httpURLConnection .getInputStream();
                ByteArrayOutputStream bytearray=new ByteArrayOutputStream();
                int len=-1;
                byte[] b=new byte[512];
                  while ((len=inputstream.read(b))!=-1){
                        bytearray.write(b,0,len);
                         }
                mybytes= bytearray.toByteArray();
                bytearray.close();
                    inputstream.close();

            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return mybytes;
    }
}
