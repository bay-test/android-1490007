package com.gitonway.myshares;

import android.widget.TextView;

/**
 * Created by zxc94 on 2017/6/8.
 */
public class Stock {
    String stockcodes;
    String stockcodes_sina ;
    String stockname ;
    String stocknowprice;
    String nowchange;
    String _id;

    String buy_price;
    String buy_count;
    String sala_price;
    String sala_count;

    String buy_price1;
    String buy_count1;
    String sala_price1;
    String sala_count1;

    String buy_price2;
    String buy_count2;
    String sala_price2;
    String sala_count2;

    String buy_price3;
    String buy_count3;
    String sala_price3;
    String sala_count3;

    String buy_price4;
    String buy_count4;
    String sala_price4;
    String sala_count4;
    String icon;

    String sale_prices;
    String tv_time;
    String tv_begin;
    String tv_ok;
    String tv_teday;
    String tv_money;
    String high;
    String slow;
    String getmoney;
    String justmoney;
    String tv_shi;
    String tv_jin;

    public String get_id() {
        return _id;
    }

    public void set_id(String _id) {
        this._id = _id;
    }

    public String getStockcodes() {
        return stockcodes;
    }

    public void setStockcodes(String stockcodes) {
        this.stockcodes = stockcodes;
    }

    public String getStockcodes_sina() {
        return stockcodes_sina;
    }

    public void setStockcodes_sina(String stockcodes_sina) {
        this.stockcodes_sina = stockcodes_sina;
    }

    public String getStockname() {
        return stockname;
    }

    public void setStockname(String stockname) {
        this.stockname = stockname;
    }

    public String getStocknowprice() {
        return stocknowprice;
    }

    public void setStocknowprice(String stocknowprice) {
        this.stocknowprice = stocknowprice;
    }

    public String getNowchange() {
        return nowchange;
    }

    public void setNowchange(String nowchange) {
        this.nowchange = nowchange;
    }

    public String getBuy_price() {
        return buy_price;
    }

    public void setBuy_price(String buy_price) {
        this.buy_price = buy_price;
    }

    public String getBuy_count() {
        return buy_count;
    }

    public void setBuy_count(String buy_count) {
        this.buy_count = buy_count;
    }

    public String getSala_price() {
        return sala_price;
    }

    public void setSala_price(String sala_price) {
        this.sala_price = sala_price;
    }

    public String getSala_count() {
        return sala_count;
    }

    public void setSala_count(String sala_count) {
        this.sala_count = sala_count;
    }

    public String getIcon() {
        return icon;
    }

    public void setIcon(String icon) {
        this.icon = icon;
    }

    public String getBuy_price1() {
        return buy_price1;
    }

    public void setBuy_price1(String buy_price1) {
        this.buy_price1 = buy_price1;
    }

    public String getBuy_count1() {
        return buy_count1;
    }

    public void setBuy_count1(String buy_count1) {
        this.buy_count1 = buy_count1;
    }

    public String getSala_price1() {
        return sala_price1;
    }

    public void setSala_price1(String sala_price1) {
        this.sala_price1 = sala_price1;
    }

    public String getSala_count1() {
        return sala_count1;
    }

    public void setSala_count1(String sala_count1) {
        this.sala_count1 = sala_count1;
    }

    public String getBuy_price2() {
        return buy_price2;
    }

    public void setBuy_price2(String buy_price2) {
        this.buy_price2 = buy_price2;
    }

    public String getBuy_count2() {
        return buy_count2;
    }

    public void setBuy_count2(String buy_count2) {
        this.buy_count2 = buy_count2;
    }

    public String getSala_price2() {
        return sala_price2;
    }

    public void setSala_price2(String sala_price2) {
        this.sala_price2 = sala_price2;
    }

    public String getSala_count2() {
        return sala_count2;
    }

    public void setSala_count2(String sala_count2) {
        this.sala_count2 = sala_count2;
    }

    public String getBuy_price3() {
        return buy_price3;
    }

    public void setBuy_price3(String buy_price3) {
        this.buy_price3 = buy_price3;
    }

    public String getBuy_count3() {
        return buy_count3;
    }

    public void setBuy_count3(String buy_count3) {
        this.buy_count3 = buy_count3;
    }

    public String getSala_price3() {
        return sala_price3;
    }

    public void setSala_price3(String sala_price3) {
        this.sala_price3 = sala_price3;
    }

    public String getSala_count3() {
        return sala_count3;
    }

    public void setSala_count3(String sala_count3) {
        this.sala_count3 = sala_count3;
    }

    public String getBuy_price4() {
        return buy_price4;
    }

    public void setBuy_price4(String buy_price4) {
        this.buy_price4 = buy_price4;
    }

    public String getBuy_count4() {
        return buy_count4;
    }

    public void setBuy_count4(String buy_count4) {
        this.buy_count4 = buy_count4;
    }

    public String getSala_price4() {
        return sala_price4;
    }

    public void setSala_price4(String sala_price4) {
        this.sala_price4 = sala_price4;
    }

    public String getSala_count4() {
        return sala_count4;
    }

    public void setSala_count4(String sala_count4) {
        this.sala_count4 = sala_count4;
    }

    public String getSale_prices() {
        return sale_prices;
    }

    public void setSale_prices(String sale_prices) {
        this.sale_prices = sale_prices;
    }

    public String getTv_time() {
        return tv_time;
    }

    public void setTv_time(String tv_time) {
        this.tv_time = tv_time;
    }

    public String getTv_begin() {
        return tv_begin;
    }

    public void setTv_begin(String tv_begin) {
        this.tv_begin = tv_begin;
    }

    public String getTv_ok() {
        return tv_ok;
    }

    public void setTv_ok(String tv_ok) {
        this.tv_ok = tv_ok;
    }

    public String getTv_teday() {
        return tv_teday;
    }

    public void setTv_teday(String tv_teday) {
        this.tv_teday = tv_teday;
    }

    public String getTv_money() {
        return tv_money;
    }

    public void setTv_money(String tv_money) {
        this.tv_money = tv_money;
    }

    public String getHigh() {
        return high;
    }

    public void setHigh(String high) {
        this.high = high;
    }

    public String getSlow() {
        return slow;
    }

    public void setSlow(String slow) {
        this.slow = slow;
    }

    public String getGetmoney() {
        return getmoney;
    }

    public void setGetmoney(String getmoney) {
        this.getmoney = getmoney;
    }

    public String getJustmoney() {
        return justmoney;
    }

    public void setJustmoney(String justmoney) {
        this.justmoney = justmoney;
    }

    public String getTv_shi() {
        return tv_shi;
    }

    public void setTv_shi(String tv_shi) {
        this.tv_shi = tv_shi;
    }

    public String getTv_jin() {
        return tv_jin;
    }

    public void setTv_jin(String tv_jin) {
        this.tv_jin = tv_jin;
    }
}
