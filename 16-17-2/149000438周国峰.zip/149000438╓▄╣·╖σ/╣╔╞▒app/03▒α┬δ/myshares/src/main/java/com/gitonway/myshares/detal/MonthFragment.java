package com.gitonway.myshares.detal;


import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.widget.SwipeRefreshLayout;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.gitonway.myshares.R;
import com.gitonway.myshares.common.common;

/**
 * A simple {@link Fragment} subclass.
 */
public class MonthFragment extends Fragment {

ImageView iv_month;
    public MonthFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view=inflater.inflate(R.layout.fragment_month, container, false);
        iv_month= (ImageView) view.findViewById(R.id.iv_month);
        String stockcode_sina=getArguments().getString("stockcode_sina");

        new AsyncTask<String,Integer,byte[]>(){
            @Override
            protected byte[] doInBackground(String... params) {
                common con=new common();
                String urlstock=("http://image.sinajs.cn/newchart/monthly/n/"+params[0]+".gif");
                byte[] bb=con.dataStocks(urlstock);
                return bb;
            }

            @Override
            protected void onPostExecute(byte[] bytes) {
                super.onPostExecute(bytes);

                Bitmap bitmap= BitmapFactory.decodeByteArray(bytes,0,bytes.length,null);
                iv_month.setImageBitmap(bitmap);

            }
        }.execute(stockcode_sina);
        return view;
    }

}
