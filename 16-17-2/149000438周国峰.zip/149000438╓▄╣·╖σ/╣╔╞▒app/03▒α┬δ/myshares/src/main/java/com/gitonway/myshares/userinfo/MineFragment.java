package com.gitonway.myshares.userinfo;


import android.os.Bundle;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTabHost;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TabHost;

import com.gitonway.myshares.CustomFragment;
import com.gitonway.myshares.R;
import com.gitonway.myshares.userinfo.LoginFragment;
import com.gitonway.myshares.userinfo.RegFragment;


/**
 * A simple {@link Fragment} subclass.
 */
public class MineFragment extends Fragment {


    public MineFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view=inflater.inflate(R.layout.fragment_mine, container, false);
        FragmentTabHost fragmentTabHost= (FragmentTabHost) view.findViewById(android.R.id.tabhost);
        fragmentTabHost.setup(getActivity(),getChildFragmentManager(),R.id.realtabcontent);

        TabHost.TabSpec tabSpec=fragmentTabHost.newTabSpec("cust");
        tabSpec.setIndicator("注册");
        fragmentTabHost.addTab(tabSpec,RegFragment.class,null);

        TabHost.TabSpec tabSpec1=fragmentTabHost.newTabSpec("stock");
        tabSpec1.setIndicator("登录");
        fragmentTabHost.addTab(tabSpec1,LoginFragment.class,null);

        fragmentTabHost.getTabWidget().getChildAt(0).getLayoutParams().height=110;
        fragmentTabHost.getTabWidget().getChildAt(1).getLayoutParams().height=110;
        return view;
    }

}
