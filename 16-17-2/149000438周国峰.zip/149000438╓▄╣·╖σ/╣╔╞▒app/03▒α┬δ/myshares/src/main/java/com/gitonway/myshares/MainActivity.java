package com.gitonway.myshares;

import android.content.Intent;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.AnimationSet;
import android.view.animation.RotateAnimation;
import android.view.animation.ScaleAnimation;
import android.widget.RelativeLayout;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        RelativeLayout relativeLayout= (RelativeLayout) findViewById(R.id.activity_begin);

        AnimationSet animationSet=new AnimationSet(true);
        ScaleAnimation scaleAnimation=new ScaleAnimation(0,1,0,1, Animation.RELATIVE_TO_SELF,0.5f,Animation.RELATIVE_TO_SELF,0.5f);
        scaleAnimation.setDuration(2000);
        RotateAnimation rotateAnimation=new RotateAnimation(0,360,Animation.RELATIVE_TO_SELF,0.5f,Animation.RELATIVE_TO_SELF,0.5f);
        rotateAnimation.setDuration(2000);
        AlphaAnimation alphaAnimation=new AlphaAnimation(0,1);
        alphaAnimation.setDuration(2000);
//        getSupportActionBar().hide();
//        Animation animation=new TranslateAnimation(Animation.RELATIVE_TO_SELF,0.1f,Animation.RELATIVE_TO_SELF,iv_android.getMaxWidth(),Animation.RELATIVE_TO_SELF,iv_android.getMaxHeight(),Animation.RELATIVE_TO_SELF,0);
//        animation.setDuration(3000);
        animationSet.addAnimation(alphaAnimation);
        animationSet.addAnimation(rotateAnimation);
        animationSet.addAnimation(scaleAnimation);
        relativeLayout.startAnimation(animationSet);

        handler.sendMessageDelayed(handler.obtainMessage(1), 3000);
    }
    Handler handler= new Handler(new Handler.Callback() {
        @Override
        public boolean handleMessage(Message message) {
            if (message.what==1){
                Intent intent=new Intent(MainActivity.this,NewActivity.class);
                startActivity(intent);
                finish();
            }
            return true;
        }
    });


}
