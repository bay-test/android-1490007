package com.gitonway.myshares.mainfragment;


import android.content.ContentValues;

import android.content.res.Resources;

import android.database.sqlite.SQLiteDatabase;

import android.os.Bundle;

import android.support.v4.app.Fragment;

import android.support.v4.app.FragmentTabHost;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.TabHost;

import android.widget.Toast;

import com.gitonway.myshares.CustomFragment;
import com.gitonway.myshares.MySQLiteOpenHelper;
import com.gitonway.myshares.R;
import com.gitonway.myshares.Stock;

import java.util.HashMap;
import java.util.Map;


/**
 * A simple {@link Fragment} subclass.
 */
public class MkFragment extends Fragment {
Map<String,Stock> stockMap=new HashMap<>();
    CustomFragment customFragment;
    public MkFragment() {
        // Required empty public constructor
    }

    public void onAttachFragment(Fragment fragment) {
        super.onAttachFragment(fragment);
        if(fragment instanceof CustomFragment)
            customFragment= (CustomFragment) fragment;

    }

    @Override
    public View onCreateView(LayoutInflater inflater, final ViewGroup container,
                             Bundle savedInstanceState) {
        View view=inflater.inflate(R.layout.fragment_mk, container, false);
        FragmentTabHost fragmentTabHost= (FragmentTabHost) view.findViewById(android.R.id.tabhost);
        fragmentTabHost.setup(getActivity(),getChildFragmentManager(),R.id.realtabcontent);

        TabHost.TabSpec tabSpec=fragmentTabHost.newTabSpec("cust");
        tabSpec.setIndicator("自选");
        fragmentTabHost.addTab(tabSpec,CustomFragment.class,null);

        TabHost.TabSpec tabSpec1=fragmentTabHost.newTabSpec("stock");
        tabSpec1.setIndicator("沪深");
        fragmentTabHost.addTab(tabSpec1,StockFragment.class,null);

        fragmentTabHost.getTabWidget().getChildAt(0).getLayoutParams().height=110;
        fragmentTabHost.getTabWidget().getChildAt(1).getLayoutParams().height=110;
        final AutoCompleteTextView act= (AutoCompleteTextView) view.findViewById(R.id.tv_search);
        Resources resources=view.getResources();
        final String [] stockcodes=resources.getStringArray(R.array.stockcodes);
        final String [] stockname=resources.getStringArray(R.array.stocknames);
        final String [] stockcodes_sina=resources.getStringArray(R.array.stockcodes_sina);
        for (int i=0;i<stockcodes.length;i++){
            Stock stock=new Stock();
            stock.setStockname(stockname[i]);
            stock.setStockcodes(stockcodes[i]);
            stock.setStockcodes_sina(stockcodes_sina[i]);
            stockMap.put(stockcodes[i],stock);
        }


        ArrayAdapter aa=new ArrayAdapter(getContext(),R.layout.adapter,R.id.tv_view,stockcodes);
        act.setAdapter(aa);
act.setOnItemClickListener(new AdapterView.OnItemClickListener() {
    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        String stockcode=parent.getItemAtPosition(position).toString();
        Stock stock=stockMap.get(stockcode);
        MySQLiteOpenHelper mySQLiteOpenHelper=new MySQLiteOpenHelper(getContext(),1);
        ContentValues contentValues=new ContentValues();
        contentValues.put("stockcodes",stock.getStockcodes());
        contentValues.put("stockcodes_sina",stock.getStockcodes_sina());
        contentValues.put("stockname",stock.getStockname());

        SQLiteDatabase sqLiteDatabase=mySQLiteOpenHelper.getWritableDatabase();
        sqLiteDatabase.insert("stock",null,contentValues);
        act.setText("");
        customFragment.refresh();
        sqLiteDatabase.close();
        Toast.makeText(getContext(), "添加成功！", Toast.LENGTH_SHORT).show();
    }
});

        return view;
    }

}


