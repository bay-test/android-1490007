package com.gitonway.myshares.mainfragment;


import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;

import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Bundle;

import android.support.v4.app.Fragment;

import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.gitonway.myshares.R;
import com.gitonway.myshares.Stock;

import com.gitonway.myshares.common.common;
import com.gitonway.myshares.detal.DetalActivity;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static android.support.v7.widget.LinearLayoutManager.VERTICAL;


/**
 * A simple {@link Fragment} subclass.
 */
public class StockFragment extends Fragment {
    private static final String TAG = "StockFragment";
    List<Stock> stock=new ArrayList<Stock>();
    Myadapter myadapter;
    StringBuffer stringBuffer = new StringBuffer();
    public StockFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view=inflater.inflate(R.layout.fragment_stock, container, false);
            RecyclerView recyclerView= (RecyclerView) view.findViewById(R.id.rv_sh);
            getStock();
            LinearLayoutManager layoutmanager=new LinearLayoutManager(getContext());
            layoutmanager.setOrientation(VERTICAL);
            recyclerView.setLayoutManager(layoutmanager);
            myadapter=new Myadapter(getContext(),stock);
            recyclerView.setAdapter(myadapter);
            return view;
        }

    private List<Stock> getStock() {
        Resources resources=getResources();
       String[] stockcodes_sina=resources.getStringArray(R.array.stockcodes_sina);
        for (int i=0;i<50;i++){
            stringBuffer.append(stockcodes_sina[i]+",");
        }
        new AsyncTask<String,Integer,Map<String, Stock>>(){
            @Override
            protected Map<String, Stock> doInBackground(String... params) {
                common com = new common();
                Map<String, Stock> stockMap = com.loadStocks(params[0]);
                return stockMap;
            }
            @Override
            protected void onPostExecute(Map<String, Stock> stringStockMap) {
                super.onPostExecute(stringStockMap);
                stock.addAll(stringStockMap.values());
                if (myadapter!=null){
                    myadapter.notifyDataSetChanged();
                }
            }
        }.execute(stringBuffer.toString());
        return stock;

    }

}
class Myadapter extends RecyclerView.Adapter {
    Context context;
    List<Stock> stock;


    public Myadapter(Context context, List<Stock> stock) {
        this.context=context;
        this.stock=stock;

}
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view=LayoutInflater.from(context).inflate(R.layout.fragment_item1,parent,false);
       MyViewHolder myview=new MyViewHolder(view);
        return myview;
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        MyViewHolder mvh= (MyViewHolder) holder;
        mvh.tv_name.setText(stock.get(position).getStockname());
        mvh.tv_code.setText(stock.get(position).getStockcodes());
        mvh.tv_nowprice.setText(stock.get(position).getStocknowprice());
        mvh.tv_nowchange.setText(stock.get(position).getNowchange());
        if (Float.valueOf(stock.get(position).getNowchange())>=0){
            mvh.tv_nowprice.setTextColor(Color.GREEN);
            mvh.tv_nowchange.setBackgroundColor(Color.GREEN);
        }else {
            mvh.tv_nowprice.setTextColor(Color.RED);
            mvh.tv_nowchange.setBackgroundColor(Color.RED);
        }
        mvh.tv_name.setTextColor(Color.WHITE);
        mvh.tv_nowchange.setTextColor(Color.WHITE);
    }

    @Override
    public int getItemCount() {
        return stock.size();
    }

    class MyViewHolder extends RecyclerView.ViewHolder {
        TextView tv_name;
        TextView tv_code;
        TextView tv_nowprice;
        TextView tv_nowchange;
        public MyViewHolder(View itemView) {
            super(itemView);
            tv_name= (TextView) itemView.findViewById(R.id.tv_name);
            tv_code= (TextView) itemView.findViewById(R.id.tv_code);
            tv_nowprice= (TextView) itemView.findViewById(R.id.tv_nowprice);
            tv_nowchange= (TextView) itemView.findViewById(R.id.tv_nowchange);
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    Intent intent=new Intent(context,DetalActivity.class);
                    intent.putExtra("stockcode", stock.get(getAdapterPosition()).getStockcodes());
                    intent.putExtra("stockcode_sina", stock.get(getAdapterPosition()).getStockcodes_sina());
                    context.startActivity(intent);

                }
            });

        }
    }

}


