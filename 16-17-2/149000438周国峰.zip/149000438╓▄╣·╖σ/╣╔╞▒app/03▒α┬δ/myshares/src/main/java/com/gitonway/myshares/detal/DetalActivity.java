 package com.gitonway.myshares.detal;

import android.animation.FloatArrayEvaluator;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.AsyncTask;
import android.support.v4.app.FragmentTabHost;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TabHost;
import android.widget.TextView;

import com.gitonway.myshares.R;
import com.gitonway.myshares.Stock;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.DecimalFormat;

 public class DetalActivity extends AppCompatActivity {
     private static final String TAG = "DetalActivity";
     TextView stockname;
     TextView buy_price;
     TextView buy_count;
     TextView sala_price;
     TextView sala_count;

     TextView buy_price1;
     TextView buy_count1;
     TextView sala_price1;
     TextView sala_count1;

     TextView buy_price2;
     TextView buy_count2;
     TextView sala_price2;
     TextView sala_count2;

     TextView buy_price3;
     TextView buy_count3;
     TextView sala_price3;
     TextView sala_count3;

     TextView buy_price4;
     TextView buy_count4;
     TextView sala_price4;
     TextView sala_count4;

     TextView sale_prices;
     TextView tv_time;
     TextView tv_begin;
     TextView tv_ok;
     TextView tv_teday;
     TextView tv_money;
     TextView high;
     TextView slow;
     TextView getmoney;
     TextView justmoney;
     TextView tv_shi;
     TextView tv_jin;

     String stockcode_sina;

     FragmentTabHost fragmentTabHost;

     ImageView iv_day;

     @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detal);


        Log.e(TAG, "onCreate: ==============="+ stockcode_sina);
        final ProgressDialog progress=new ProgressDialog(this);
         progress.setMessage("数据加载中......");
         progress.show();
         Intent intent=getIntent();
         stockcode_sina=intent.getStringExtra("stockcode_sina").trim();
         iv_day= (ImageView) findViewById(R.id.iv_day);
         stockname= (TextView) findViewById(R.id.stockname);

         buy_price= (TextView) findViewById(R.id.buy_price);
        buy_count= (TextView) findViewById(R.id.buy_count);
        sala_price= (TextView) findViewById(R.id.sala_price);
        sala_count= (TextView) findViewById(R.id.sala_count);

         buy_price1= (TextView) findViewById(R.id.buy_price1);
         buy_count1= (TextView) findViewById(R.id.buy_count1);
         sala_price1= (TextView) findViewById(R.id.sala_price1);
         sala_count1= (TextView) findViewById(R.id.sala_count1);

         buy_price2= (TextView) findViewById(R.id.buy_price2);
         buy_count2= (TextView) findViewById(R.id.buy_count2);
         sala_price2= (TextView) findViewById(R.id.sala_price2);
         sala_count2= (TextView) findViewById(R.id.sala_count2);

         buy_price3= (TextView) findViewById(R.id.buy_price3);
         buy_count3= (TextView) findViewById(R.id.buy_count3);
         sala_price3= (TextView) findViewById(R.id.sala_price3);
         sala_count3= (TextView) findViewById(R.id.sala_count3);

         buy_price4= (TextView) findViewById(R.id.buy_price4);
         buy_count4= (TextView) findViewById(R.id.buy_count4);
         sala_price4= (TextView) findViewById(R.id.sala_price4);
         sala_count4= (TextView) findViewById(R.id.sala_count4);

         sale_prices= (TextView) findViewById(R.id.sale_prices);
         tv_time= (TextView) findViewById(R.id.tv_time);
         tv_begin= (TextView) findViewById(R.id.tv_begin);
         tv_ok= (TextView) findViewById(R.id.tv_ok);
         tv_teday= (TextView) findViewById(R.id.tv_teday);
         tv_money= (TextView) findViewById(R.id.tv_money);
         high= (TextView) findViewById(R.id.high);
         slow= (TextView) findViewById(R.id.slow);
         getmoney= (TextView) findViewById(R.id.getmoney);
         justmoney= (TextView) findViewById(R.id.justmoney);
         tv_shi= (TextView) findViewById(R.id.tv_shi);
         tv_jin= (TextView) findViewById(R.id.tv_jin);



        fragmentTabHost= (FragmentTabHost) findViewById(android.R.id.tabhost);

        fragmentTabHost.setup(DetalActivity.this,getSupportFragmentManager(),R.id.realtabcontent);
         Bundle bundle=new Bundle();
         bundle.putString("stockcode_sina",stockcode_sina);

        TabHost.TabSpec tabhost=fragmentTabHost.newTabSpec("daily");
        tabhost.setIndicator("日k图");
        fragmentTabHost.addTab(tabhost,DayFragment.class,bundle);

        TabHost.TabSpec tabhost1=fragmentTabHost.newTabSpec("min");
        tabhost1.setIndicator("分时图");
        fragmentTabHost.addTab(tabhost1,MinFragment.class,bundle);

        TabHost.TabSpec tabhost2=fragmentTabHost.newTabSpec("weekly");
        tabhost2.setIndicator("周k图");
        fragmentTabHost.addTab(tabhost2,WeekFragment.class,bundle);

        TabHost.TabSpec tabhost3=fragmentTabHost.newTabSpec("monthly");
        tabhost3.setIndicator("月k图");
        fragmentTabHost.addTab(tabhost3,MonthFragment.class,bundle);


         fragmentTabHost.getTabWidget().getChildAt(0).getLayoutParams().height=110;
         fragmentTabHost.getTabWidget().getChildAt(1).getLayoutParams().height=110;
         fragmentTabHost.getTabWidget().getChildAt(2).getLayoutParams().height=110;
         fragmentTabHost.getTabWidget().getChildAt(3).getLayoutParams().height=110;

        new AsyncTask<String,Integer,Stock>(){

            @Override
            protected Stock doInBackground(String... params) {
                Stock stock=new Stock();
                try {
                    URL url=new URL("http://hq.sinajs.cn/list="+params[0]);
                    HttpURLConnection httpURLConnection= (HttpURLConnection) url.openConnection();
                    httpURLConnection.connect();
                    if (httpURLConnection.getResponseCode()==200){
                        InputStream inputStream=httpURLConnection.getInputStream();
                        ByteArrayOutputStream byteArrayOutputStream=new ByteArrayOutputStream();
                        int len=-1;
                        byte [] b=new byte[1024];
                        while((len=inputStream.read(b))!=-1){
                            byteArrayOutputStream.write(b,0,len);

                        }
                        byteArrayOutputStream.close();
                        inputStream.close();
                        String value=byteArrayOutputStream.toString("GBK");
                        Log.e(TAG, "doInBackground: "+value );
                        String [] values=value.split("\"")[1].split(",");

                        stock.setStockname(values[0]);

                        stock.setBuy_price(values[11]);
                        stock.setBuy_count(values[10]);
                        stock.setSala_price(values[20]);
                        stock.setSala_count(values[21]);

                        stock.setBuy_price1(values[13]);
                        stock.setBuy_count1(values[12]);
                        stock.setSala_price1(values[23]);
                        stock.setSala_count1(values[22]);

                        stock.setBuy_price2(values[15]);
                        stock.setBuy_count2(values[14]);
                        stock.setSala_price2(values[25]);
                        stock.setSala_count2(values[24]);

                        stock.setBuy_price3(values[17]);
                        stock.setBuy_count3(values[16]);
                        stock.setSala_price3(values[27]);
                        stock.setSala_count3(values[26]);

                        stock.setBuy_price4(values[19]);
                        stock.setBuy_count4(values[18]);
                        stock.setSala_price4(values[29]);
                        stock.setSala_count4(values[28]);

//                        stock.setGetmoney(values[9]);
                        stock.setHigh(values[4]);
                        stock.setTv_time(values[31]);
                        stock.setTv_teday(values[2]);
//                        stock.setTv_shi(values[19]);
                        stock.setTv_ok(values[8]);
                        stock.setTv_money(values[9]);
//                        stock.setTv_jin(values[28]);
                        stock.setTv_begin(values[1]);
                        stock.setSlow(values[5]);
                        stock.setSale_prices(values[3]);
//                        stock.setJustmoney(values[28]);


                    }
                } catch (Exception e) {
                    progress.dismiss();
                    e.printStackTrace();
                }
                return stock;
            }

            @Override
            protected void onPostExecute(Stock stock) {
                super.onPostExecute(stock);
                stockname.setText(stock.getStockname());

                buy_price.setText(stock.getBuy_price());
                buy_count.setText(stock.getBuy_count());
                sala_price.setText(stock.getSala_price());
                sala_count.setText(stock.getSala_price());

                buy_price1.setText(stock.getBuy_price1());
                buy_count1.setText(stock.getBuy_count1());
                sala_price1.setText(stock.getSala_price1());
                sala_count1.setText(stock.getSala_price1());

                buy_price2.setText(stock.getBuy_price2());
                buy_count2.setText(stock.getBuy_count2());
                sala_price2.setText(stock.getSala_price2());
                sala_count2.setText(stock.getSala_price2());

                buy_price3.setText(stock.getBuy_price3());
                buy_count3.setText(stock.getBuy_count3());
                sala_price3.setText(stock.getSala_price3());
                sala_count3.setText(stock.getSala_price3());

                buy_price4.setText(stock.getBuy_price4());
                buy_count4.setText(stock.getBuy_count4());
                sala_price4.setText(stock.getSala_price4());
                sala_count4.setText(stock.getSala_price4());

                Float gupiao= Float.valueOf(stock.getTv_money());
                DecimalFormat decimalFormat=new DecimalFormat("0.00");
                String nowChangeStr = decimalFormat.format(gupiao/10000);

                Float gupiaol= Float.valueOf(stock.getTv_ok());
                DecimalFormat decimal=new DecimalFormat("0.00");
                String ChangeStr = decimal.format(gupiaol/10000);

                sale_prices.setText(stock.getSale_prices());
                tv_time.setText(stock.getTv_time());
                tv_begin.setText(stock.getTv_begin());
                tv_ok.setText(ChangeStr+"万股");
                tv_teday.setText(stock.getTv_teday());
                tv_money.setText(nowChangeStr+"万元");
                high.setText(stock.getHigh());
                slow.setText(stock.getSlow());


            }
        }.execute(stockcode_sina.trim());

progress.dismiss();

    }
     public void iv_back(View view){
         finish();
     }
}

