package com.gitonway.myshares;

import android.content.Intent;
import android.support.v4.app.FragmentTabHost;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TabHost;

import com.gitonway.myshares.userinfo.MineFragment;
import com.gitonway.myshares.mainfragment.MkFragment;

public class NewActivity extends AppCompatActivity {
    FragmentTabHost fragmentTabHost;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new);
        fragmentTabHost= (FragmentTabHost) findViewById(android.R.id.tabhost);
        fragmentTabHost.setup(NewActivity.this,getSupportFragmentManager(),R.id.realtabcontent);

        View view=View.inflate(this,R.layout.mk_shares,null);
        ImageView iv= (ImageView) view.findViewById(R.id.iv_hq);
        iv.setImageResource(R.drawable.hq_slector);
        TabHost.TabSpec tabSpec=fragmentTabHost.newTabSpec("mk");
        tabSpec.setIndicator(view);
        fragmentTabHost.addTab(tabSpec,MkFragment.class,null);

        View view1=View.inflate(this,R.layout.mine_shares,null);
        ImageView iv1= (ImageView) view1.findViewById(R.id.iv_mine);
        iv1.setImageResource(R.drawable.mine_slector);
        TabHost.TabSpec tabSpec1=fragmentTabHost.newTabSpec("mine");
        tabSpec1.setIndicator(view1);
        fragmentTabHost.addTab(tabSpec1,MineFragment.class,null);

    }
    public void change(View view){
        Intent intent=new Intent(NewActivity.this,EditActivity.class);
        startActivity(intent);
    }
}
