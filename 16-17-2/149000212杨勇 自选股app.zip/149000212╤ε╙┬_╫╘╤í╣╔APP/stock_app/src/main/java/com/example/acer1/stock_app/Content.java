package com.example.acer1.stock_app;

import android.content.Intent;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTabHost;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TabHost;
import android.widget.TextView;

public class Content extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_content);

       init();

    }

    private void init() {
        getSupportActionBar().hide();//掩藏Title
        FragmentTabHost fragmentTabHost;
        fragmentTabHost = (FragmentTabHost) findViewById(android.R.id.tabhost);//获取TabHost的Id
        fragmentTabHost.setup(Content.this,getSupportFragmentManager(),R.id.tabhostdisplay);

        TabHost.TabSpec tabSpecHQ = fragmentTabHost.newTabSpec("HQ");//创建行情按钮
        View view_HQ = View.inflate(Content.this,R.layout.tabhost_button_item,null);//获取到自定义button布局
        ImageView iv1 = (ImageView) view_HQ.findViewById(R.id.tabhost_botton_iv);//获取到自定义button布局的Image
        TextView  tv1 = (TextView) view_HQ.findViewById(R.id.tabhost_botton_tv);//获取到自定义button布局的Text
        iv1.setImageResource(R.drawable.hq_selector);//为image设置图片
        tv1.setText("行情");//为text设置文字
        tabSpecHQ.setIndicator(view_HQ);//将自定义布局设置到tabSpecHQ

        TabHost.TabSpec tabSpecWD = fragmentTabHost.newTabSpec("WD");//创建我的按钮
        View view_WD = View.inflate(Content.this,R.layout.tabhost_button_item,null);//获取到自定义button布局
        ImageView iv2 = (ImageView) view_WD.findViewById(R.id.tabhost_botton_iv);//获取到自定义button布局的Image
        TextView  tv2 = (TextView) view_WD.findViewById(R.id.tabhost_botton_tv);//获取到自定义button布局的Text
        iv2.setImageResource(R.drawable.wd_selector);//为image设置图片
        tv2.setText("我的");//为text设置文字
        tabSpecWD.setIndicator(view_WD);//将自定义布局设置到tabSpecHQ

        fragmentTabHost.addTab(tabSpecHQ,HQFragment.class,null);//tabSpecHQ添加到fragmentTabHost，这个按钮获取焦点打开一个HQFragment.class
        fragmentTabHost.addTab(tabSpecWD,WDFragment.class,null);//tabSpecWD添加到fragmentTabHost，这个按钮获取焦点打开一个WDFragment.class
    }
    public void bj(View v)
    {
        Intent intent = new Intent(this,BJActivity.class);
        startActivity(intent);
    }
}
