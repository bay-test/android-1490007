package com.example.acer1.stock_app;

import android.app.ActivityManager;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;

public class CDActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cd);
        getSupportActionBar().hide();

    }
    public void cd (View v){
        if(v.getId()==R.id.cd_title_fh)
        {finish();}
        if (v.getId()==R.id.cd_tv3)
        {
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setTitle("版本号");
            builder.setMessage("1.0.0");
            builder.show();
        }
        if(v.getId()==R.id.cd_tv2)
        {
           System.exit(0);//彻底退出APP

        }if(v.getId()==R.id.cd_tv1)
        {
            AlertDialog.Builder bu=new AlertDialog.Builder(CDActivity.this);//创建一个对话框
            bu.setTitle("关于我们");
            View layout = LayoutInflater.from(CDActivity.this).inflate(R.layout.cd_dialog_layout,null);
            bu.setView(layout);
            bu.show();//显示该对话框

        }
        if(v.getId()==R.id.yhxy)
        {
            Intent intent = new Intent(CDActivity.this,XieYiActivity.class);
            startActivity(intent);
        }
    }

}
