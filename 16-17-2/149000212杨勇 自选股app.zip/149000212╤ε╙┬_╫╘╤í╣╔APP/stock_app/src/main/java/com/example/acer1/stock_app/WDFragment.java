package com.example.acer1.stock_app;


import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v4.app.Fragment;
import android.support.v7.app.AlertDialog;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import static com.example.acer1.stock_app.R.styleable.FloatingActionButton;


/**
 * A simple {@link Fragment} subclass.
 */
public class WDFragment extends Fragment {
    android.support.design.widget.FloatingActionButton floatingActionButton;
    EditText username;
    EditText userpassword;
    Button login;
    String name;
    String namevalue;
    Entity entity = new Entity();
    public WDFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(final LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v =inflater.inflate(R.layout.fragment_wd, container, false);
        username= (EditText) v.findViewById(R.id.username);
        userpassword= (EditText) v.findViewById(R.id.userpassword);
        login= (Button) v.findViewById(R.id.login);
        floatingActionButton= (android.support.design.widget.FloatingActionButton) v.findViewById(R.id.floatingActionButton);
        floatingActionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getContext(),RegisterActivity.class);
                startActivity(intent);

            }
        });

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int i=1;
                namevalue=username.getText().toString();
                if (username.getText().toString().length()>=1){
                 UserSQlite userSQlite = new UserSQlite(getContext(),1);
                SQLiteDatabase sqLiteDatabase = userSQlite.getWritableDatabase();
                Cursor cursor;
                cursor= sqLiteDatabase.rawQuery("SELECT username FROM usertable WHERE username=?",new String[]{namevalue});
//                "usertable",new String[]{"username"},null,null,null,null,null
                while(cursor.moveToNext()){
                    name=cursor.getString(0);
                    entity.setUsername(cursor.getString(0));
                    if (cursor.getCount()<=1)
                    {   i=0;
                        break;
                    }
                }

                 if(namevalue.equals(name)){
                     Toast.makeText(getContext(), ":::"+entity.getUsername()+"欢迎您登录本APP!:::", Toast.LENGTH_SHORT).show();
                     Intent intent = new Intent(getContext(),UserActivity.class);
                     intent.putExtra("name",entity.getUsername());
                     startActivity(intent);
                 }else{
                     Snackbar.make(view,"对不起！系统没有这个用户，请先注册！",Snackbar.LENGTH_INDEFINITE).setAction("确定要注册吗？", new View.OnClickListener() {
                         @Override
                         public void onClick(View view) {
                             Intent intent = new Intent(getContext(),RegisterActivity.class);
                             startActivity(intent);
                         }}).show();
                 }
            }else{ AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
                    builder.setTitle("提示");
                    builder.setMessage("亲!用户名和密码不能为空！");
                    builder.show();}
            }

        });




        return v;
    }
}
