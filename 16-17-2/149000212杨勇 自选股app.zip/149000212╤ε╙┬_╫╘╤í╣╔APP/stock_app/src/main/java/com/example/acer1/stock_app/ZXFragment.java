package com.example.acer1.stock_app;


import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import static com.example.acer1.stock_app.R.id.stock_code;


/**
 * A simple {@link Fragment} subclass.
 */
public class ZXFragment extends Fragment {
    List<Entity> mylist = new ArrayList<Entity>();
    Myadapter myadapter;
    Cursor cursor;
    Entity entity = new Entity();
    public ZXFragment() {
        // Required empty public constructor
    }
    public void Refresh(){
        mylist=getmylist();
        myadapter.notifyDataSetChanged();

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v=inflater.inflate(R.layout.fragment_zx, container, false);

        RecyclerView recyclerView = (RecyclerView) v.findViewById(R.id.zx_recyclerview);
        final SwipeRefreshLayout swipeRefreshLayout = (SwipeRefreshLayout) v.findViewById(R.id.refresh);


        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getContext());
        linearLayoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        recyclerView.setLayoutManager(linearLayoutManager);

        MySQLiteOpenHelper mySQLiteOpenHelper = new MySQLiteOpenHelper(getContext(),1);
        SQLiteDatabase sqLiteDatabase= mySQLiteOpenHelper.getWritableDatabase();
        cursor= sqLiteDatabase.query("stock",new String[]{"_id","stockcodes","stocknames","stockcodes_sina"},null,null,null,null,null );
        while(cursor.moveToNext()){

            entity.set_id(cursor.getString(0));
            entity.setStock_code(cursor.getString(1));
            entity.setStock_name(cursor.getString(2));
            entity.setStockcodes_sina(cursor.getString(3));
            entity.setStock_zdf("-1.205");
            entity.setStock_zxj("1532.4");
//            new AsyncTask<String, Integer, Entity >() {
//
//                @Override
//                protected Entity doInBackground(String... voids) {
//                    Entity et =new Entity();
//                   String k= null;
//                    try {
//                        URL url = new URL("http://hq.sinajs.cn/list="+voids[0]);
//                        try {
//                            HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
//                            httpURLConnection.connect();
//                            if (httpURLConnection.getResponseCode()==200)
//                            {
//                                InputStream inputStream  =httpURLConnection.getInputStream();
//                                ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
//                                byte[]b= new byte[1024];
//                                int len=-1;
//                                while((len = inputStream.read(b)) != -1){
//                                    byteArrayOutputStream.write(b,0,len);
//                                }
//                                String result = byteArrayOutputStream.toString("GBK");
//                                byteArrayOutputStream.close();
//                                inputStream.close();
//                                String [] Entitys = result.split("\"")[1].split(",");
//                                et.setStock_zxj(Entitys[3]);
//
//                            }
//                        } catch (IOException e) {
//                            e.printStackTrace();
//                        }
//                    } catch (MalformedURLException e) {
//                        e.printStackTrace();
//                    }
//                    Toast.makeText(getContext(), ":::::"+k, Toast.LENGTH_SHORT).show();
//                    return et;
//                }
//
//                @Override
//                protected void onPostExecute(Entity entity) {
//                    super.onPostExecute(entity);
//
//                }
//            }.execute(entity.getStock_code().trim());


            mylist.add(entity);
        }
        sqLiteDatabase.close();
         myadapter = new Myadapter(getContext(),mylist);
        recyclerView.setAdapter(myadapter);

        swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                mylist = getmylist();
                myadapter.notifyDataSetChanged();
                swipeRefreshLayout.setRefreshing(false);
            }
        });
        return v;
    }




    private List<Entity> getmylist() {
        mylist.clear();
        MySQLiteOpenHelper mySQLiteOpenHelper = new MySQLiteOpenHelper(getContext(),1);
        SQLiteDatabase sqLiteDatabase= mySQLiteOpenHelper.getWritableDatabase();
        Cursor cursor= sqLiteDatabase.query("stock",new String[]{"_id","stockcodes","stocknames","stockcodes_sina"},null,null,null,null,null );
        while(cursor.moveToNext()){
            Entity entity = new Entity();
            entity.set_id(cursor.getString(0));
            entity.setStock_code(cursor.getString(1));
            entity.setStock_name(cursor.getString(2));
            entity.setStockcodes_sina(cursor.getString(3));
            entity.setStock_zdf("-0.361");
            entity.setStock_zxj("17325.0");
            mylist.add(entity);

        }
        sqLiteDatabase.close();
        return  mylist;
    }




}
class Myadapter extends RecyclerView.Adapter {
    Context context;
    List<Entity> ra_list;

    public Myadapter(Context context, List<Entity> ra_list) {
        this.context = context;
        this.ra_list = ra_list;
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.recyclerview_item,parent,false);
        MyHolder myholder = new MyHolder(v);
        return myholder;
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {

        MyHolder myholder = (MyHolder) holder;
        myholder.stock_name.setText(ra_list.get(position).getStock_name());
        myholder.stock_code.setText(ra_list.get(position).getStock_code());
        myholder.stock_zxj.setText(ra_list.get(position).getStock_zxj());
        myholder.stock_zdf.setText(ra_list.get(position).getStock_zdf());
    }

    @Override
    public int getItemCount() {
        return ra_list.size();
    }

    class MyHolder extends RecyclerView.ViewHolder {
        TextView stock_name;
        TextView stock_code;
        TextView stock_zxj;
        TextView stock_zdf;
        public MyHolder(final View itemView) {
            super(itemView);
            stock_name = (TextView) itemView.findViewById(R.id.stock_name);
            stock_code = (TextView) itemView.findViewById(R.id.stock_code);
            stock_zxj = (TextView) itemView.findViewById(R.id.stock_zxj);
            stock_zdf = (TextView) itemView.findViewById(R.id.stock_zdf);
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent intent = new Intent(context,XQActivity.class);
                    Entity entity = ra_list.get(getAdapterPosition());
                    intent.putExtra("stock_name",entity.getStock_name());
                    intent.putExtra("stock_code",entity.getStockcodes_sina());
                    context.startActivity(intent);
                }
            });
        }
    }

}
