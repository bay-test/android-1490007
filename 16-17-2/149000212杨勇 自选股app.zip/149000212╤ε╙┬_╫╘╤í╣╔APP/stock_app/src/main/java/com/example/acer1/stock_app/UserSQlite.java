package com.example.acer1.stock_app;

import android.content.Context;
import android.database.DatabaseErrorHandler;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Created by acer1 on 2017-06-14 0014.
 */

public class UserSQlite extends SQLiteOpenHelper {
    public UserSQlite(Context context,int version) {
        super(context, "usertable", null, version);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL("CREATE table usertable(_id integer primary key autoincrement,username varchar,userpassword)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }
}
