package com.example.acer1.stock_app;

/**
 * Created by acer1 on 2017-06-15 0015.
 */

public class HsEntity {
    String  stock_name;
    String  stock_code;
    String  zxj;
    String zdf;

    public HsEntity(String stock_code, String stock_name, String zdf, String zxj) {
        this.stock_code = stock_code;
        this.stock_name = stock_name;
        this.zdf = zdf;
        this.zxj = zxj;
    }

    public String getStock_code() {
        return stock_code;
    }

    public void setStock_code(String stock_code) {
        this.stock_code = stock_code;
    }

    public String getStock_name() {
        return stock_name;
    }

    public void setStock_name(String stock_name) {
        this.stock_name = stock_name;
    }

    public String getZdf() {
        return zdf;
    }

    public void setZdf(String zdf) {
        this.zdf = zdf;
    }

    public String getZxj() {
        return zxj;
    }

    public void setZxj(String zxj) {
        this.zxj = zxj;
    }

    public HsEntity() {

        this.stock_code = stock_code;
        this.stock_name = stock_name;
        this.zdf = zdf;
        this.zxj = zxj;
    }
}
