package com.example.acer1.stock_app;

import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class RegisterActivity extends AppCompatActivity {
Button register;
    EditText name;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        getSupportActionBar().hide();

        register = (Button) findViewById(R.id.register);
        name = (EditText) findViewById(R.id.name);
        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                UserSQlite userSQlite = new UserSQlite(RegisterActivity.this,1);
                SQLiteDatabase sqLiteDatabase = userSQlite.getWritableDatabase();
                ContentValues contentvalue = new ContentValues();
                contentvalue.put("username",name.getText().toString());
                sqLiteDatabase.insert("usertable",null,contentvalue);
                Toast.makeText(RegisterActivity.this, "用户："+name.getText().toString()+"注册成功,前往登录！", Toast.LENGTH_SHORT).show();
                sqLiteDatabase.close();
                finish();
            }
        });



    }
}
