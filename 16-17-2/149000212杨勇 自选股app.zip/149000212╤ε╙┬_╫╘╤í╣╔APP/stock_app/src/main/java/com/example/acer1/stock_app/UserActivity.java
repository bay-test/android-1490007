package com.example.acer1.stock_app;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class UserActivity extends AppCompatActivity {
TextView name;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user);
        Intent intent = getIntent();

        name = (TextView) findViewById(R.id.user_name);
        name.setText("尊敬的："+intent.getStringExtra("name")+"，欢迎使用本APP");
    }
}
