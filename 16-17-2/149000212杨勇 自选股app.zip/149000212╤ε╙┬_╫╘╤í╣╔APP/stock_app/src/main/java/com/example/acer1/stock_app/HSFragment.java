package com.example.acer1.stock_app;


import android.content.Intent;
import android.content.res.Resources;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;


/**
 * A simple {@link Fragment} subclass.
 */
public class HSFragment extends Fragment {

    List<HsEntity> mylist = new ArrayList<>();
    RecyclerView recyclerView;
    public HSFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v=inflater.inflate(R.layout.fragment_blank, container, false);
        Resources resources;
        resources=v.getResources();
        final String[] stockcodes=resources.getStringArray(R.array.stockcodes);
        final String[] stockcodes_sina=resources.getStringArray(R.array.stockcodes_sina);
        final String[] stocknames=resources.getStringArray(R.array.stocknames);


for (int i=0;i<=50;i++) {
    HsEntity tt = new HsEntity("" + stockcodes_sina[i], " " + stocknames[i], "dsfa", "fas");
    mylist.add(tt);
}

        recyclerView= (RecyclerView) v.findViewById(R.id.hs_rv);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getContext());
        linearLayoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        recyclerView.setLayoutManager(linearLayoutManager);

        HsAdapter hsAdapter = new HsAdapter(mylist);
        recyclerView.setAdapter(hsAdapter);


        return v;
    }
    public class HsAdapter extends RecyclerView.Adapter<HsAdapter.ViewHolder> {
        private List<HsEntity> hslist;

        public HsAdapter(List<HsEntity> hslist) {
            this.hslist = hslist;
        }

        @Override
        public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View layout =LayoutInflater.from(getContext()).inflate(R.layout.hs_rv_item,parent,false);
            ViewHolder hSviewHolder = new ViewHolder(layout);


            return hSviewHolder;
        }

        @Override
        public void onBindViewHolder(ViewHolder holder, int position) {
            HsEntity hsEntity = hslist.get(position);
            holder.hsstock_code.setText(hsEntity.getStock_code());
            holder.hsstock_name.setText(hsEntity.getStock_name());

        }

        @Override
        public int getItemCount() {
            return hslist.size();
        }

        public class ViewHolder extends RecyclerView.ViewHolder {
            TextView hsstock_code;
            TextView hsstock_name;
            public ViewHolder(View itemView) {
                super(itemView);
                hsstock_code= (TextView) itemView.findViewById(R.id.hsstock_code);
                hsstock_name= (TextView) itemView.findViewById(R.id.hsstock_name);
                itemView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Intent intent = new Intent(getContext(),XQActivity.class);
                        HsEntity entity = hslist.get(getAdapterPosition());
                        intent.putExtra("stock_name",entity.getStock_name());
                        intent.putExtra("stock_code",entity.getStock_code());
                        getContext().startActivity(intent);
                    }
                });
            }
        }
    }

}
