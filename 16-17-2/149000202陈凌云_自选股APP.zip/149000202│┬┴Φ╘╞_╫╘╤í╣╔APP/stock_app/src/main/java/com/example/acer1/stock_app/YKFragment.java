package com.example.acer1.stock_app;


import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;


/**
 * A simple {@link Fragment} subclass.
 */
public class YKFragment extends Fragment {


    public YKFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        final View v =inflater.inflate(R.layout.fragment_yk, container, false);
        final String stock_code =    getArguments().getString("stock_code");
        new AsyncTask<String, Integer, Entity>(){
            Bitmap bitmap;
            ImageView imageView;
            @Override
            protected Entity doInBackground(String... strings) {
                try {
                    URL url = new URL("http://image.sinajs.cn/newchart/monthly/n/"+stock_code+".gif");
                    HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
                    httpURLConnection.connect();
                    InputStream inputStream =httpURLConnection.getInputStream();
                    if(httpURLConnection.getResponseCode()==200)
                    {
                        InputStream is = httpURLConnection.getInputStream();
                        bitmap = BitmapFactory.decodeStream(is);
                        inputStream.close();
                    }
                } catch (java.io.IOException e) {
                    e.printStackTrace();
                }

                return null;

            }

            @Override
            protected void onPostExecute(Entity entity) {
                super.onPostExecute(entity);
                imageView = (ImageView) v.findViewById(R.id.iv_yk);
                imageView.setImageBitmap(bitmap);

            }
        }.execute(stock_code.trim());



        return v;
    }

}
