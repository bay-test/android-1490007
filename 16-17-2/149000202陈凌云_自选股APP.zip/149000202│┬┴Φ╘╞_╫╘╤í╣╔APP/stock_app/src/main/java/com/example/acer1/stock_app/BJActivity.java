package com.example.acer1.stock_app;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class BJActivity extends AppCompatActivity {
    RecyclerView recyclerView;
    List<Entity> mylist =new ArrayList<Entity>();
    SwipeRefreshLayout swipeRefreshLayout;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bj);

        getSupportActionBar().hide();
        swipeRefreshLayout= (SwipeRefreshLayout) findViewById(R.id.bj_refresh);
        recyclerView = (RecyclerView) findViewById(R.id.bj_rv);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        linearLayoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        recyclerView.setLayoutManager(linearLayoutManager);
        final MyBjadapter myBjadapter = new MyBjadapter(BJActivity.this,mylist);
        recyclerView.setAdapter(myBjadapter);
        mysqlitedataRefresh();
        swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                mylist=mysqlitedataRefresh();
                myBjadapter.notifyDataSetChanged();
                swipeRefreshLayout.setRefreshing(false);
            }
        });
    }
    private List<Entity> mysqlitedataRefresh(){
        mylist.clear();
    MySQLiteOpenHelper mySQLiteOpenHelper =new MySQLiteOpenHelper(BJActivity.this,1);
    SQLiteDatabase sqLiteDatabase = mySQLiteOpenHelper.getWritableDatabase();
    Cursor cursor;
    cursor = sqLiteDatabase.query("stock",new String[]{"stockcodes","stocknames"},null,null,null,null,null);
    while (cursor.moveToNext())
    {
        Entity entity = new Entity();
        entity.setStock_code(cursor.getString(0));
        entity.setStock_name(cursor.getString(1));
        mylist.add(entity);
    }
    sqLiteDatabase.close();
        return mylist;
}

    class MyBjadapter extends RecyclerView.Adapter {
        BJActivity content;
        List<Entity> bjrv_list;
        public MyBjadapter(BJActivity content, List<Entity> bjrv_list) {
            this.content = content;
            this.bjrv_list = bjrv_list;
        }

        @Override
        public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View Layout = LayoutInflater.from(content).inflate(R.layout.bj_rv_item,parent,false);
            MyBjHolder myBjHolder = new MyBjHolder(Layout);

            return myBjHolder;
        }

        @Override
        public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
            Entity entity = new Entity();
            MyBjHolder myBjHolder =(MyBjHolder) holder;
            myBjHolder.bj_item_code.setText(bjrv_list.get(position).getStock_code());
            myBjHolder.bj_item_name.setText(bjrv_list.get(position).getStock_name());


        }

        @Override
        public int getItemCount() {
            return bjrv_list.size();
        }

        private class MyBjHolder extends RecyclerView.ViewHolder {
            TextView bj_item_name;
            TextView bj_item_code;
            public MyBjHolder(View layout) {
                super(layout);
                bj_item_name= (TextView) layout.findViewById(R.id.bj_item_name);
                bj_item_code= (TextView) layout.findViewById(R.id.bj_item_code);
                layout.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Entity entity = bjrv_list.get(getAdapterPosition());
                        String name=entity.getStock_name();
                        Toast.makeText(BJActivity.this, ":::"+entity.getStock_name()+"删除成功，下拉刷新！:::", Toast.LENGTH_SHORT).show();
                        MySQLiteOpenHelper mySQLiteOpenHelper = new MySQLiteOpenHelper(BJActivity.this,1);
                        SQLiteDatabase sqLiteDatabase = mySQLiteOpenHelper.getWritableDatabase();
                        sqLiteDatabase.delete("stock","stocknames=?",new String[]{""+name});
                        sqLiteDatabase.close();
                        mysqlitedataRefresh();

                    }
                });
            }
        }
    }


    public void fh(View v)
    {
        finish();
    }



}
