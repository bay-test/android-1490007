package com.example.acer1.stock_app;

import android.content.Intent;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.AnimationSet;
import android.view.animation.RotateAnimation;
import android.view.animation.ScaleAnimation;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;

public class Welcome extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        requestWindowFeature(Window.FEATURE_NO_TITLE);//设置无标题（自己测试无效）
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);//设置全屏

        setContentView(R.layout.activity_weilcome);
        init();


    }

    private void init() {
        getSupportActionBar().hide();//掩藏欢迎界面的Title
        RelativeLayout ll = (RelativeLayout) findViewById(R.id.activity_weilcome);//获取到Welcome布局的Id

        AnimationSet animationset = new AnimationSet(false);//复合动画创建
        animationset.setDuration(3000);//复合动画设置时间3秒

        ScaleAnimation sa = new ScaleAnimation(0f, 1f, 0f, 1f, Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.5f);//缩放动画创建
        sa.setDuration(3000);//缩放动画设置时间3秒

        AlphaAnimation aa = new AlphaAnimation(0.1f, 1f);//透明动画创建
        aa.setDuration(3000);//透明动画设置时间3秒

        RotateAnimation ra = new RotateAnimation(0, 360, Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.5f);//旋转动画开始
        ra.setDuration(3000);//旋转动画设置时间3秒

        animationset.addAnimation(sa);//缩放动画添加到复合动画里面
        animationset.addAnimation(aa);//透明动画添加到复合动画里面
        animationset.addAnimation(ra);//旋转动画添加到复合动画里面
        ll.startAnimation(animationset);//启动复合动画

       new Handler().postDelayed(new Runnable() {
           @Override
           public void run() {
               Intent it = new Intent(Welcome.this,Content.class);//使用Intent跳转到主界面
               startActivity(it);
               finish();

           }
       },5000);
    }
}


