package com.example.acer1.stock_app;


import android.content.ContentValues;
import android.content.Intent;
import android.content.res.Resources;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTabHost;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.ImageView;
import android.widget.TabHost;
import android.widget.TextView;
import android.widget.Toast;

import java.security.PublicKey;
import java.util.HashMap;
import java.util.Map;


/**
 * A simple {@link Fragment} subclass.
 */
public class HQFragment extends Fragment {
    Map<String,Entity>entityMap=new HashMap<String, Entity>();
    ImageView imageView ;
    ZXFragment zx;
    public HQFragment() {
        // Required empty public constructor
    }

    @Override
    public void onAttachFragment(Fragment childFragment) {
        super.onAttachFragment(childFragment);

        if(childFragment instanceof  ZXFragment)
        {

            Toast.makeText(getContext(), "自选股票", Toast.LENGTH_SHORT).show();
        }else
        {
            Toast.makeText(getContext(), "沪深股票", Toast.LENGTH_SHORT).show();
        }

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View tb_view = inflater.inflate(R.layout.fragment_hq, container, false);

        FragmentTabHost fragmentTabHost = (FragmentTabHost) tb_view.findViewById(android.R.id.tabhost);
        fragmentTabHost.setup(getActivity(),getChildFragmentManager(),R.id.tabhostdisplay);
        TabHost.TabSpec tabSpecZX = fragmentTabHost.newTabSpec("ZX");
        tabSpecZX.setIndicator("自选");
        fragmentTabHost.addTab(tabSpecZX,ZXFragment.class,null);


        TabHost.TabSpec tabSpecHS = fragmentTabHost.newTabSpec("HS");
        tabSpecHS.setIndicator("沪深");
        fragmentTabHost.addTab(tabSpecHS,HSFragment.class,null);
        fragmentTabHost.getTabWidget().getChildAt(0).getLayoutParams().height=110;
        fragmentTabHost.getTabWidget().getChildAt(1).getLayoutParams().height=110;



        Resources resources;
        resources=tb_view.getResources();
        final String[] stockcodes=resources.getStringArray(R.array.stockcodes);
        final String[] stockcodes_sina=resources.getStringArray(R.array.stockcodes_sina);
        final String[] stocknames=resources.getStringArray(R.array.stocknames);
        for(int i=0;i<stockcodes.length;i++)
        {
            Entity entity = new Entity();
            entity.stock_code=stockcodes[i];
            entity.stock_name=stocknames[i];
            entity.stockcodes_sina=stockcodes_sina[i];
            entityMap.put(stockcodes[i],entity);
        }
        final AutoCompleteTextView autoCompleteTextView = (AutoCompleteTextView) tb_view.findViewById(R.id.title_atv);
        ArrayAdapter arrayAdapter = new ArrayAdapter(getActivity(),android.R.layout.simple_expandable_list_item_1,stockcodes);
        autoCompleteTextView.setAdapter(arrayAdapter);

        autoCompleteTextView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int i, long id) {
                String item = parent.getItemAtPosition(i).toString();
                Entity entity = entityMap.get(item);
                MySQLiteOpenHelper mysqlite = new MySQLiteOpenHelper(getActivity(),1);
                ContentValues contentvalue = new ContentValues();
                contentvalue.put("stockcodes",entity.getStock_code());
                contentvalue.put("stockcodes_sina",entity.getStockcodes_sina());
                contentvalue.put("stocknames",entity.getStock_name());
                SQLiteDatabase sqLiteDatabase=mysqlite.getWritableDatabase();
                sqLiteDatabase.insert("stock",null,contentvalue);
                sqLiteDatabase.close();

               // zx.Refresh();
                Toast.makeText(getActivity(), "添加股票"+parent.getItemAtPosition(i).toString()+"成功，下拉刷新！",Toast.LENGTH_SHORT).show();
                autoCompleteTextView.setText(" ");
            }
        });

       imageView = (ImageView) tb_view.findViewById(R.id.cd);
        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getContext(),CDActivity.class);
                startActivity(intent);
            }
        });


        return tb_view;


    }

//    <item name="colorPrimary">@color/colorPrimary</item>
//    <item name="colorPrimaryDark">@color/colorPrimaryDark</item>
//    <item name="colorAccent">@color/colorAccent</item>
}
