package com.example.acer1.stock_app;


import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.Toast;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.security.PublicKey;


/**
 * A simple {@link Fragment} subclass.
 */
public class RKFragment extends Fragment {
    ImageView imageView;
    String stock_code;
    Bitmap bitmap = null;
    public RKFragment() {
        // Required empty public constructor
    }



    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        final View rk_view =inflater.inflate(R.layout.fragment_rk, container, false);
        stock_code =    getArguments().getString("stock_code");
        new AsyncTask<String, Integer, Entity>(){

            @Override
            protected Entity doInBackground(String... strings) {
                try {
                    URL url = new URL("http://image.sinajs.cn/newchart/daily/n/"+stock_code+".gif");
                    HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
                    httpURLConnection.connect();
                    InputStream inputStream =httpURLConnection.getInputStream();
                    if(httpURLConnection.getResponseCode()==200)
                    {
                        InputStream is = httpURLConnection.getInputStream();
                        bitmap = BitmapFactory.decodeStream(is);
                       inputStream.close();
                    }
                } catch (java.io.IOException e) {
                    e.printStackTrace();
                }

                return null;

            }

            @Override
            protected void onPostExecute(Entity entity) {
                super.onPostExecute(entity);
                 imageView = (ImageView) rk_view.findViewById(R.id.iv_rk);
                 imageView.setImageBitmap(bitmap);

            }
        }.execute(stock_code.trim());
        return rk_view;
    }

}
