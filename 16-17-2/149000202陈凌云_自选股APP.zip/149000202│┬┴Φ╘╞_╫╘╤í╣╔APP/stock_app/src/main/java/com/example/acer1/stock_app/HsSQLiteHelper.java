package com.example.acer1.stock_app;

import android.content.Context;
import android.database.DatabaseErrorHandler;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Created by acer1 on 2017-06-15 0015.
 */

public class HsSQLiteHelper extends SQLiteOpenHelper {
    public HsSQLiteHelper(Context context, int version) {
        super(context, "hstable", null, version);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL(" CREATE table hstable (_id integer primary key autoincrement,stockcodes varchar,stockcodes_sina varchar,stocknames varchar);");
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }
}
