package com.example.acer1.stock_app;

import android.content.Intent;
import android.nfc.Tag;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Handler;
import android.os.Message;
import android.renderscript.Sampler;
import android.support.v4.app.FragmentTabHost;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Layout;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.TabHost;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

public class XQActivity extends AppCompatActivity {
    TextView tv_stock_name;
    String stock_code;
    String stock_name;
    Entity entity = new Entity();

    TextView m_1_1;
    TextView m_1_2;
    TextView m_2_1;
    TextView m_2_2;
    TextView m_3_1;
    TextView m_3_2;
    TextView m_4_1;
    TextView m_4_2;
    TextView m_5_1;
    TextView m_5_2;
    TextView mm_1_1;
    TextView mm_1_2;
    TextView mm_2_1;
    TextView mm_2_2;
    TextView mm_3_1;
    TextView mm_3_2;
    TextView mm_4_1;
    TextView mm_4_2;
    TextView mm_5_1;
    TextView mm_5_2;

    TextView jk;
    TextView zs;
    TextView cjl;
    TextView sz;
    TextView zg;
    TextView mgsy;
    TextView syl;
    TextView zd;
    TextView mgjzc;
    TextView sjl;

    TextView t1;
    TextView t2;
    TextView t3;

    FragmentTabHost fragmentTabHost;
    ImageView xq_fh;



    @Override
    protected void onCreate(Bundle savedInstanceState) {



        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_xq);



        getSupportActionBar().hide();
        Intent intent= getIntent();
        stock_name=intent.getStringExtra("stock_name");
        stock_code=intent.getStringExtra("stock_code");
        xq_fh= (ImageView) findViewById(R.id.xq_fh);
        xq_fh.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                 finish();
            }
        });

        fragmentTabHost = (FragmentTabHost) findViewById(android.R.id.tabhost);
        fragmentTabHost.setup(XQActivity.this,getSupportFragmentManager(),R.id.tabhostshow);
        Bundle bundle =new Bundle();
        bundle.putString("stock_code",stock_code);
        TabHost.TabSpec tabSpecFS = fragmentTabHost.newTabSpec("fs");
        tabSpecFS.setIndicator("分时");
        fragmentTabHost.addTab(tabSpecFS,FSFragment.class,bundle);

        TabHost.TabSpec tabSpecR = fragmentTabHost.newTabSpec("R");
        tabSpecR.setIndicator("日K");
        fragmentTabHost.addTab(tabSpecR,RKFragment.class,bundle);

        TabHost.TabSpec tabSpecZ = fragmentTabHost.newTabSpec("Z");
        tabSpecZ.setIndicator("周K");
        fragmentTabHost.addTab(tabSpecZ,ZKFragment.class,bundle);

        TabHost.TabSpec tabSpecY = fragmentTabHost.newTabSpec("Y");
        tabSpecY.setIndicator("月K");
        fragmentTabHost.addTab(tabSpecY,YKFragment.class,bundle);
        fragmentTabHost.getTabWidget().getChildAt(0).getLayoutParams().height=110;
        fragmentTabHost.getTabWidget().getChildAt(1).getLayoutParams().height=110;
        fragmentTabHost.getTabWidget().getChildAt(2).getLayoutParams().height=110;
        fragmentTabHost.getTabWidget().getChildAt(3).getLayoutParams().height=110;



        new AsyncTask<String, Integer, Entity>() {
            @Override
            protected Entity doInBackground(String... voids) {
                try {
                    URL url = new URL("http://hq.sinajs.cn/list="+voids[0]);

                        HttpURLConnection httpURLConnection = (HttpURLConnection)url.openConnection();
                        httpURLConnection.connect();
                        if(httpURLConnection.getResponseCode()==200)
                        {
                            InputStream inputStream =httpURLConnection.getInputStream();
                            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                            byte []b=new byte[1024];
                            int len = -1;
                            while((len = inputStream.read(b)) != -1){
                                byteArrayOutputStream.write(b,0,len);
                            }
                            String result = byteArrayOutputStream.toString("GBK");
                            byteArrayOutputStream.close();
                            inputStream.close();
                            String [] Entitys = result.split("\"")[1].split(",");
                            entity.setStock_name(Entitys[0]);
                            entity.setM_1_1(Entitys[11]);
                            entity.setM_2_1(Entitys[13]);
                            entity.setM_3_1(Entitys[15]);
                            entity.setM_4_1(Entitys[17]);
                            entity.setM_5_1(Entitys[19]);
                            entity.setM_1_2(Entitys[10]);
                            entity.setM_2_2(Entitys[12]);
                            entity.setM_3_2(Entitys[14]);
                            entity.setM_4_2(Entitys[16]);
                            entity.setM_5_2(Entitys[18]);

                            entity.setMm_1_1(Entitys[21]);
                            entity.setMm_2_1(Entitys[23]);
                            entity.setMm_3_1(Entitys[25]);
                            entity.setMm_4_1(Entitys[27]);
                            entity.setMm_5_1(Entitys[29]);
                            entity.setMm_1_2(Entitys[20]);
                            entity.setMm_2_2(Entitys[22]);
                            entity.setMm_3_2(Entitys[24]);
                            entity.setMm_4_2(Entitys[26]);
                            entity.setMm_5_2(Entitys[28]);

                            entity.setJk(Entitys[1]);
                            entity.setZs(Entitys[2]);
                            entity.setCjl(Entitys[8]);
                            entity.setSz(Entitys[9]);
                            entity.setZg(Entitys[4]);
                            entity.setMgsy("---");
                            entity.setSyl("---");
                            entity.setZd(Entitys[5]);
                            entity.setMgjzc("---");
                            entity.setSjl("---");

                            entity.setT1(Entitys[3]);



                        }
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                return entity;
            }
            @Override
            protected void onPostExecute(Entity entity) {
                super.onPostExecute(entity);

                tv_stock_name = (TextView) findViewById(R.id.xq_title_stockname);
                m_1_1= (TextView) findViewById(R.id.m_1_1);
                m_2_1= (TextView) findViewById(R.id.m_2_1);
                m_3_1= (TextView) findViewById(R.id.m_3_1);
                m_4_1= (TextView) findViewById(R.id.m_4_1);
                m_5_1= (TextView) findViewById(R.id.m_5_1);
                m_1_2= (TextView) findViewById(R.id.m_1_2);
                m_2_2= (TextView) findViewById(R.id.m_2_2);
                m_3_2= (TextView) findViewById(R.id.m_3_2);
                m_4_2= (TextView) findViewById(R.id.m_4_2);
                m_5_2= (TextView) findViewById(R.id.m_5_2);

                mm_1_1= (TextView) findViewById(R.id.mm_1_1);
                mm_2_1= (TextView) findViewById(R.id.mm_2_1);
                mm_3_1= (TextView) findViewById(R.id.mm_3_1);
                mm_4_1= (TextView) findViewById(R.id.mm_4_1);
                mm_5_1= (TextView) findViewById(R.id.mm_5_1);
                mm_1_2= (TextView) findViewById(R.id.mm_1_2);
                mm_2_2= (TextView) findViewById(R.id.mm_2_2);
                mm_3_2= (TextView) findViewById(R.id.mm_3_2);
                mm_4_2= (TextView) findViewById(R.id.mm_4_2);
                mm_5_2= (TextView) findViewById(R.id.mm_5_2);

                 jk= (TextView) findViewById(R.id.jk);
                 zs= (TextView) findViewById(R.id.zs);
                 cjl= (TextView) findViewById(R.id.cjl);
                 sz= (TextView) findViewById(R.id.sz);
                 zg= (TextView) findViewById(R.id.zg);
                 mgsy= (TextView) findViewById(R.id.mgsy);
                 syl= (TextView) findViewById(R.id.syl);
                 zd= (TextView) findViewById(R.id.zd);
                 mgjzc= (TextView) findViewById(R.id.mgjzc);
                 sjl= (TextView) findViewById(R.id.sjl);

                t1= (TextView) findViewById(R.id.t1);
                t2= (TextView) findViewById(R.id.t2);
                t3= (TextView) findViewById(R.id.t3);


                tv_stock_name.setText(entity.getStock_name());
                m_1_1.setText(entity.getM_1_1());
                m_2_1.setText(entity.getM_2_1());
                m_3_1.setText(entity.getM_3_1());
                m_4_1.setText(entity.getM_4_1());
                m_5_1.setText(entity.getM_5_1());
                m_1_2.setText(entity.getM_1_2());
                m_2_2.setText(entity.getM_2_2());
                m_3_2.setText(entity.getM_3_2());
                m_4_2.setText(entity.getM_4_2());
                m_5_2.setText(entity.getM_5_2());

                mm_1_1.setText(entity.getMm_1_1());
                mm_2_1.setText(entity.getMm_2_1());
                mm_3_1.setText(entity.getMm_3_1());
                mm_4_1.setText(entity.getMm_4_1());
                mm_5_1.setText(entity.getMm_5_1());
                mm_1_2.setText(entity.getMm_1_2());
                mm_2_2.setText(entity.getMm_2_2());
                mm_3_2.setText(entity.getMm_3_2());
                mm_4_2.setText(entity.getMm_4_2());
                mm_5_2.setText(entity.getMm_5_2());

                 jk.setText(entity.getJk());
                zs.setText(entity.getZs());
                 cjl.setText(entity.getCjl());
//                int i = Integer.parseInt(entity.getSz());
                 sz.setText(entity.getSz()+"万");
                 zg.setText(entity.getZg());
                 mgsy.setText(entity.getMgsy());
                 syl.setText(entity.getSyl());
                 zd.setText(entity.getZd());
                 mgjzc.setText(entity.getMgjzc());
                 sjl.setText(entity.getSjl());
                t1.setText(entity.getT1());

            }
        }.execute(stock_code.trim());



    }



}
