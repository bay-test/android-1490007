package com.example.acer1.stock_app;

import android.widget.TextView;

/**
 * Created by acer1 on 2017-06-09 0009.
 */

public class Entity {
    String stock_name;
    String stock_code;
    String stock_zxj;
    String stock_zdf;
    String _id;
    String stockcodes_sina;


    String m_1_1;
    String m_1_2;
    String m_2_1;
    String m_2_2;
    String m_3_1;
    String m_3_2;
    String m_4_1;
    String m_4_2;
    String m_5_1;
    String m_5_2;

    String mm_1_1;
    String mm_1_2;
    String mm_2_1;
    String mm_2_2;
    String mm_3_1;
    String mm_3_2;
    String mm_4_1;
    String mm_4_2;
    String mm_5_1;
    String mm_5_2;

    String jk;
    String zs;
    String cjl;
    String sz;
    String zg;
    String mgsy;
    String syl;
    String zd;
    String mgjzc;

    String t1;
    String t2;
    String t3;
    String username;

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getT1() {
        return t1;
    }

    public void setT1(String t1) {
        this.t1 = t1;
    }

    public String getT2() {
        return t2;
    }

    public void setT2(String t2) {
        this.t2 = t2;
    }

    public String getT3() {
        return t3;
    }

    public void setT3(String t3) {
        this.t3 = t3;
    }

    public String getCjl() {
        return cjl;
    }

    public void setCjl(String cjl) {
        this.cjl = cjl;
    }

    public String getMgjzc() {
        return mgjzc;
    }

    public void setMgjzc(String mgjzc) {
        this.mgjzc = mgjzc;
    }

    public String getMgsy() {
        return mgsy;
    }

    public void setMgsy(String mgsy) {
        this.mgsy = mgsy;
    }

    public String getSjl() {
        return sjl;
    }

    public void setSjl(String sjl) {
        this.sjl = sjl;
    }

    public String getSyl() {
        return syl;
    }

    public void setSyl(String syl) {
        this.syl = syl;
    }

    public String getSz() {
        return sz;
    }

    public void setSz(String sz) {
        this.sz = sz;
    }

    public String getZd() {
        return zd;
    }

    public void setZd(String zd) {
        this.zd = zd;
    }

    public String getZg() {
        return zg;
    }

    public void setZg(String zg) {
        this.zg = zg;
    }

    public String getZs() {
        return zs;
    }

    public void setZs(String zs) {
        this.zs = zs;
    }

    String sjl;


    public String getMm_1_1() {
        return mm_1_1;
    }

    public void setMm_1_1(String mm_1_1) {
        this.mm_1_1 = mm_1_1;
    }

    public String getMm_1_2() {
        return mm_1_2;
    }

    public void setMm_1_2(String mm_1_2) {
        this.mm_1_2 = mm_1_2;
    }

    public String getMm_2_1() {
        return mm_2_1;
    }

    public void setMm_2_1(String mm_2_1) {
        this.mm_2_1 = mm_2_1;
    }

    public String getMm_2_2() {
        return mm_2_2;
    }

    public void setMm_2_2(String mm_2_2) {
        this.mm_2_2 = mm_2_2;
    }

    public String getMm_3_1() {
        return mm_3_1;
    }

    public void setMm_3_1(String mm_3_1) {
        this.mm_3_1 = mm_3_1;
    }

    public String getMm_3_2() {
        return mm_3_2;
    }

    public void setMm_3_2(String mm_3_2) {
        this.mm_3_2 = mm_3_2;
    }

    public String getMm_4_1() {
        return mm_4_1;
    }

    public void setMm_4_1(String mm_4_1) {
        this.mm_4_1 = mm_4_1;
    }

    public String getMm_4_2() {
        return mm_4_2;
    }

    public void setMm_4_2(String mm_4_2) {
        this.mm_4_2 = mm_4_2;
    }

    public String getMm_5_1() {
        return mm_5_1;
    }

    public void setMm_5_1(String mm_5_1) {
        this.mm_5_1 = mm_5_1;
    }

    public String getMm_5_2() {
        return mm_5_2;
    }

    public void setMm_5_2(String mm_5_2) {
        this.mm_5_2 = mm_5_2;
    }



    public String getM_1_1() {
        return m_1_1;
    }

    public void setM_1_1(String m_1_1) {
        this.m_1_1 = m_1_1;
    }

    public String getM_1_2() {
        return m_1_2;
    }

    public void setM_1_2(String m_1_2) {
        this.m_1_2 = m_1_2;
    }

    public String getM_2_1() {
        return m_2_1;
    }

    public void setM_2_1(String m_2_1) {
        this.m_2_1 = m_2_1;
    }

    public String getM_2_2() {
        return m_2_2;
    }

    public void setM_2_2(String m_2_2) {
        this.m_2_2 = m_2_2;
    }

    public String getM_3_1() {
        return m_3_1;
    }

    public void setM_3_1(String m_3_1) {
        this.m_3_1 = m_3_1;
    }

    public String getM_3_2() {
        return m_3_2;
    }

    public void setM_3_2(String m_3_2) {
        this.m_3_2 = m_3_2;
    }

    public String getM_4_1() {
        return m_4_1;
    }

    public void setM_4_1(String m_4_1) {
        this.m_4_1 = m_4_1;
    }

    public String getM_4_2() {
        return m_4_2;
    }

    public void setM_4_2(String m_4_2) {
        this.m_4_2 = m_4_2;
    }

    public String getM_5_1() {
        return m_5_1;
    }

    public void setM_5_1(String m_5_1) {
        this.m_5_1 = m_5_1;
    }

    public String getM_5_2() {
        return m_5_2;
    }

    public void setM_5_2(String m_5_2) {
        this.m_5_2 = m_5_2;
    }



    public void setJk(String jk) {
        this.jk = jk;
    }

    public String getJk() {

        return jk;
    }

    public Entity(String jk) {

        this.jk = jk;
    }

    public Entity(String _id, String stock_code, String stock_name, String stock_zdf, String stock_zxj, String stockcodes_sina,String jk) {
        this._id = _id;
        this.stock_code = stock_code;
        this.stock_name = stock_name;
        this.stock_zdf = stock_zdf;
        this.stock_zxj = stock_zxj;
        this.stockcodes_sina = stockcodes_sina;

        this.jk=jk;
    }

    @Override
    protected Object clone() throws CloneNotSupportedException {
        return super.clone();
    }

    @Override
    public boolean equals(Object obj) {
        return super.equals(obj);
    }

    @Override
    protected void finalize() throws Throwable {
        super.finalize();
    }

    @Override
    public int hashCode() {
        return super.hashCode();
    }

    public Entity() {
        super();
    }

    @Override
    public String toString() {
        return super.toString();
    }

    public void set_id(String _id) {
        this._id = _id;
    }

    public void setStock_code(String stock_code) {
        this.stock_code = stock_code;
    }

    public void setStock_name(String stock_name) {
        this.stock_name = stock_name;
    }

    public void setStock_zdf(String stock_zdf) {
        this.stock_zdf = stock_zdf;
    }

    public void setStock_zxj(String stock_zxj) {
        this.stock_zxj = stock_zxj;
    }

    public void setStockcodes_sina(String stockcodes_sina) {
        this.stockcodes_sina = stockcodes_sina;
    }

    public String get_id() {

        return _id;
    }

    public String getStock_code() {
        return stock_code;
    }

    public String getStock_name() {
        return stock_name;
    }

    public String getStock_zdf() {
        return stock_zdf;
    }

    public String getStock_zxj() {
        return stock_zxj;
    }

    public String getStockcodes_sina() {
        return stockcodes_sina;
    }


}