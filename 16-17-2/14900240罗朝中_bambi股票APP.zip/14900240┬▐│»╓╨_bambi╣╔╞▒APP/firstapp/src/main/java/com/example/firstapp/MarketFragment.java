package com.example.firstapp;


import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.res.Resources;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTabHost;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.ImageView;
import android.widget.TabHost;
import android.widget.TextView;
import android.widget.Toast;

import java.util.HashMap;
import java.util.Map;


/**
 * A simple {@link Fragment} subclass.
 */
public class MarketFragment extends Fragment {
    ChoseFragment choseFragment;
    FragmentTabHost fragmentTabHost;
Map<String,Stock> stockMap=new HashMap<>();
    Handler handler = new Handler(new Handler.Callback() {
        @Override
        public boolean handleMessage(Message message) {
            Toast.makeText(getContext(),""+message.obj,Toast.LENGTH_SHORT).show();
            return false;
        }
    });

    public MarketFragment() {
        // Required empty public constructor
    }


    @Override
    public void onAttachFragment(Fragment childFragment) {
        super.onAttachFragment(childFragment);
        if (childFragment instanceof ChoseFragment){
            choseFragment = (ChoseFragment) childFragment;
            ((ChoseFragment) childFragment).setHandler(handler);

        }

        Toast.makeText(getContext(),""+childFragment,Toast.LENGTH_SHORT).show();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, final ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_market, container, false);
        fragmentTabHost = (FragmentTabHost) view.findViewById(R.id.tabhost1);
        fragmentTabHost.setup(getActivity(), getChildFragmentManager(), R.id.c_f);
        final AutoCompleteTextView tv_auoto= (AutoCompleteTextView) view.findViewById(R.id.tv_auoto);

        TabHost.TabSpec tabSpeChose = fragmentTabHost.newTabSpec("chose");
        View viewChose = View.inflate(getActivity(), R.layout.tab_item_bottom2, null);
        ImageView imageViewChose = (ImageView) viewChose.findViewById(R.id.iv_icon2);
        imageViewChose.setImageResource(R.drawable.selecter_chose);
        TextView textViewChose = (TextView) viewChose.findViewById(R.id.iv_name2);
        textViewChose.setText("自选");
        tabSpeChose.setIndicator(viewChose);
        fragmentTabHost.addTab(tabSpeChose, ChoseFragment.class, null);

        TabHost.TabSpec tabSpeHushen = fragmentTabHost.newTabSpec("Hushen");
        View viewHushen = View.inflate(getActivity(), R.layout.tab_item_bottom3, null);
        ImageView imageViewHushen = (ImageView) viewHushen.findViewById(R.id.iv_icon3);
        imageViewHushen.setImageResource(R.drawable.selecter_hushen);
        TextView textViewHushen = (TextView) viewHushen.findViewById(R.id.iv_name3);
        textViewHushen.setText("沪深");
        tabSpeHushen.setIndicator(viewHushen);
        fragmentTabHost.addTab(tabSpeHushen, HushenFragment.class, null);

        final Resources resources = view.getResources();
        final String[] stockcode = resources.getStringArray(R.array.stockcodes);
        final String[] sinastockcode = resources.getStringArray(R.array.sinastockcodes);
        final String[] stockname = resources.getStringArray(R.array.stocknames);
        for (int i=0;i<stockcode.length;i++){
            Stock stock=new Stock();
            stock.setStockcode(stockcode[i]);
            stock.setSinastockcode(sinastockcode[i]);
            stock.setStockname(stockname[i]);
            stockMap.put(stockcode[i],stock);
        }
        ArrayAdapter arrayAdapter=new ArrayAdapter(getContext(),android.R.layout.simple_list_item_1,stockcode);
        tv_auoto.setAdapter(arrayAdapter);
        tv_auoto.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
               String stockcode= adapterView.getItemAtPosition(i).toString();
              Stock  stock=  stockMap.get(stockcode);

                ContentValues contentValues=new ContentValues();
                contentValues.put("stockcodes",stock.getStockcode() );
                contentValues.put("sinastockcodes", stock.getSinastockcode());
                contentValues.put("stocknames", stock.getStockname());
                MySQLiteOpenHelper mySQLiteOpenHelper=new MySQLiteOpenHelper(getContext(),1);
                SQLiteDatabase S=mySQLiteOpenHelper.getWritableDatabase();
                S.insert("stock",null,contentValues);
                S.close();
                tv_auoto.setText("");
                choseFragment.reRefresh();
                Toast.makeText(getActivity(),"添加成功！",Toast.LENGTH_SHORT).show();
            }
        });
        return view;

    }
}
