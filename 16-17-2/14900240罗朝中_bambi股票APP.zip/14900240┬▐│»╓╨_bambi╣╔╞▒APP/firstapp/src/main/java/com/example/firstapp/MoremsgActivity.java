package com.example.firstapp;

import android.content.Intent;
import android.os.AsyncTask;
import android.support.v4.app.FragmentTabHost;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TabHost;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

public class MoremsgActivity extends AppCompatActivity {
    TextView tv_title;
    TextView tv_buy2;
    TextView tv_buy3;
    TextView tv_sell2;
    TextView tv_sell3;
    String sinastockcode;
    FragmentTabHost fragTabHost;

    @Override
    protected void onCreate(final Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_moremsg);
        tv_title = (TextView) findViewById(R.id.tv_title);
        tv_buy2 = (TextView) findViewById(R.id.tv_buy2);
        tv_buy3 = (TextView) findViewById(R.id.tv_buy3);
        tv_sell2 = (TextView) findViewById(R.id.tv_sell2);
        tv_sell3 = (TextView) findViewById(R.id.tv_sell3);
        Intent intent = getIntent();
        String stockcode = intent.getStringExtra("stockcodes");
        sinastockcode = intent.getStringExtra("sinastockcodes");
        Toast.makeText(this,stockcode+"++++"+sinastockcode,Toast.LENGTH_SHORT).show();
        Log.e("ggggggggg", "onCreate: "+sinastockcode );

        fragTabHost = (FragmentTabHost) findViewById(R.id.tabhost2);
        fragTabHost.setup(MoremsgActivity.this,getSupportFragmentManager(),R.id.realtabcontent1);
        Bundle bundle = new Bundle();
        bundle.putString("sinastockcodes",sinastockcode);

        TabHost.TabSpec tabSpecFenshi = fragTabHost.newTabSpec("fenshi");
        tabSpecFenshi.setIndicator("分时");
        fragTabHost.addTab(tabSpecFenshi,FenshiFragment.class,bundle);


        TabHost.TabSpec tabSpecRik = fragTabHost.newTabSpec("rik");
//        View viewRik = View.inflate(this,R.layout.tab_item_rik,null);
        tabSpecRik.setIndicator("日k");
        fragTabHost.addTab(tabSpecRik,RikFragment.class,bundle);

        TabHost.TabSpec tabSpecZhouk = fragTabHost.newTabSpec("zhouk");
        tabSpecZhouk.setIndicator("周k");
        fragTabHost.addTab(tabSpecZhouk,ZhoukFragment.class,bundle);

        TabHost.TabSpec tabSpecYuek = fragTabHost.newTabSpec("yuek");
        tabSpecYuek.setIndicator("月k");
        fragTabHost.addTab(tabSpecYuek,YuekFragment.class,bundle);


        new AsyncTask<Void,Integer,Stock>(){

            @Override
            protected Stock doInBackground(Void... params) {
                Stock stock = new Stock();

                try {
                    URL url = new URL("http://hq.sinajs.cn/list="+sinastockcode);
                    HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
                    httpURLConnection.connect();
                    if (httpURLConnection.getResponseCode()==200){
                        InputStream inputStream = httpURLConnection.getInputStream();
                        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                        int length = -1;
                        byte[] b =new byte[1024];
                        while ((length = inputStream.read(b))!=-1) {
                            byteArrayOutputStream.write(b,0,length);

                        }
                        String result = byteArrayOutputStream.toString("GBK");
//                        Toast.makeText(MoremsgActivity.this,""+result,Toast.LENGTH_SHORT).show();
                        byteArrayOutputStream.close();
                        inputStream.close();
                        String[] stockArray = result.split("\"")[1].split(",");
                        stock.setStockname(stockArray[0]);
                        stock.setTv_buy2(stockArray[10]);
                        stock.setTv_buy3(stockArray[11]);
                        stock.setTv_sell2(stockArray[20]);
                        stock.setTv_sell3(stockArray[21]);




                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }


                return stock;
            }

            @Override
            protected void onPostExecute(Stock stock) {
                super.onPostExecute(stock);
                tv_title.setText(stock.getStockname());
                tv_buy2.setText(stock.getTv_buy2());
                tv_buy3.setText(stock.getTv_buy3());
                tv_sell2.setText(stock.getTv_sell2());
                tv_sell3.setText(stock.getTv_sell3());
            }
        }.execute();




    }
    public void backHome(View view){
        finish();
    }
}
