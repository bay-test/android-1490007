package com.example.firstapp;


import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;


/**
 * A simple {@link Fragment} subclass.
 */
public class ZhoukFragment extends Fragment {
    ImageView iv_zhouk;
    String sinastockcode;


    public ZhoukFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_zhouk, container, false);
        iv_zhouk = (ImageView) view.findViewById(R.id.iv_zhouk);
        Bundle bundle = getArguments();
        sinastockcode = bundle.getString("sinastockcodes");
        Log.e("ffffff", "onCreateView: "+sinastockcode );
        new AsyncTask<String, Integer, byte[]>(){

            @Override
            protected byte[] doInBackground(String... params) {
                Common com = new Common();
                String urlstock = ("http://image.sinajs.cn/newchart/weekly/n/"+params[0]+".gif");
                byte[] day = com.loadChart(urlstock);

                Log.e("tag", "doInBackground:------------- "+day.length );
                return day;
            }

            @Override
            protected void onPostExecute(byte[] bytes) {
                super.onPostExecute(bytes);
                Bitmap bitmap = BitmapFactory.decodeByteArray(bytes,0,bytes.length);
                iv_zhouk.setImageBitmap(bitmap);

            }
        }.execute(sinastockcode.trim());
        // Inflate the layout for this fragment
        return view;
    }

}
