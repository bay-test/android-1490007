package com.example.firstapp;

import android.content.Intent;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.AnimationSet;
import android.view.animation.RotateAnimation;
import android.view.animation.ScaleAnimation;
import android.widget.RelativeLayout;

public class welcome extends AppCompatActivity {
    Handler handler;
    RelativeLayout activity_login;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome);
        activity_login = (RelativeLayout) findViewById(R.id.activity_login);
        handler = new Handler(new Handler.Callback(){

            @Override
            public boolean handleMessage(Message message) {
                if (message.what==1){
                    Intent intent = new Intent(welcome.this,MainActivity.class);
                    startActivity(intent);
                }
                return false;
            }
        });
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Animation rotate = new RotateAnimation(0,360,Animation.RELATIVE_TO_SELF,0.5f);
                rotate.setDuration(3000);
                rotate.setStartOffset(1000);
                Animation scale = new ScaleAnimation(0.5f,1f,0.5f,1f,Animation.RELATIVE_TO_SELF,0.5f);
                scale.setDuration(3000);
                scale.setStartOffset(1000);
                Animation alpha = new AlphaAnimation(0,1);
                alpha.setDuration(3000);
                alpha.setStartOffset(1000);
                AnimationSet animationSet = new AnimationSet(true);
                animationSet.addAnimation(rotate);
                animationSet.addAnimation(scale);
                animationSet.addAnimation(alpha);
                activity_login.setAnimation(animationSet);
            }
        });
        handler.sendEmptyMessageDelayed(1,6000);

    }
}
