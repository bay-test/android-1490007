package com.example.firstapp;

import android.util.Log;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by Administrator on 2017/6/15 0015.
 */

public class Common {

    public Map<String, Stock> loadStocks(String sinaStockCode) {
        Map<String, Stock> stocksMap = new HashMap<String, Stock>();
        try {
            URL url = new URL("http://hq.sinajs.cn/list=" + sinaStockCode);
            HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();

            httpURLConnection.connect();

            if (httpURLConnection.getResponseCode() == 200) {

                InputStream inputStream = httpURLConnection.getInputStream();
                ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();

                int len = -1;
                byte[] b = new byte[1024];
                while ((len = inputStream.read(b)) != -1) {
                    byteArrayOutputStream.write(b, 0, len);
                }
                String result = byteArrayOutputStream.toString("GBK");
                // Toast.makeText(DetailActivity.this, ""+result, Toast.LENGTH_SHORT).show();
                //  Log.e("tag", "doInBackground:================= " + result);

                byteArrayOutputStream.close();
                inputStream.close();
                httpURLConnection.disconnect();

                Log.e("tag", "loadStocks: ----------" + result);
                result = result.replace("var hq_str_", "");
                result = result.replace("\"", "");
                String[] stocks = result.split(";");
                for (String stock : stocks) {
                    String[] s = stock.split("=");
                    if (s.length < 2) {
                        continue;
                    }
                    String[] stockInfo = s[1].split(",");
                    Stock retStock = new Stock();
                    retStock.setStockname(stockInfo[0]);
                    retStock.setTv_buy2(stockInfo[10]);
                    retStock.setTv_buy3(stockInfo[11]);
                    retStock.setTv_sell2(stockInfo[20]);
                    retStock.setTv_sell3(stockInfo[21]);
                    retStock.setStocknewest(stockInfo[3]);
                    float stockchange = (Float.valueOf(stockInfo[3]) - Float.valueOf(stockInfo[2])) / Float.valueOf(stockInfo[2]);

                    DecimalFormat decimalFormat = new DecimalFormat("0.00");
                    String stockchangestr = decimalFormat.format(stockchange * 100);

                    retStock.setStockchange(stockchangestr + "%");
                    retStock.setSinastockcode(s[0]);
                    retStock.setStockcode(s[0].replace("sh", "").replace("sz", ""));
                    stocksMap.put(s[0], retStock);


                }


            }


        } catch (Exception e) {
            e.printStackTrace();

        }

        return stocksMap;
    }

    public byte[] loadChart(String strurl) {

        byte[] minChart = null;

        try {
            // String urlstr = "http://image.sinajs.cn/newchart/min/n/" + sinaStockCode + ".gif";
             Log.e("tag", "loadMinChart:------------- "+strurl );
            URL url = new URL(strurl);
            HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
            httpURLConnection.connect();
            if (httpURLConnection.getResponseCode() == 200) {

                InputStream inputStream = httpURLConnection.getInputStream();
                ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();

                int len = -1;
                byte[] b = new byte[1024];
                while ((len = inputStream.read(b)) != -1) {
                    byteArrayOutputStream.write(b, 0, len);
                }
                minChart = byteArrayOutputStream.toByteArray();
                // Toast.makeText(DetailActivity.this, ""+result, Toast.LENGTH_SHORT).show();
                //  Log.e("tag", "doInBackground:================= " + result);

                byteArrayOutputStream.close();
                inputStream.close();
                httpURLConnection.disconnect();


            }


        } catch (Exception e) {
            e.printStackTrace();

        }

        return minChart;
    }


}
