package com.example.firstapp;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v4.app.Fragment;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.nio.Buffer;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;


/**
 * A simple {@link Fragment} subclass.
 */
public class ChoseFragment extends Fragment {
    List<Stock> stocks = new ArrayList<Stock>();
    MyAdapter myAdapter;
    Handler handler;

    public ChoseFragment() {
        // Required empty public constructor
    }
    public void setHandler(Handler handler){
        this.handler = handler;

    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             final Bundle savedInstanceState) {
        Message message = Message.obtain();
        message.obj = "abcd";
        handler.sendMessage(message);
        View view = inflater.inflate(R.layout.chose_fragmens, container, false);
        RecyclerView recyclerView = (RecyclerView) view.findViewById(R.id.rv_stock);
        final SwipeRefreshLayout swipeRefreshLayout = (SwipeRefreshLayout) view.findViewById(R.id.refresh);
        swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
               getStocks();
                swipeRefreshLayout.setRefreshing(false);
            }
        });
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        getStocks();
        

        myAdapter = new MyAdapter(getContext(),stocks);
        recyclerView.setAdapter(myAdapter);


        return view;

    }
    public void reRefresh(){
        getStocks();
        myAdapter.notifyDataSetChanged();

    }

    private void getStocks() {
        stocks.clear();

        MySQLiteOpenHelper mySQLiteOpenHelper = new MySQLiteOpenHelper(getContext(),1);
        SQLiteDatabase sqLiteDatabase = mySQLiteOpenHelper.getWritableDatabase();
        Cursor cursor =sqLiteDatabase.query("stock",new String[]{"_id","stockcodes","sinastockcodes","stocknames"},null,null,null,null,null);
//        StringBuffer queryCodes;
//        queryCodes=new StringBuffer();
        while(cursor.moveToNext()){
            Stock stock = new Stock();
            stock.setStockchange("10%");
            stock.setStocknewest("4.00");
            stock.set_id(cursor.getString(0));
            stock.setStockcode(cursor.getString(1));
            stock.setSinastockcode(cursor.getString(2));
            stock.setStockname(cursor.getString(3));

            stocks.add(stock);
        }
        sqLiteDatabase.close();


    }


}


//            queryCodes.append(cursor.getString(3).trim()+",");
//
//        }
//        sqLiteDatabase.close();
//        new AsyncTask<String, Integer, Map<String, Stock>>() {
//            @Override
//            protected Map<String, Stock> doInBackground(String... params) {
//                Common common=new Common();
//
//
//                return common.loadStocks(params[0]);
//            }
//
//            @Override
//            protected void onPostExecute(Map<String, Stock> stringStockMap) {
//                super.onPostExecute(stringStockMap);
//                stocks.addAll(stringStockMap.values());
//                if (myAdapter!=null){
//                    myAdapter.notifyDataSetChanged();
//                }
//            }
//        }.execute(queryCodes.toString());
//
//
//    }
//
//
//}





class MyAdapter extends RecyclerView.Adapter {
    Context context;
    List<Stock> stocks;
    public MyAdapter (Context context,List<Stock> stocks){
        this.context = context;
        this.stocks = stocks;

    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
       // View view = View.inflate(context,R.layout.stock_item,null);
        View view = LayoutInflater.from(context).inflate(R.layout.stock_item,parent,false);
        MyHolder myHolder = new MyHolder(view);
        return myHolder;
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        MyHolder myHolder = (MyHolder) holder;
        myHolder.stockname.setText(stocks.get(position).getStockname());
        myHolder.stockcode.setText(stocks.get(position).getStockcode());
        myHolder.stocknewest.setText(stocks.get(position).getStocknewest());
        myHolder.stockchange.setText(stocks.get(position).getStockchange());


    }

    @Override
    public int getItemCount() {
        return stocks.size();
    }

    class MyHolder extends RecyclerView.ViewHolder {
        TextView stockname;
        TextView stockcode;
        TextView stocknewest;
        TextView stockchange;


        public MyHolder(View itemView) {
            super(itemView);
            stockname = (TextView) itemView.findViewById(R.id.stockname);
            stockcode = (TextView) itemView.findViewById(R.id.stockcode);
            stocknewest = (TextView) itemView.findViewById(R.id.stocknewest);
            stockchange = (TextView) itemView.findViewById(R.id.stockchange);
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Stock stock = stocks.get(getAdapterPosition());
                    Intent intent = new Intent(context,MoremsgActivity.class);
                    intent.putExtra("stockcodes",stock.getStockcode());
                    intent.putExtra("sinastockcodes",stock.getSinastockcode());
                    context.startActivity(intent);


                }
            });
        }
    }
}