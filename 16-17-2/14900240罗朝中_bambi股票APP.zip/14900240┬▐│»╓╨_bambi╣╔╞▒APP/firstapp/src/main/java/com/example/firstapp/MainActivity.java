package com.example.firstapp;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTabHost;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TabHost;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    FragmentTabHost fragmentTabHost;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        fragmentTabHost = (FragmentTabHost) findViewById(R.id.tabhost);
        fragmentTabHost.setup(MainActivity.this,getSupportFragmentManager(),R.id.realtabcontent);

        TabHost.TabSpec tabSpecMarket = fragmentTabHost.newTabSpec("market");
        View viewMarket = View.inflate(this,R.layout.tab_item_bottom,null);
        ImageView imageViewMarket = (ImageView) viewMarket.findViewById(R.id.iv_icon);
        imageViewMarket.setImageResource(R.drawable.selecter_market);
        TextView textViewMarket = (TextView) viewMarket.findViewById(R.id.iv_name);
        textViewMarket.setText("行情");
        tabSpecMarket.setIndicator(viewMarket);
        fragmentTabHost.addTab(tabSpecMarket,MarketFragment.class,null);

        TabHost.TabSpec tabSpecMine = fragmentTabHost.newTabSpec("mine");
        View viewMine = View.inflate(this,R.layout.tab_item_bottom1,null);
        ImageView imageViewMine = (ImageView) viewMine.findViewById(R.id.iv_icon1);
        imageViewMine.setImageResource(R.drawable.selecter_mine);
        TextView textViewMine = (TextView) viewMine.findViewById(R.id.iv_name1);
        textViewMine.setText("我的");
        tabSpecMine.setIndicator(viewMine);

        fragmentTabHost.addTab(tabSpecMine,MineFragment.class,null);
    }
}
