package com.example.firstapp;

/**
 * Created by Administrator on 2017/6/12 0012.
 */
public class Stock {
    String stockname;
    String stockcode;
    String stocknewest;
    String stockchange;
    String sinastockcode;
    String _id;
    String tv_title;
    String tv_buy2;
    String tv_buy3;
    String tv_sell2;
    String tv_sell3;

    public String getTv_title() {
        return tv_title;
    }

    public void setTv_title(String tv_title) {
        this.tv_title = tv_title;
    }

    public String getTv_buy2() {
        return tv_buy2;
    }

    public void setTv_buy2(String tv_buy2) {
        this.tv_buy2 = tv_buy2;
    }

    public String getTv_buy3() {
        return tv_buy3;
    }

    public void setTv_buy3(String tv_buy3) {
        this.tv_buy3 = tv_buy3;
    }

    public String getTv_sell2() {
        return tv_sell2;
    }

    public void setTv_sell2(String tv_sell2) {
        this.tv_sell2 = tv_sell2;
    }

    public String getTv_sell3() {
        return tv_sell3;
    }

    public void setTv_sell3(String tv_sell3) {
        this.tv_sell3 = tv_sell3;
    }

    public String get_id() {
        return _id;
    }

    public void set_id(String _id) {
        this._id = _id;
    }

    public String getSinastockcode() {
        return sinastockcode;
    }

    public void setSinastockcode(String sinastockcode) {
        this.sinastockcode = sinastockcode;
    }

    public String getStockname() {
        return stockname;
    }

    public void setStockname(String stockname) {
        this.stockname = stockname;
    }

    public String getStockcode() {
        return stockcode;
    }

    public void setStockcode(String stockcode) {
        this.stockcode = stockcode;
    }

    public String getStocknewest() {
        return stocknewest;
    }

    public void setStocknewest(String stocknewest) {
        this.stocknewest = stocknewest;
    }

    public String getStockchange() {
        return stockchange;
    }

    public void setStockchange(String stockchange) {
        this.stockchange = stockchange;
    }


}
