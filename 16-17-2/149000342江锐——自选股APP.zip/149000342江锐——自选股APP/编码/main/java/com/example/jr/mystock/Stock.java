package com.example.jr.mystock;

/**
 * Created by jr on 2017/6/16.
 */

public class Stock {
    String stockname;
    String stockcode;
    String nowprice;
    String nowchange;
    String sinastockcode;
    String _id;

    String buy_price1;
    String buy_count1;
    String sale_price1;
    String sale_count1;

    public String getBuy_price1() {
        return buy_price1;
    }

    public void setBuy_price1(String buy_price1) {
        this.buy_price1 = buy_price1;
    }

    public String getBuy_count1() {
        return buy_count1;
    }

    public void setBuy_count1(String buy_count1) {
        this.buy_count1 = buy_count1;
    }

    public String getSale_price1() {
        return sale_price1;
    }

    public void setSale_price1(String sale_price1) {
        this.sale_price1 = sale_price1;
    }

    public String getSale_count1() {
        return sale_count1;
    }

    public void setSale_count1(String sale_count1) {
        this.sale_count1 = sale_count1;
    }

    public void setStockname(String stockname) {
        this.stockname = stockname;
    }

    public void setStockcode(String stockcode) {
        this.stockcode = stockcode;
    }

    public void setNowprice(String nowprice) {
        this.nowprice = nowprice;
    }

    public void setNowchange(String nowchange) {
        this.nowchange = nowchange;
    }

    public void setSinastockcode(String sinastockcode) {
        this.sinastockcode = sinastockcode;
    }

    public void set_id(String _id) {
        this._id = _id;
    }

    public String getStockname() {
        return stockname;
    }

    public String getStockcode() {
        return stockcode;
    }

    public String getNowprice() {
        return nowprice;
    }

    public String getNowchange() {
        return nowchange;
    }

    public String getSinastockcode() {
        return sinastockcode;
    }

    public String get_id() {
        return _id;
    }
}
