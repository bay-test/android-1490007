package com.example.jr.mystock;

import android.content.Intent;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTabHost;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TabHost;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    FragmentTabHost fragmentTabHost;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().hide();
        fragmentTabHost= (FragmentTabHost) findViewById(android.R.id.tabhost);
        fragmentTabHost.setup(MainActivity.this,getSupportFragmentManager(),R.id.realtabcontent);

        TabHost.TabSpec tabSpecMarket=fragmentTabHost.newTabSpec("market");
        View viewMarket=View.inflate(this,R.layout.tab_item_button,null);
        ImageView imageViewMarket= (ImageView) viewMarket.findViewById(R.id.iv_icon);
        imageViewMarket.setImageResource(R.drawable.market_item_selector);

        TextView textViewMarket= (TextView) viewMarket.findViewById(R.id.tv_name);
        textViewMarket.setText("行情");
        tabSpecMarket.setIndicator(viewMarket);

        fragmentTabHost.addTab(tabSpecMarket,MarketFragment.class,null);



        TabHost.TabSpec tabSpecMine=fragmentTabHost.newTabSpec("mine");
        View viewMine=View.inflate(this,R.layout.tab_item_button,null);
        ImageView imageViewMine= (ImageView) viewMine.findViewById(R.id.iv_icon);
        imageViewMine.setImageResource(R.drawable.mine_item_selector);

        TextView textViewMine= (TextView) viewMine.findViewById(R.id.tv_name);
        textViewMine.setText("我的");

        tabSpecMine.setIndicator(viewMine);
        fragmentTabHost.addTab(tabSpecMine,MineFragment.class,null);

    }
    public void editStock(View view){
        Intent intent=new Intent(MainActivity.this,EditStockActivity.class);
        startActivity(intent);
    }
}
