package com.example.jr.mystock;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.v4.app.FragmentTabHost;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TabHost;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;

public class DetailActivity extends AppCompatActivity {
    TextView stockname;
    TextView buy_price1;
    TextView buy_count1;
    TextView sale_price1;
    TextView sale_count1;

    String stockcode;
    String sinastockcode;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);
        getSupportActionBar().hide();
/*
Intent intent = getIntent();
        sinastockcode =  intent.getStringExtra("sinastockcode");
*/

        Intent intent=getIntent();
        stockcode=intent.getStringExtra("stockcode");
        sinastockcode=intent.getStringExtra("sinastockcode");

        Toast.makeText(this,stockcode+"---"+sinastockcode,Toast.LENGTH_LONG).show();
        FragmentTabHost fragmentTabHost= (FragmentTabHost) findViewById(android.R.id.tabhost);
        fragmentTabHost.setup(this,getSupportFragmentManager(),R.id.realtabcontent);


        TabHost.TabSpec tabSpecfen=fragmentTabHost.newTabSpec("fen");
        tabSpecfen.setIndicator("分时K");
        Bundle bundle=new Bundle();
        bundle.putString("sinastockcode",sinastockcode);
        fragmentTabHost.addTab(tabSpecfen,fenFragment.class,bundle);

        TabHost.TabSpec tabSpecri=fragmentTabHost.newTabSpec("ri");
        tabSpecri.setIndicator("日K");
        fragmentTabHost.addTab(tabSpecri,riFragment.class,null);


        TabHost.TabSpec tabSpeczhou=fragmentTabHost.newTabSpec("zhou");
        tabSpeczhou.setIndicator("周K");
        fragmentTabHost.addTab(tabSpeczhou,zhouFragment.class,null);


        TabHost.TabSpec tabSpecyue=fragmentTabHost.newTabSpec("yue");
        tabSpecyue.setIndicator("月K");
        fragmentTabHost.addTab(tabSpecyue,yueFragment.class,null);


        stockname= (TextView) findViewById(R.id.stockname);
        buy_price1= (TextView) findViewById(R.id.buy_price1);
        buy_count1 = (TextView) findViewById(R.id.buy_count1);
        sale_price1= (TextView) findViewById(R.id.sale_price1);
        sale_count1= (TextView) findViewById(R.id.sale_count1);

        final ProgressDialog progressDialog=new ProgressDialog(this);
        progressDialog.setMessage("玩命加载中.....");
        progressDialog.setCancelable(false);
        progressDialog.show();



        new AsyncTask<Void,Integer,Stock>(){


            @Override
            protected Stock doInBackground(Void... voids) {
                Stock stock=new Stock();

                try {
                    URL url = new URL("http://hq.sinajs.cn/list=" + sinastockcode.trim());
                    HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
                    httpURLConnection.setRequestMethod("GET");
                    httpURLConnection.connect();
                    if (httpURLConnection.getResponseCode()==200){
                        InputStream inputStream=httpURLConnection.getInputStream();
                        final ByteArrayOutputStream byteArrayOutputStream=new ByteArrayOutputStream();

                        byte[] b=new byte[1024];
                        int len=-1;
                        while ((len = inputStream.read(b))!=-1){
                            byteArrayOutputStream.write(b,0,len);
                        }
                        String result=byteArrayOutputStream.toString("GBK");
                        //   Toast.makeText(DetailActivity.this,""+result,Toast.LENGTH_LONG).show();
                        Log.e("tag", "doInBackground: ========="+result );
                        inputStream.close();
                        byteArrayOutputStream.close();

                        String [] stockArray=result.split("\"")[1].split(",");
                        stock.setStockname(stockArray[0]);
                        stock.setBuy_price1(stockArray[10]);
                        stock.setBuy_count1(stockArray[11]);
                        stock.setSale_price1(stockArray[20]);
                        stock.setSale_count1(stockArray[21]);

                    }
                    httpURLConnection.disconnect();


                } catch (IOException e) {
                    e.printStackTrace();
                    progressDialog.dismiss();
                }


                return stock;
            }

            @Override
            protected void onPostExecute(Stock stock) {

                super.onPostExecute(stock);

                stockname.setText(stock.getStockname());
                buy_price1.setText(stock.getBuy_price1());
                buy_count1.setText(stock.getBuy_count1());
                sale_price1.setText(stock.getSale_price1());
                sale_count1.setText(stock.getSale_count1());

                progressDialog.dismiss();
            }
        }.execute();


    }
    public  void backHome(View view){
        finish();
    }
}